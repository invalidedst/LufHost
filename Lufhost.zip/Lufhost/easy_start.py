#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LufHost Easy Start - Самый простой способ запустить бота
Решает все проблемы одной командой
"""

import os
import sys
import subprocess
import logging
from pathlib import Path

def setup_logging():
    """Настройка логирования"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(message)s',
        handlers=[
            logging.FileHandler('easy_start.log'),
            logging.StreamHandler(sys.stdout)
        ]
    )

def print_header():
    """Вывод заголовка"""
    print("🚀 LufHost Easy Start - Решение всех проблем одной командой")
    print("=" * 70)

def check_and_fix_dependencies():
    """Проверка и исправление зависимостей"""
    print("📦 Проверяю зависимости...")
    
    # Проверка Python
    try:
        result = subprocess.run([sys.executable, "--version"], 
                               capture_output=True, text=True)
        if result.returncode == 0:
            print(f"✅ Python: {result.stdout.strip()}")
        else:
            print("❌ Python не найден")
            return False
    except Exception as e:
        print(f"❌ Ошибка Python: {e}")
        return False
    
    # Проверка pip
    try:
        result = subprocess.run([sys.executable, "-m", "pip", "--version"], 
                               capture_output=True, text=True)
        if result.returncode == 0:
            print("✅ pip доступен")
        else:
            print("❌ pip не найден")
            return False
    except Exception as e:
        print(f"❌ Ошибка pip: {e}")
        return False
    
    return True

def install_required_packages():
    """Установка необходимых пакетов"""
    print("📦 Устанавливаю необходимые пакеты...")
    
    packages = [
        "aiogram>=3.0.0",
        "python-dotenv", 
        "aiofiles",
        "aiohttp",
        "requests",
        "docker"
    ]
    
    for package in packages:
        try:
            print(f"   Устанавливаю {package}...")
            result = subprocess.run([
                sys.executable, "-m", "pip", "install", package, "--user"
            ], capture_output=True, text=True)
            
            if result.returncode == 0:
                print(f"   ✅ {package} установлен")
            else:
                print(f"   ⚠️ {package} - возможны проблемы")
        except Exception as e:
            print(f"   ❌ Ошибка установки {package}: {e}")
    
    return True

def fix_database_issues():
    """Исправление проблем с базой данных"""
    print("🗄️ Исправляю проблемы с базой данных...")
    
    try:
        # Запуск fix скрипта
        result = subprocess.run([sys.executable, "database_fix.py"], 
                               capture_output=True, text=True)
        
        if result.returncode == 0:
            print("✅ База данных исправлена")
            return True
        else:
            print(f"⚠️ Предупреждение БД: {result.stderr}")
            return True  # Продолжаем даже с предупреждениями
    except Exception as e:
        print(f"❌ Ошибка исправления БД: {e}")
        return False

def create_simple_startup():
    """Создание простого скрипта запуска"""
    print("📝 Создаю простой скрипт запуска...")
    
    try:
        # Создаем упрощенный скрипт запуска
        startup_script = """#!/bin/bash
# LufHost Easy Start Script

echo "🚀 LufHost Bot - Простой запуск"
echo "================================="

# Проверяем папку бота
if [ ! -d "LufHost" ]; then
    echo "❌ Папка LufHost не найдена!"
    echo "Создайте папку LufHost и поместите туда файлы бота"
    exit 1
fi

# Переходим в папку бота
cd LufHost

# Проверяем main.py
if [ ! -f "main.py" ]; then
    echo "❌ Файл main.py не найден!"
    echo "Поместите главный файл бота в папку LufHost"
    exit 1
fi

# Проверяем .env файл
if [ ! -f ".env" ]; then
    echo "⚠️ Файл .env не найден, создаю базовый..."
    cat > .env << 'EOF'
# LufHost Bot Configuration
BOT_TOKEN=your_bot_token_here
DATABASE_URL=sqlite:///database.db
ADMIN_IDS=123456789
DEBUG=True
EOF
    echo "✅ Создан файл .env"
    echo "❗ Не забудьте установить ваш BOT_TOKEN в файле .env"
fi

# Устанавливаем зависимости если нужно
echo "📦 Проверяю зависимости..."
python3 -m pip install aiogram python-dotenv aiofiles --user --quiet

# Запускаем бота
echo "🤖 Запускаю бота..."
python3 main.py
"""
        
        # Записываем скрипт
        with open("easy_start.sh", "w") as f:
            f.write(startup_script)
        
        # Делаем исполняемым
        os.chmod("easy_start.sh", 0o755)
        
        # Создаем Windows версию
        windows_script = """@echo off
echo 🚀 LufHost Bot - Простой запуск
echo =================================

if not exist "LufHost" (
    echo ❌ Папка LufHost не найдена!
    echo Создайте папку LufHost и поместите туда файлы бота
    pause
    exit /b 1
)

cd LufHost

if not exist "main.py" (
    echo ❌ Файл main.py не найден!
    echo Поместите главный файл бота в папку LufHost
    pause
    exit /b 1
)

if not exist ".env" (
    echo ⚠️ Файл .env не найден, создаю базовый...
    echo # LufHost Bot Configuration > .env
    echo BOT_TOKEN=your_bot_token_here >> .env
    echo DATABASE_URL=sqlite:///database.db >> .env
    echo ADMIN_IDS=123456789 >> .env
    echo DEBUG=True >> .env
    echo ✅ Создан файл .env
    echo ❗ Не забудьте установить ваш BOT_TOKEN в файле .env
)

echo 📦 Проверяю зависимости...
python -m pip install aiogram python-dotenv aiofiles --user --quiet

echo 🤖 Запускаю бота...
python main.py
pause
"""
        
        with open("easy_start.bat", "w") as f:
            f.write(windows_script)
        
        print("✅ Скрипты запуска созданы:")
        print("   - easy_start.sh (Linux/Mac)")
        print("   - easy_start.bat (Windows)")
        
        return True
        
    except Exception as e:
        print(f"❌ Ошибка создания скриптов: {e}")
        return False

def create_help_guide():
    """Создание руководства по использованию"""
    print("📖 Создаю руководство по использованию...")
    
    help_content = """# LufHost - Простое руководство

## 🚀 Как запустить бота

### 1. Быстрый старт
```bash
# Запустите эту команду один раз для настройки
python3 easy_start.py

# Затем запускайте бота так:
./easy_start.sh          # Linux/Mac
easy_start.bat           # Windows
```

### 2. Настройка

1. Создайте папку `LufHost` и поместите туда файлы вашего бота
2. В файле `LufHost/.env` установите ваш BOT_TOKEN
3. Запустите бота командой выше

## 🐛 Решение проблем

### Проблема: Бот спрашивает соглашение снова
```bash
python3 database_fix.py
```

### Проблема: Не создаются контейнеры
```bash
# Установите Docker
sudo apt install docker.io
sudo systemctl start docker
sudo usermod -aG docker $USER

# Затем запустите:
python3 fix_docker_issue.py
```

### Проблема: Зависимости не установлены
```bash
pip3 install aiogram python-dotenv aiofiles --user
```

## 📁 Структура файлов

```
├── LufHost/                 # Папка с вашим ботом
│   ├── main.py             # Главный файл бота
│   ├── .env                # Настройки (создается автоматически)
│   └── ...                 # Другие файлы бота
├── easy_start.sh           # Скрипт запуска (Linux/Mac)
├── easy_start.bat          # Скрипт запуска (Windows)
├── database_fix.py         # Исправление проблем с БД
├── fix_docker_issue.py     # Исправление проблем с Docker
└── README_SIMPLE.md        # Это руководство
```

## ✅ Все исправлено!

Теперь запуск бота занимает всего одну команду:
- `./easy_start.sh` или `easy_start.bat`

Больше никаких сложных настроек!
"""
    
    try:
        with open("README_SIMPLE.md", "w", encoding="utf-8") as f:
            f.write(help_content)
        
        print("✅ Создано руководство: README_SIMPLE.md")
        return True
        
    except Exception as e:
        print(f"❌ Ошибка создания руководства: {e}")
        return False

def main():
    """Основная функция"""
    setup_logging()
    print_header()
    
    try:
        # Выполняем все шаги
        steps = [
            ("Проверка зависимостей", check_and_fix_dependencies),
            ("Установка пакетов", install_required_packages),
            ("Исправление базы данных", fix_database_issues),
            ("Создание скриптов запуска", create_simple_startup),
            ("Создание руководства", create_help_guide)
        ]
        
        success_count = 0
        for step_name, step_func in steps:
            print(f"\n{step_name}...")
            if step_func():
                success_count += 1
                print(f"✅ {step_name} - выполнено")
            else:
                print(f"❌ {step_name} - ошибка")
        
        print("\n" + "=" * 70)
        print(f"🎉 Настройка завершена! ({success_count}/{len(steps)} шагов)")
        print("=" * 70)
        
        print("\n📋 Что делать дальше:")
        print("1. Поместите файлы бота в папку LufHost/")
        print("2. Установите BOT_TOKEN в файле LufHost/.env")
        print("3. Запустите: ./easy_start.sh или easy_start.bat")
        print("\n💡 Теперь все просто! Один скрипт для запуска бота.")
        
    except KeyboardInterrupt:
        print("\n❌ Прервано пользователем")
    except Exception as e:
        print(f"\n❌ Неожиданная ошибка: {e}")
        logging.error(f"Критическая ошибка: {e}")

if __name__ == "__main__":
    main()