#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Docker VDS Manager
Менеджер Docker контейнеров для юзерботов
"""

import logging
import asyncio
import json
import subprocess
from typing import Dict, List, Optional, Any
from config import (
    DOCKER_HOST, DOCKER_NETWORK, DOCKER_IMAGE, DOCKER_BASE_PORT,
    SERVER_SSH_HOST, SERVER_SSH_USER, SERVER_SSH_PASSWORD,
    SERVER_PORTAINER_URL, SERVER_PORTAINER_USER, SERVER_PORTAINER_PASSWORD
)

logger = logging.getLogger(__name__)

class DockerVDSManager:
    """Менеджер Docker контейнеров"""
    
    def __init__(self):
        self.base_port = DOCKER_BASE_PORT
        self.network = DOCKER_NETWORK
        self.image = DOCKER_IMAGE
        self.containers = {}  # Кеш контейнеров
    
    async def create_container(self, user_id: int, container_name: str = None) -> Dict[str, Any]:
        """Создает новый контейнер для пользователя"""
        try:
            if not container_name:
                container_name = f"userbot_{user_id}_{int(asyncio.get_event_loop().time())}"
            
            # Находим свободный порт
            port = await self._find_free_port(user_id)
            
            # Создаем контейнер через SSH
            success = await self._execute_docker_command(
                f"docker run -d --name {container_name} -p {port}:8080 --restart=unless-stopped {self.image}"
            )
            
            if success:
                container_info = {
                    "name": container_name,
                    "port": port,
                    "user_id": user_id,
                    "status": "running",
                    "created_at": asyncio.get_event_loop().time(),
                    "url": f"http://{SERVER_SSH_HOST}:{port}"
                }
                
                # Сохраняем в кеш
                self.containers[container_name] = container_info
                
                logger.info(f"Создан контейнер {container_name} для пользователя {user_id}")
                
                return {
                    "success": True,
                    "container_name": container_name,
                    "port": port,
                    "url": f"http://{SERVER_SSH_HOST}:{port}",
                    "status": "running"
                }
            else:
                return {
                    "success": False,
                    "error": "Не удалось создать контейнер"
                }
            
        except Exception as e:
            logger.error(f"Ошибка создания контейнера для пользователя {user_id}: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    async def get_user_containers(self, user_id: int) -> List[Dict[str, Any]]:
        """Получает список контейнеров пользователя"""
        try:
            user_containers = []
            for name, info in self.containers.items():
                if info.get("user_id") == user_id:
                    user_containers.append({
                        "name": name,
                        "status": info.get("status", "unknown"),
                        "port": info.get("port"),
                        "url": info.get("url"),
                        "created_at": info.get("created_at")
                    })
            
            return user_containers
            
        except Exception as e:
            logger.error(f"Ошибка получения контейнеров пользователя {user_id}: {e}")
            return []
    
    async def manage_container(self, container_name: str, action: str) -> bool:
        """Управляет контейнером (start/stop/restart/remove)"""
        try:
            docker_actions = {
                "start": f"docker start {container_name}",
                "stop": f"docker stop {container_name}",
                "restart": f"docker restart {container_name}",
                "remove": f"docker rm -f {container_name}"
            }
            
            if action not in docker_actions:
                logger.warning(f"Неизвестное действие: {action}")
                return False
            
            # Выполняем команду через SSH
            success = await self._execute_docker_command(docker_actions[action])
            
            if success:
                # Обновляем кеш
                if container_name in self.containers:
                    if action == "remove":
                        del self.containers[container_name]
                    else:
                        self.containers[container_name]["status"] = "running" if action in ["start", "restart"] else "stopped"
                
                logger.info(f"Действие {action} выполнено для контейнера {container_name}")
            
            return success
            
        except Exception as e:
            logger.error(f"Ошибка управления контейнером {container_name}: {e}")
            return False
    
    async def get_container_logs(self, container_name: str) -> str:
        """Получает логи контейнера"""
        try:
            # Получаем логи через SSH
            command = f"docker logs {container_name} --tail 50"
            
            ssh_command = [
                "ssh",
                f"{SERVER_SSH_USER}@{SERVER_SSH_HOST}",
                command
            ]
            
            process = await asyncio.create_subprocess_exec(
                *ssh_command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await process.communicate()
            
            if process.returncode == 0:
                logs = stdout.decode()
                return logs if logs else "Логи пусты"
            else:
                return f"Ошибка получения логов: {stderr.decode()}"
            
        except Exception as e:
            logger.error(f"Ошибка получения логов контейнера {container_name}: {e}")
            return f"Ошибка получения логов: {e}"
    
    async def _find_free_port(self, user_id: int) -> int:
        """Находит свободный порт для контейнера"""
        base_port = self.base_port + (user_id % 1000)
        
        # Проверяем занятые порты
        used_ports = set()
        for container_info in self.containers.values():
            if container_info.get("port"):
                used_ports.add(container_info["port"])
        
        # Ищем свободный порт
        port = base_port
        while port in used_ports:
            port += 1
        
        return port
    
    async def _execute_docker_command(self, command: str) -> bool:
        """Выполняет Docker команду через SSH"""
        try:
            ssh_command = [
                "ssh",
                f"{SERVER_SSH_USER}@{SERVER_SSH_HOST}",
                command
            ]
            
            process = await asyncio.create_subprocess_exec(
                *ssh_command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await process.communicate()
            
            if process.returncode == 0:
                logger.info(f"Команда выполнена успешно: {command}")
                return True
            else:
                logger.error(f"Ошибка выполнения команды: {stderr.decode()}")
                return False
                
        except Exception as e:
            logger.error(f"Ошибка SSH подключения: {e}")
            return False

# Глобальный экземпляр менеджера
docker_manager = DockerVDSManager()

# Функции для совместимости с существующим кодом
async def create_userbot_for_telegram_user(user_id: int) -> Dict[str, Any]:
    """Создает юзербота для пользователя Telegram"""
    return await docker_manager.create_container(user_id)

async def get_user_containers_list(user_id: int) -> List[Dict[str, Any]]:
    """Получает список контейнеров пользователя"""
    return await docker_manager.get_user_containers(user_id)

async def manage_container(container_name: str, action: str) -> bool:
    """Управляет контейнером"""
    return await docker_manager.manage_container(container_name, action)

async def get_container_logs_for_user(container_name: str) -> str:
    """Получает логи контейнера"""
    return await docker_manager.get_container_logs(container_name)

async def delete_docker_container(container_name: str) -> bool:
    """Удаляет Docker контейнер"""
    return await docker_manager.manage_container(container_name, "remove")
