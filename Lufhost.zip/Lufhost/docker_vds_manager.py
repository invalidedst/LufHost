#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Docker VDS Manager для Telegram бота
Простое управление Docker контейнерами через SSH
"""

import asyncio
import paramiko
import logging
from typing import Dict, List, Optional
from datetime import datetime
import json

# Настройки VDS
VDS_HOST = "77.222.47.27"
VDS_USER = "root"
VDS_PASSWORD = "2chUenQFso^rpfRH"
VDS_PORT = 22

class DockerVDSManager:
    """Менеджер Docker контейнеров на VDS"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
    async def execute_ssh_command(self, command: str) -> tuple:
        """Выполнить команду через SSH"""
        try:
            # Создаем SSH подключение
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            
            # Подключаемся
            ssh.connect(
                hostname=VDS_HOST,
                username=VDS_USER,
                password=VDS_PASSWORD,
                port=VDS_PORT,
                timeout=30
            )
            
            # Выполняем команду
            stdin, stdout, stderr = ssh.exec_command(command)
            
            # Получаем результат
            output = stdout.read().decode('utf-8').strip()
            error = stderr.read().decode('utf-8').strip()
            exit_code = stdout.channel.recv_exit_status()
            
            # Закрываем соединение
            ssh.close()
            
            return output, error, exit_code
            
        except Exception as e:
            self.logger.error(f"Ошибка SSH: {e}")
            return "", str(e), 1
    
    async def find_free_port(self) -> int:
        """Найти свободный порт"""
        for port in range(10000, 20001):
            command = f"netstat -ln | grep :{port} || echo 'free'"
            output, error, exit_code = await self.execute_ssh_command(command)
            
            if "free" in output:
                return port
        
        return None
    
    async def create_userbot_container(self, user_id: int) -> Dict:
        """Создать контейнер для пользователя"""
        try:
            # Найти свободный порт
            port = await self.find_free_port()
            if not port:
                return {"success": False, "error": "Нет свободных портов"}
            
            # Имя контейнера
            container_name = f"userbot_{user_id}_{int(datetime.now().timestamp())}"
            
            # Команда создания контейнера
            docker_command = f"""
            docker run -d \
                --name {container_name} \
                --restart unless-stopped \
                -p {port}:8080 \
                -e USER_ID={user_id} \
                -e TELEGRAM_BOT_TOKEN=YOUR_TOKEN_HERE \
                python:3.9-slim \
                bash -c "
                    pip install aiogram aiohttp && 
                    echo 'Userbot для пользователя {user_id} запущен на порту {port}' &&
                    python -c '
import asyncio
from aiohttp import web
import os

async def hello(request):
    user_id = os.environ.get(\"USER_ID\", \"unknown\")
    return web.Response(text=f\"Userbot для пользователя {user_id} работает!\")

app = web.Application()
app.router.add_get(\"/\", hello)

if __name__ == \"__main__\":
    web.run_app(app, host=\"0.0.0.0\", port=8080)
                    '
                "
            """
            
            # Выполнить команду
            output, error, exit_code = await self.execute_ssh_command(docker_command)
            
            if exit_code == 0:
                return {
                    "success": True,
                    "container_name": container_name,
                    "port": port,
                    "user_id": user_id,
                    "url": f"http://{VDS_HOST}:{port}",
                    "container_id": output
                }
            else:
                return {
                    "success": False,
                    "error": error or "Ошибка создания контейнера"
                }
                
        except Exception as e:
            self.logger.error(f"Ошибка создания контейнера: {e}")
            return {"success": False, "error": str(e)}
    
    async def list_user_containers(self, user_id: int) -> List[Dict]:
        """Список контейнеров пользователя"""
        try:
            command = f"docker ps -a --filter name=userbot_{user_id} --format 'table {{{{.Names}}}}\t{{{{.Status}}}}\t{{{{.Ports}}}}'"
            output, error, exit_code = await self.execute_ssh_command(command)
            
            if exit_code == 0 and output:
                containers = []
                lines = output.split('\n')[1:]  # Пропускаем заголовок
                
                for line in lines:
                    if line.strip():
                        parts = line.split('\t')
                        if len(parts) >= 3:
                            containers.append({
                                "name": parts[0],
                                "status": parts[1],
                                "ports": parts[2]
                            })
                
                return containers
            
            return []
            
        except Exception as e:
            self.logger.error(f"Ошибка получения списка: {e}")
            return []
    
    async def start_container(self, container_name: str) -> bool:
        """Запустить контейнер"""
        try:
            command = f"docker start {container_name}"
            output, error, exit_code = await self.execute_ssh_command(command)
            return exit_code == 0
        except Exception as e:
            self.logger.error(f"Ошибка запуска: {e}")
            return False
    
    async def stop_container(self, container_name: str) -> bool:
        """Остановить контейнер"""
        try:
            command = f"docker stop {container_name}"
            output, error, exit_code = await self.execute_ssh_command(command)
            return exit_code == 0
        except Exception as e:
            self.logger.error(f"Ошибка остановки: {e}")
            return False
    
    async def remove_container(self, container_name: str) -> bool:
        """Удалить контейнер"""
        try:
            # Сначала остановим
            await self.stop_container(container_name)
            
            # Потом удалим
            command = f"docker rm {container_name}"
            output, error, exit_code = await self.execute_ssh_command(command)
            return exit_code == 0
        except Exception as e:
            self.logger.error(f"Ошибка удаления: {e}")
            return False
    
    async def get_container_logs(self, container_name: str) -> str:
        """Получить логи контейнера"""
        try:
            command = f"docker logs --tail 20 {container_name}"
            output, error, exit_code = await self.execute_ssh_command(command)
            
            if exit_code == 0:
                return output
            else:
                return error
                
        except Exception as e:
            self.logger.error(f"Ошибка получения логов: {e}")
            return str(e)

# Глобальный менеджер
docker_manager = DockerVDSManager()

# Функции для интеграции с ботом
async def create_userbot_for_telegram_user(user_id: int):
    """Создать юзербот для пользователя Telegram"""
    return await docker_manager.create_userbot_container(user_id)

async def get_user_containers_list(user_id: int):
    """Получить список контейнеров пользователя"""
    return await docker_manager.list_user_containers(user_id)

async def manage_container(container_name: str, action: str):
    """Управление контейнером (start/stop/remove)"""
    if action == "start":
        return await docker_manager.start_container(container_name)
    elif action == "stop":
        return await docker_manager.stop_container(container_name)
    elif action == "remove":
        return await docker_manager.remove_container(container_name)
    else:
        return False

async def get_container_logs_for_user(container_name: str):
    """Получить логи контейнера"""
    return await docker_manager.get_container_logs(container_name)

# Пример использования в боте
async def example_usage():
    """Пример использования"""
    user_id = 123456789
    
    # Создать контейнер
    print("Создаю контейнер...")
    result = await create_userbot_for_telegram_user(user_id)
    print(f"Результат: {result}")
    
    if result["success"]:
        print(f"Контейнер создан: {result['container_name']}")
        print(f"Доступ по адресу: {result['url']}")
        
        # Получить список контейнеров
        print("\nСписок контейнеров:")
        containers = await get_user_containers_list(user_id)
        for container in containers:
            print(f"- {container['name']}: {container['status']}")

if __name__ == "__main__":
    # Запуск примера
    asyncio.run(example_usage())