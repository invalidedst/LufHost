#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Fix Docker Issue - исправление проблем с Docker образами
"""

import docker
import logging
import tempfile
import os
from pathlib import Path

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DockerImageFixer:
    def __init__(self):
        try:
            self.client = docker.from_env()
            logger.info("Docker подключен успешно")
        except Exception as e:
            logger.error(f"Не удалось подключиться к Docker: {e}")
            self.client = None
    
    def create_userbot_image(self):
        """Создание образа юзербота локально"""
        if not self.client:
            logger.error("Docker недоступен")
            return False
        
        try:
            # Создаем временную директорию для сборки
            with tempfile.TemporaryDirectory() as temp_dir:
                temp_path = Path(temp_dir)
                
                # Создаем Dockerfile
                dockerfile_content = """
FROM python:3.10-slim

# Обновляем систему и устанавливаем зависимости
RUN apt-get update && apt-get install -y \\
    curl \\
    git \\
    && rm -rf /var/lib/apt/lists/*

# Создаем пользователя для бота
RUN groupadd -r botuser && useradd -r -g botuser botuser

# Устанавливаем Python пакеты
RUN pip install --no-cache-dir \\
    aiogram>=3.0.0 \\
    python-dotenv \\
    aiofiles \\
    aiohttp \\
    requests \\
    asyncio

# Создаем рабочую директорию
WORKDIR /app
RUN chown botuser:botuser /app

# Создаем базовый main.py
RUN echo 'import asyncio\\n\\
import logging\\n\\
import os\\n\\
from aiogram import Bot, Dispatcher\\n\\
from aiogram.filters import CommandStart\\n\\
from aiogram.types import Message\\n\\
\\n\\
logging.basicConfig(level=logging.INFO)\\n\\
logger = logging.getLogger(__name__)\\n\\
\\n\\
BOT_TOKEN = os.getenv("BOT_TOKEN")\\n\\
USER_ID = os.getenv("USER_ID", "unknown")\\n\\
\\n\\
if not BOT_TOKEN:\\n\\
    logger.error("BOT_TOKEN не установлен!")\\n\\
    exit(1)\\n\\
\\n\\
bot = Bot(token=BOT_TOKEN)\\n\\
dp = Dispatcher()\\n\\
\\n\\
@dp.message(CommandStart())\\n\\
async def start_command(message: Message):\\n\\
    await message.answer(f"Привет! Я юзербот пользователя {USER_ID}\\nВремя запуска: {os.getenv(\\'STARTUP_TIME\\', \\'неизвестно\\')}\\nВерсия: 1.0")\\n\\
\\n\\
@dp.message()\\n\\
async def echo_handler(message: Message):\\n\\
    if message.text:\\n\\
        await message.answer(f"Эхо: {message.text}")\\n\\
\\n\\
async def main():\\n\\
    logger.info(f"Запуск юзербота для пользователя {USER_ID}")\\n\\
    logger.info(f"Токен: {BOT_TOKEN[:10]}...")\\n\\
    try:\\n\\
        await dp.start_polling(bot)\\n\\
    except Exception as e:\\n\\
        logger.error(f"Ошибка: {e}")\\n\\
        await bot.close()\\n\\
\\n\\
if __name__ == "__main__":\\n\\
    asyncio.run(main())' > /app/main.py

# Создаем скрипт запуска
RUN echo '#!/bin/bash\\n\\
echo "🤖 Запуск юзербота..."\\n\\
echo "Пользователь: $USER_ID"\\n\\
echo "Время запуска: $(date)"\\n\\
export STARTUP_TIME="$(date)"\\n\\
\\n\\
if [ -z "$BOT_TOKEN" ]; then\\n\\
    echo "❌ ОШИБКА: BOT_TOKEN не установлен"\\n\\
    echo "Установите токен через переменные окружения"\\n\\
    exit 1\\n\\
fi\\n\\
\\n\\
echo "✅ Токен найден: ${BOT_TOKEN:0:10}..."\\n\\
echo "🚀 Запускаю бота..."\\n\\
python /app/main.py' > /app/start.sh

RUN chmod +x /app/start.sh
RUN chown -R botuser:botuser /app

USER botuser

EXPOSE 8080
CMD ["/app/start.sh"]
"""
                
                # Записываем Dockerfile
                dockerfile_path = temp_path / "Dockerfile"
                with open(dockerfile_path, 'w') as f:
                    f.write(dockerfile_content)
                
                # Строим образ
                logger.info("Создаю образ lufhost-userbot...")
                image, build_logs = self.client.images.build(
                    path=str(temp_path),
                    tag="lufhost-userbot:latest",
                    rm=True,
                    nocache=True
                )
                
                # Выводим логи сборки
                for log in build_logs:
                    if 'stream' in log:
                        print(log['stream'].strip())
                
                logger.info("✅ Образ lufhost-userbot:latest создан успешно")
                return True
                
        except Exception as e:
            logger.error(f"Ошибка создания образа: {e}")
            return False
    
    def test_container_creation(self):
        """Тестирование создания контейнера"""
        if not self.client:
            return False
        
        try:
            # Создаем тестовый контейнер
            container = self.client.containers.create(
                image="lufhost-userbot:latest",
                name="test-userbot",
                environment={
                    'BOT_TOKEN': 'test_token_123',
                    'USER_ID': 'test_user'
                },
                remove=True
            )
            
            logger.info("✅ Тестовый контейнер создан успешно")
            
            # Удаляем тестовый контейнер
            container.remove()
            
            return True
            
        except Exception as e:
            logger.error(f"Ошибка тестирования: {e}")
            return False
    
    def fix_all_docker_issues(self):
        """Исправление всех проблем с Docker"""
        logger.info("🔧 Исправляю проблемы с Docker...")
        
        if not self.client:
            logger.error("❌ Docker недоступен. Установите Docker:")
            logger.error("   sudo apt update && sudo apt install docker.io")
            logger.error("   sudo systemctl start docker")
            logger.error("   sudo usermod -aG docker $USER")
            return False
        
        # Создаем образ
        if not self.create_userbot_image():
            return False
        
        # Тестируем создание контейнера
        if not self.test_container_creation():
            return False
        
        logger.info("✅ Все проблемы с Docker исправлены!")
        return True

def main():
    fixer = DockerImageFixer()
    success = fixer.fix_all_docker_issues()
    
    if success:
        print("\n🎉 Docker настроен и готов к работе!")
        print("Теперь можно создавать контейнеры для юзерботов")
    else:
        print("\n❌ Не удалось исправить проблемы с Docker")
        print("Проверьте установку Docker и права доступа")

if __name__ == "__main__":
    main()