#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LufHost Inline Keyboards
Инлайн клавиатуры для бота
"""

from aiogram.types import InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder
import logging

from config import TARIFFS, CURRENCY_DEFAULT, PAYMENT_METHODS, HOST_SUPPORT_LINK, HOST_DONATE_LINK

# === ОСНОВНЫЕ МЕНЮ ===

def setup_main_menu_keyboard():
    """Главное меню LufHost"""
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="👤 Профиль", callback_data="profile"),
        InlineKeyboardButton(text="⚙️ Настройки", callback_data="settings")
    )
    builder.row(
        InlineKeyboardButton(text="🤖 Управление юзерботами", callback_data="userbots_menu")
    )
    builder.row(
        InlineKeyboardButton(text="💬 Поддержка", url=HOST_SUPPORT_LINK),
        InlineKeyboardButton(text="💸 Поддержать проект", url=HOST_DONATE_LINK)
    )
    return builder

def setup_profile_keyboard():
    """Клавиатура профиля"""
    builder = InlineKeyboardBuilder()
    builder.button(text="💰 Пополнить баланс", callback_data="top_up_balance")
    builder.button(text="🔙 Главное меню", callback_data="main_menu")
    builder.adjust(1)
    return builder

def setup_settings_keyboard():
    """Клавиатура настроек"""
    builder = InlineKeyboardBuilder()
    builder.button(text="💱 Выбрать валюту", callback_data="select_currency")
    builder.button(text="🔙 Главное меню", callback_data="main_menu")
    builder.adjust(1)
    return builder

# === СОГЛАШЕНИЕ ===

def setup_agreement_keyboard():
    """Клавиатура принятия соглашения"""
    builder = InlineKeyboardBuilder()
    builder.button(text="✅ Согласен", callback_data="agree_policy")
    builder.adjust(1)
    return builder

# === ПОПОЛНЕНИЕ БАЛАНСА ===

def setup_top_up_methods_keyboard():
    """Клавиатура способов пополнения"""
    builder = InlineKeyboardBuilder()
    
    # Добавляем доступные способы оплаты
    for method_key, method_info in PAYMENT_METHODS.items():
        if method_info.get('enabled', False):
            builder.button(
                text=method_info['name'], 
                callback_data=f"payment_method_{method_key}"
            )
    
    builder.button(text="🔙 Профиль", callback_data="profile")
    builder.adjust(1)
    return builder

def setup_payment_confirmation_keyboard(payment_id):
    """Клавиатура подтверждения платежа"""
    builder = InlineKeyboardBuilder()
    builder.button(text="❌ Отменить", callback_data=f"cancel_payment_{payment_id}")
    builder.adjust(1)
    return builder

# === АДМИН КЛАВИАТУРЫ ===

def setup_admin_keyboard(maintenance_enabled):
    """Административная клавиатура"""
    builder = InlineKeyboardBuilder()
    
    maintenance_text = "🔴 Выключить тех. работы" if maintenance_enabled else "🟡 Включить тех. работы"
    builder.button(text=maintenance_text, callback_data="toggle_maintenance")
    
    builder.adjust(1)
    return builder

def setup_admin_payment_review_keyboard(payment_id):
    """Клавиатура проверки платежа админом"""
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="✅ Одобрить", callback_data=f"approve_payment_{payment_id}"),
        InlineKeyboardButton(text="❌ Отклонить", callback_data=f"reject_payment_{payment_id}")
    )
    return builder

# === ВАЛЮТЫ ===

def setup_select_currency_keyboard():
    """Клавиатура выбора валюты"""
    builder = InlineKeyboardBuilder()
    builder.button(text="🇷🇺 RUB", callback_data="currency_rub")
    builder.button(text="🇺🇦 UAH", callback_data="currency_uah")
    builder.button(text="🇰🇿 KZT", callback_data="currency_kzt")
    builder.button(text="🇺🇸 USD", callback_data="currency_usd")
    builder.button(text="🔙 Настройки", callback_data="back_to_settings")
    builder.adjust(1)
    return builder

# === УПРАВЛЕНИЕ ЮЗЕРБОТАМИ ===

def setup_userbots_menu_keyboard():
    """Меню управления юзерботами"""
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="📋 Мои юзерботы", callback_data="list_userbots"),
        InlineKeyboardButton(text="💎 Купить юзербота", callback_data="buy_userbot")
    )
    builder.button(text="🔙 Главное меню", callback_data="main_menu")
    builder.adjust(2, 1)
    return builder

def setup_list_userbots_keyboard(containers):
    """Клавиатура списка юзерботов"""
    builder = InlineKeyboardBuilder()
    
    if containers:
        for container in containers:
            db_id = container.get('container_db_id')
            name = container.get('name', 'N/A')
            status = container.get('status', '?')
            if db_id is not None:
                button_text = f"{status} {name}"
                builder.button(text=button_text, callback_data=f"control_userbot_{db_id}")
            else:
                logging.warning(f"Пропуск контейнера без container_db_id: {container}")
    else:
        builder.button(text="💡 У вас нет юзерботов", callback_data="buy_userbot")

    builder.button(text="🔙 Управление", callback_data="userbots_menu")
    builder.adjust(1)
    return builder

def setup_control_userbot_keyboard(container_status, install_link, container_db_id):
    """Клавиатура управления контейнером"""
    builder = InlineKeyboardBuilder()
    
    # Кнопки управления
    if container_status == "🟢":
        builder.button(text="🔴 Выключить", callback_data=f"disable_userbot_{container_db_id}")
    else:
        builder.button(text="🟢 Включить", callback_data=f"enable_userbot_{container_db_id}")
    
    builder.button(text="🔄 Перезапустить", callback_data=f"restart_userbot_{container_db_id}")
    
    # Ссылка на установку
    if install_link and "N/A" not in install_link:
        builder.button(text="🔗 Установка", url=install_link)
    else:
        builder.button(text="🔗 Недоступна", callback_data="link_na_placeholder")
    
    builder.button(text="♻️ Переустановить", callback_data=f"confirm_reinstall_userbot_{container_db_id}")
    builder.button(text="🔙 К списку", callback_data="list_userbots")
    
    builder.adjust(2, 2, 1)
    return builder

def setup_reinstall_confirmation_keyboard(container_db_id):
    """Клавиатура подтверждения переустановки"""
    builder = InlineKeyboardBuilder()
    builder.button(text="♻️ Да, переустановить", callback_data=f"reinstall_userbot_{container_db_id}")
    builder.button(text="❌ Отмена", callback_data=f"cancel_reinstall_userbot_{container_db_id}")
    builder.adjust(1)
    return builder

# === ПОКУПКА ЮЗЕРБОТА ===

def setup_buy_userbot_keyboard():
    """Клавиатура выбора тарифа"""
    builder = InlineKeyboardBuilder()
    
    # Динамически добавляем кнопки тарифов
    for tariff_key, tariff_data in TARIFFS.items():
        if tariff_key != "Beta":
            # Эмодзи для тарифов
            tariff_emoji = ""
            if tariff_key == "lite":
                tariff_emoji = "🌀 "
            elif tariff_key == "standard":
                tariff_emoji = "🛠 "
            elif tariff_key == "premium":
                tariff_emoji = "⭐ "
            
            button_text = f"{tariff_emoji}{tariff_data['name']}"
            builder.button(text=button_text, callback_data=f"select_tariff_{tariff_key}")

    builder.button(text="🔙 Управление", callback_data="userbots_menu")
    builder.adjust(1)
    return builder

def setup_tariff_period_keyboard(tariff_key, currency=CURRENCY_DEFAULT):
    """Клавиатура выбора периода тарифа"""
    builder = InlineKeyboardBuilder()
    tariff_data = TARIFFS.get(tariff_key)
    
    if not tariff_data or not tariff_data.get("monthly_prices"):
        logging.error(f"Не найдены цены для тарифа '{tariff_key}'")
        builder.button(text="❌ Нет доступных периодов", callback_data="no_periods_placeholder")
    else:
        prices = tariff_data["monthly_prices"]
        for period_months in sorted(prices.keys()):
            period_info = prices[period_months]
            price = period_info['price']
            name = period_info['name']
            
            # Показываем экономию для длительных периодов
            if period_months > 1:
                monthly_price = prices[1]['price']
                total_regular = monthly_price * period_months
                savings = total_regular - price
                savings_percent = (savings / total_regular) * 100
                
                button_text = f"{name} - {price:.0f} {currency} (экономия {savings_percent:.0f}%)"
            else:
                button_text = f"{name} - {price:.0f} {currency}"
            
            builder.button(
                text=button_text,
                callback_data=f"period_{tariff_key}_{period_months}"
            )
    
    builder.button(text="🔙 К тарифам", callback_data="buy_userbot")
    builder.adjust(1)
    return builder