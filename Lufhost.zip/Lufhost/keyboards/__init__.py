#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LufHost Keyboards Module
Модуль клавиатур для бота
"""

from .inline import *
