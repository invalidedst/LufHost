#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LufHost Quick Setup
Быстрая настройка и запуск системы одной командой
"""

import os
import sys
import subprocess
import logging
from pathlib import Path

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def main():
    print("🚀 LufHost Quick Setup - Автоматическая настройка бота")
    print("=" * 60)
    
    try:
        # 1. Установка системных зависимостей
        print("📦 Устанавливаю системные зависимости...")
        subprocess.run(["apt", "update"], check=True, capture_output=True)
        subprocess.run(["apt", "install", "-y", "python3-venv", "python3-pip", "docker.io"], 
                      check=True, capture_output=True)
        print("✅ Системные зависимости установлены")
        
        # 2. Исправление базы данных
        print("🗄️ Исправляю базу данных...")
        result = subprocess.run([sys.executable, "database_fix.py"], 
                               capture_output=True, text=True)
        if result.returncode == 0:
            print("✅ База данных исправлена")
        else:
            print(f"⚠️ Предупреждение БД: {result.stderr}")
        
        # 3. Автоматическое развертывание
        print("🤖 Развертываю бота...")
        result = subprocess.run([sys.executable, "bot_deploy.py"], 
                               capture_output=True, text=True)
        if result.returncode == 0:
            print("✅ Бот развернут успешно")
        else:
            print(f"⚠️ Предупреждение развертывания: {result.stderr}")
        
        # 4. Создание упрощенного запуска
        print("📝 Создаю упрощенный запуск...")
        
        # Создаем простой скрипт запуска
        simple_start = """#!/bin/bash
echo "🚀 Запуск LufHost Bot..."

# Переходим в папку проекта
cd "$(dirname "$0")"

# Активируем виртуальное окружение
if [ -d "venv" ]; then
    source venv/bin/activate
    echo "✅ Виртуальное окружение активировано"
else
    echo "❌ Виртуальное окружение не найдено. Запустите: python3 quick_setup.py"
    exit 1
fi

# Проверяем наличие папки бота
if [ ! -d "LufHost" ]; then
    echo "❌ Папка LufHost не найдена"
    exit 1
fi

# Переходим в папку бота и запускаем
cd LufHost
echo "📂 Переход в папку LufHost"

# Проверяем наличие main.py
if [ ! -f "main.py" ]; then
    echo "❌ Файл main.py не найден"
    exit 1
fi

echo "🤖 Запускаю бота..."
python3 main.py
"""
        
        with open("start_bot.sh", "w") as f:
            f.write(simple_start)
        os.chmod("start_bot.sh", 0o755)
        
        # Создаем Windows версию
        windows_start = """@echo off
echo 🚀 Запуск LufHost Bot...

cd /d "%~dp0"

if exist "venv\\Scripts\\activate.bat" (
    call venv\\Scripts\\activate.bat
    echo ✅ Виртуальное окружение активировано
) else (
    echo ❌ Виртуальное окружение не найдено. Запустите: python quick_setup.py
    pause
    exit /b 1
)

if not exist "LufHost" (
    echo ❌ Папка LufHost не найдена
    pause
    exit /b 1
)

cd LufHost
echo 📂 Переход в папку LufHost

if not exist "main.py" (
    echo ❌ Файл main.py не найден
    pause
    exit /b 1
)

echo 🤖 Запускаю бота...
python main.py
pause
"""
        
        with open("start_bot.bat", "w") as f:
            f.write(windows_start)
        
        print("✅ Скрипты запуска созданы")
        
        # 5. Создание файла помощи
        help_content = """# LufHost - Быстрая помощь

## 🚀 Быстрый запуск

### Linux/Mac:
```bash
./start_bot.sh
```

### Windows:
```cmd
start_bot.bat
```

## 🔧 Настройка

1. Откройте файл `LufHost/.env`
2. Установите ваш BOT_TOKEN от @BotFather
3. Настройте другие параметры при необходимости

## 📝 Основные команды

- `python3 quick_setup.py` - Быстрая настройка всей системы
- `python3 bot_deploy.py` - Только развертывание бота
- `python3 database_fix.py` - Исправление проблем с БД

## 🐛 Решение проблем

### Проблема с соглашением
Если бот снова просит принять соглашение:
```bash
python3 database_fix.py
```

### Проблема с контейнерами
Если не создаются контейнеры:
1. Проверьте Docker: `docker --version`
2. Установите Docker: `sudo apt install docker.io`
3. Запустите: `python3 container_manager.py`

### Проблема с зависимостями
```bash
source venv/bin/activate
pip install aiogram python-dotenv
```

## 📁 Структура файлов

```
LufHost/
├── main.py              # Главный файл бота
├── config.py            # Конфигурация
├── handlers/            # Обработчики команд
├── keyboards/           # Клавиатуры
├── utils/               # Утилиты
└── .env                 # Настройки (создается автоматически)
```

## 🆘 Получение помощи

Если что-то не работает:
1. Проверьте логи в `bot_deploy.log`
2. Убедитесь что BOT_TOKEN корректный
3. Проверьте что все зависимости установлены

Удачи с LufHost! 🎉
"""
        
        with open("README_HELP.md", "w", encoding="utf-8") as f:
            f.write(help_content)
        
        print("✅ Файл помощи создан: README_HELP.md")
        
        print("\n" + "=" * 60)
        print("🎉 Настройка завершена!")
        print("=" * 60)
        print("\n📋 Что делать дальше:")
        print("1. Настройте BOT_TOKEN в файле LufHost/.env")
        print("2. Запустите бота: ./start_bot.sh")
        print("3. При проблемах смотрите README_HELP.md")
        print("\n💡 Теперь запуск занимает всего одну команду!")
        
    except subprocess.CalledProcessError as e:
        print(f"❌ Ошибка выполнения команды: {e}")
        print("Попробуйте запустить с sudo или проверьте права доступа")
    except Exception as e:
        print(f"❌ Неожиданная ошибка: {e}")
        logger.error(f"Ошибка в quick_setup: {e}")

if __name__ == "__main__":
    main()