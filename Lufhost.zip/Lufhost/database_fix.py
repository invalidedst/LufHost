#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LufHost Database Fix
Исправление проблем с базой данных и состоянием пользователей
"""

import sqlite3
import logging
import os
from pathlib import Path

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DatabaseFixer:
    def __init__(self, db_path="LufHost/database.db"):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(exist_ok=True)
    
    def init_database(self):
        """Инициализация базы данных с правильной схемой"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Создание таблицы пользователей с правильными полями
                cursor.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    user_id INTEGER PRIMARY KEY,
                    username TEXT,
                    first_name TEXT,
                    last_name TEXT,
                    balance REAL DEFAULT 0.0,
                    currency TEXT DEFAULT 'RUB',
                    agreed BOOLEAN DEFAULT FALSE,
                    reg_date TEXT DEFAULT CURRENT_TIMESTAMP,
                    is_active BOOLEAN DEFAULT TRUE
                )
                """)
                
                # Создание таблицы контейнеров
                cursor.execute("""
                CREATE TABLE IF NOT EXISTS containers (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    container_name TEXT UNIQUE,
                    container_id TEXT,
                    status TEXT DEFAULT 'stopped',
                    port INTEGER,
                    url TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users (user_id)
                )
                """)
                
                # Создание таблицы платежей
                cursor.execute("""
                CREATE TABLE IF NOT EXISTS payments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    amount REAL,
                    method TEXT,
                    status TEXT DEFAULT 'pending',
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users (user_id)
                )
                """)
                
                # Создание таблицы конфигурации
                cursor.execute("""
                CREATE TABLE IF NOT EXISTS config (
                    key TEXT PRIMARY KEY,
                    value TEXT,
                    description TEXT
                )
                """)
                
                # Вставка базовых настроек
                default_configs = [
                    ('maintenance_mode', 'false', 'Режим технических работ'),
                    ('maintenance_message', 'Ведутся технические работы', 'Сообщение о тех. работах'),
                    ('max_containers_per_user', '5', 'Максимум контейнеров на пользователя'),
                    ('auto_approve_payments', 'true', 'Автоматическое одобрение платежей')
                ]
                
                for key, value, desc in default_configs:
                    cursor.execute(
                        "INSERT OR IGNORE INTO config (key, value, description) VALUES (?, ?, ?)",
                        (key, value, desc)
                    )
                
                conn.commit()
                logger.info("База данных инициализирована")
                return True
                
        except Exception as e:
            logger.error(f"Ошибка инициализации БД: {e}")
            return False
    
    def fix_user_agreement_issue(self):
        """Исправление проблемы с соглашением пользователей"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Проверяем существует ли колонка agreed
                cursor.execute("PRAGMA table_info(users)")
                columns = [column[1] for column in cursor.fetchall()]
                
                if 'agreed' not in columns:
                    # Добавляем колонку agreed
                    cursor.execute("ALTER TABLE users ADD COLUMN agreed BOOLEAN DEFAULT FALSE")
                    logger.info("Добавлена колонка 'agreed' в таблицу users")
                
                # Устанавливаем agreed=TRUE для всех существующих пользователей
                cursor.execute("UPDATE users SET agreed = TRUE WHERE agreed IS NULL OR agreed = FALSE")
                affected = cursor.rowcount
                
                conn.commit()
                logger.info(f"Исправлено соглашение для {affected} пользователей")
                return True
                
        except Exception as e:
            logger.error(f"Ошибка исправления соглашений: {e}")
            return False
    
    def create_database_utils(self):
        """Создание файла утилит для работы с БД"""
        utils_content = """#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sqlite3
import logging
from datetime import datetime
from typing import Optional, Dict, List

DB_PATH = "database.db"

def get_connection():
    \"\"\"Получение подключения к БД\"\"\"
    return sqlite3.connect(DB_PATH)

def get_user_data(user_id: int) -> Optional[Dict]:
    \"\"\"Получение данных пользователя\"\"\"
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(\"\"\"
                SELECT user_id, username, first_name, last_name, balance, 
                       currency, agreed, reg_date, is_active
                FROM users WHERE user_id = ?
            \"\"\", (user_id,))
            
            row = cursor.fetchone()
            if row:
                return {
                    'user_id': row[0],
                    'username': row[1],
                    'first_name': row[2],
                    'last_name': row[3],
                    'balance': row[4] or 0.0,
                    'currency': row[5] or 'RUB',
                    'agreed': bool(row[6]),
                    'reg_date': row[7],
                    'is_active': bool(row[8])
                }
            return None
    except Exception as e:
        logging.error(f"Ошибка получения пользователя {user_id}: {e}")
        return None

def create_user_if_not_exists(user_id: int, username: str = None, 
                               first_name: str = None, last_name: str = None,
                               agreed: bool = False) -> bool:
    \"\"\"Создание пользователя если не существует\"\"\"
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            
            # Проверяем существование
            if get_user_data(user_id):
                return True
            
            # Создаем нового пользователя
            cursor.execute(\"\"\"
                INSERT INTO users (user_id, username, first_name, last_name, 
                                 balance, currency, agreed, reg_date, is_active)
                VALUES (?, ?, ?, ?, 0.0, 'RUB', ?, ?, TRUE)
            \"\"\", (user_id, username, first_name, last_name, agreed, 
                   datetime.now().isoformat()))
            
            conn.commit()
            logging.info(f"Создан пользователь {user_id}")
            return True
            
    except Exception as e:
        logging.error(f"Ошибка создания пользователя {user_id}: {e}")
        return False

def check_user_agreement(user_id: int) -> bool:
    \"\"\"Проверка принятия соглашения\"\"\"
    user_data = get_user_data(user_id)
    return user_data and user_data.get('agreed', False)

def record_user_agreement(user_id: int) -> bool:
    \"\"\"Запись принятия соглашения\"\"\"
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE users SET agreed = TRUE WHERE user_id = ?",
                (user_id,)
            )
            
            if cursor.rowcount == 0:
                # Пользователь не существует, создаем с соглашением
                return create_user_if_not_exists(user_id, agreed=True)
            
            conn.commit()
            logging.info(f"Соглашение записано для пользователя {user_id}")
            return True
            
    except Exception as e:
        logging.error(f"Ошибка записи соглашения для {user_id}: {e}")
        return False

def get_user_balance(user_id: int) -> float:
    \"\"\"Получение баланса пользователя\"\"\"
    user_data = get_user_data(user_id)
    return user_data.get('balance', 0.0) if user_data else 0.0

def set_user_balance(user_id: int, balance: float) -> bool:
    \"\"\"Установка баланса пользователя\"\"\"
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE users SET balance = ? WHERE user_id = ?",
                (balance, user_id)
            )
            conn.commit()
            
            if cursor.rowcount > 0:
                logging.info(f"Баланс пользователя {user_id} установлен: {balance}")
                return True
            else:
                logging.warning(f"Пользователь {user_id} не найден для обновления баланса")
                return False
                
    except Exception as e:
        logging.error(f"Ошибка установки баланса для {user_id}: {e}")
        return False

def get_user_currency(user_id: int) -> str:
    \"\"\"Получение валюты пользователя\"\"\"
    user_data = get_user_data(user_id)
    return user_data.get('currency', 'RUB') if user_data else 'RUB'

def set_user_currency(user_id: int, currency: str) -> bool:
    \"\"\"Установка валюты пользователя\"\"\"
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE users SET currency = ? WHERE user_id = ?",
                (currency, user_id)
            )
            conn.commit()
            return cursor.rowcount > 0
            
    except Exception as e:
        logging.error(f"Ошибка установки валюты для {user_id}: {e}")
        return False

def get_user_reg_date(user_id: int) -> str:
    \"\"\"Получение даты регистрации\"\"\"
    user_data = get_user_data(user_id)
    return user_data.get('reg_date', 'Не известно') if user_data else 'Не известно'

# Функции для работы с конфигурацией
def check_maintenance_mode() -> Dict:
    \"\"\"Проверка режима технических работ\"\"\"
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT value FROM config WHERE key = 'maintenance_mode'")
            row = cursor.fetchone()
            enabled = row and row[0].lower() == 'true'
            
            cursor.execute("SELECT value FROM config WHERE key = 'maintenance_message'")
            row = cursor.fetchone()
            message = row[0] if row else 'Ведутся технические работы'
            
            return {'enabled': enabled, 'message': message}
            
    except Exception as e:
        logging.error(f"Ошибка проверки режима обслуживания: {e}")
        return {'enabled': False, 'message': 'Ошибка проверки'}

# Функции для статистики
def get_all_users_stats() -> Dict:
    \"\"\"Статистика пользователей\"\"\"
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            
            cursor.execute("SELECT COUNT(*) FROM users")
            total = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM users WHERE agreed = TRUE")
            agreed = cursor.fetchone()[0]
            
            cursor.execute("SELECT AVG(balance), SUM(balance) FROM users")
            row = cursor.fetchone()
            avg_balance = row[0] or 0.0
            total_balance = row[1] or 0.0
            
            return {
                'total': total,
                'agreed': agreed,
                'avg_balance': avg_balance,
                'total_balance': total_balance
            }
            
    except Exception as e:
        logging.error(f"Ошибка получения статистики: {e}")
        return {'total': 0, 'agreed': 0, 'avg_balance': 0.0, 'total_balance': 0.0}

def get_all_containers_stats() -> Dict:
    \"\"\"Статистика контейнеров\"\"\"
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            
            cursor.execute("SELECT COUNT(*) FROM containers")
            total = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM containers WHERE status = 'running'")
            active = cursor.fetchone()[0]
            
            inactive = total - active
            
            return {
                'total': total,
                'active': active,
                'inactive': inactive
            }
            
    except Exception as e:
        logging.error(f"Ошибка получения статистики контейнеров: {e}")
        return {'total': 0, 'active': 0, 'inactive': 0}
"""
        
        utils_path = Path("LufHost/utils/database.py")
        utils_path.parent.mkdir(exist_ok=True)
        
        with open(utils_path, 'w', encoding='utf-8') as f:
            f.write(utils_content)
        
        logger.info(f"Создан файл утилит БД: {utils_path}")
        return True
    
    def run_all_fixes(self):
        """Запуск всех исправлений"""
        logger.info("Начинаю исправление базы данных...")
        
        success = True
        success &= self.init_database()
        success &= self.fix_user_agreement_issue() 
        success &= self.create_database_utils()
        
        if success:
            logger.info("Все исправления применены успешно!")
        else:
            logger.error("Некоторые исправления не удались")
        
        return success

if __name__ == "__main__":
    fixer = DatabaseFixer()
    fixer.run_all_fixes()