#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LufHost Bot Auto-Deploy Script
Автоматическое развертывание и управление Telegram-ботом
"""

import os
import sys
import subprocess
import logging
import json
import time
from pathlib import Path

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] %(levelname)s: %(message)s',
    handlers=[
        logging.FileHandler('bot_deploy.log'),
        logging.StreamHandler(sys.stdout)
    ]
)

class BotDeployer:
    def __init__(self):
        self.project_root = Path.cwd()
        self.venv_path = self.project_root / "venv"
        self.bot_path = self.project_root / "LufHost"
        self.requirements = [
            "aiogram>=3.0.0",
            "python-dotenv",
            "aiofiles",
            "aiohttp",
            "psycopg2-binary"
        ]
        
    def check_python_version(self):
        """Проверка версии Python"""
        try:
            version = subprocess.check_output([sys.executable, "--version"], text=True).strip()
            logging.info(f"Python версия: {version}")
            
            if sys.version_info < (3, 8):
                raise Exception("Требуется Python 3.8 или выше")
                
            return True
        except Exception as e:
            logging.error(f"Ошибка проверки Python: {e}")
            return False
    
    def setup_virtual_environment(self):
        """Создание и настройка виртуального окружения"""
        try:
            if self.venv_path.exists():
                logging.info("Виртуальное окружение уже существует")
                return True
                
            logging.info("Создаю виртуальное окружение...")
            subprocess.run([sys.executable, "-m", "venv", str(self.venv_path)], check=True)
            
            # Активация и обновление pip
            if os.name == 'nt':  # Windows
                pip_path = self.venv_path / "Scripts" / "pip"
                python_path = self.venv_path / "Scripts" / "python"
            else:  # Linux/Mac
                pip_path = self.venv_path / "bin" / "pip"
                python_path = self.venv_path / "bin" / "python"
            
            logging.info("Обновляю pip...")
            subprocess.run([str(python_path), "-m", "pip", "install", "--upgrade", "pip"], check=True)
            
            logging.info("Виртуальное окружение создано успешно")
            return True
            
        except subprocess.CalledProcessError as e:
            logging.error(f"Ошибка создания виртуального окружения: {e}")
            return False
    
    def install_dependencies(self):
        """Установка зависимостей"""
        try:
            if os.name == 'nt':
                pip_path = self.venv_path / "Scripts" / "pip"
            else:
                pip_path = self.venv_path / "bin" / "pip"
                
            logging.info("Устанавливаю зависимости...")
            for req in self.requirements:
                logging.info(f"Устанавливаю {req}...")
                subprocess.run([str(pip_path), "install", req], check=True)
            
            logging.info("Все зависимости установлены")
            return True
            
        except subprocess.CalledProcessError as e:
            logging.error(f"Ошибка установки зависимостей: {e}")
            return False
    
    def check_bot_files(self):
        """Проверка файлов бота"""
        try:
            if not self.bot_path.exists():
                logging.error(f"Папка бота не найдена: {self.bot_path}")
                return False
            
            main_file = self.bot_path / "main.py"
            if not main_file.exists():
                logging.error(f"Главный файл бота не найден: {main_file}")
                return False
            
            # Проверяем файлы конфигурации
            required_files = ["config.py", "handlers", "keyboards", "utils"]
            for file_name in required_files:
                file_path = self.bot_path / file_name
                if not file_path.exists():
                    logging.warning(f"Файл/папка не найдена: {file_path}")
            
            logging.info("Файлы бота проверены")
            return True
            
        except Exception as e:
            logging.error(f"Ошибка проверки файлов: {e}")
            return False
    
    def create_env_file(self):
        """Создание .env файла с настройками"""
        try:
            env_file = self.bot_path / ".env"
            
            if env_file.exists():
                logging.info(".env файл уже существует")
                return True
            
            # Базовые настройки
            env_content = """# LufHost Bot Configuration
BOT_TOKEN=your_bot_token_here
DATABASE_URL=your_database_url_here
ADMIN_IDS=123456789,987654321

# Redis (опционально)
REDIS_URL=redis://localhost:6379

# Webhook настройки (для продакшена)
WEBHOOK_URL=
WEBHOOK_PORT=8080

# Режим разработки
DEBUG=True
"""
            
            with open(env_file, 'w', encoding='utf-8') as f:
                f.write(env_content)
            
            logging.info(f".env файл создан: {env_file}")
            logging.warning("Не забудьте настроить переменные в .env файле!")
            return True
            
        except Exception as e:
            logging.error(f"Ошибка создания .env файла: {e}")
            return False
    
    def create_startup_script(self):
        """Создание скрипта запуска"""
        try:
            if os.name == 'nt':
                script_name = "start_bot.bat"
                python_path = self.venv_path / "Scripts" / "python"
                script_content = f"""@echo off
echo Starting LufHost Bot...
cd /d "{self.bot_path}"
"{python_path}" main.py
pause
"""
            else:
                script_name = "start_bot.sh"
                python_path = self.venv_path / "bin" / "python"
                script_content = f"""#!/bin/bash
echo "Starting LufHost Bot..."
cd "{self.bot_path}"
"{python_path}" main.py
"""
            
            script_path = self.project_root / script_name
            
            with open(script_path, 'w', encoding='utf-8') as f:
                f.write(script_content)
            
            if os.name != 'nt':
                os.chmod(script_path, 0o755)
            
            logging.info(f"Скрипт запуска создан: {script_path}")
            return True
            
        except Exception as e:
            logging.error(f"Ошибка создания скрипта запуска: {e}")
            return False
    
    def fix_agreement_issue(self):
        """Исправление проблемы с соглашением"""
        try:
            # Ищем файл с обработчиком соглашения
            common_file = self.bot_path / "handlers" / "common.py"
            if not common_file.exists():
                logging.warning("Файл common.py не найден")
                return True
            
            # Читаем содержимое
            with open(common_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Исправляем логику проверки соглашения
            if "check_user_agreement" in content:
                logging.info("Исправляю логику проверки соглашения...")
                
                # Добавляем более надежную проверку
                fix_content = """
# Исправление проблемы с повторным запросом соглашения
def check_user_agreement_fixed(user_id):
    try:
        user_data = get_user_data(user_id)
        if user_data and user_data.get('agreed', False):
            return True
        return False
    except Exception as e:
        logging.error(f"Ошибка проверки соглашения для {user_id}: {e}")
        return False

def record_user_agreement_fixed(user_id):
    try:
        # Создаем или обновляем пользователя с флагом согласия
        create_user_if_not_exists(user_id, agreed=True)
        logging.info(f"Соглашение записано для пользователя {user_id}")
        return True
    except Exception as e:
        logging.error(f"Ошибка записи соглашения для {user_id}: {e}")
        return False
"""
                
                # Добавляем исправления в конец файла
                with open(common_file, 'a', encoding='utf-8') as f:
                    f.write(fix_content)
                
                logging.info("Исправления добавлены в common.py")
            
            return True
            
        except Exception as e:
            logging.error(f"Ошибка исправления соглашения: {e}")
            return False
    
    def start_bot(self):
        """Запуск бота"""
        try:
            if os.name == 'nt':
                python_path = self.venv_path / "Scripts" / "python"
            else:
                python_path = self.venv_path / "bin" / "python"
            
            bot_main = self.bot_path / "main.py"
            
            logging.info("Запускаю бота...")
            
            # Запуск в фоновом режиме
            process = subprocess.Popen(
                [str(python_path), str(bot_main)],
                cwd=str(self.bot_path),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            # Ждем 5 секунд и проверяем статус
            time.sleep(5)
            
            if process.poll() is None:
                logging.info("Бот запущен успешно!")
                logging.info(f"PID процесса: {process.pid}")
                
                # Сохраняем PID для управления
                pid_file = self.project_root / "bot.pid"
                with open(pid_file, 'w') as f:
                    f.write(str(process.pid))
                
                return True
            else:
                stdout, stderr = process.communicate()
                logging.error(f"Бот завершился с ошибкой:")
                logging.error(f"STDOUT: {stdout}")
                logging.error(f"STDERR: {stderr}")
                return False
                
        except Exception as e:
            logging.error(f"Ошибка запуска бота: {e}")
            return False
    
    def deploy(self):
        """Полное развертывание бота"""
        logging.info("=" * 50)
        logging.info("Начинаю автоматическое развертывание LufHost Bot")
        logging.info("=" * 50)
        
        steps = [
            ("Проверка Python", self.check_python_version),
            ("Настройка виртуального окружения", self.setup_virtual_environment),
            ("Установка зависимостей", self.install_dependencies),
            ("Проверка файлов бота", self.check_bot_files),
            ("Создание .env файла", self.create_env_file),
            ("Создание скрипта запуска", self.create_startup_script),
            ("Исправление проблемы с соглашением", self.fix_agreement_issue),
        ]
        
        for step_name, step_func in steps:
            logging.info(f"Выполняю: {step_name}")
            if not step_func():
                logging.error(f"Ошибка на этапе: {step_name}")
                return False
            logging.info(f"✓ {step_name} - выполнено")
        
        logging.info("=" * 50)
        logging.info("Развертывание завершено успешно!")
        logging.info("=" * 50)
        logging.info("")
        logging.info("Следующие шаги:")
        logging.info("1. Настройте переменные в файле LufHost/.env")
        logging.info("2. Запустите бота командой: ./start_bot.sh (Linux/Mac) или start_bot.bat (Windows)")
        logging.info("3. Проверьте логи в файле bot_deploy.log")
        
        return True

if __name__ == "__main__":
    deployer = BotDeployer()
    
    if len(sys.argv) > 1 and sys.argv[1] == "--start":
        # Только запуск бота
        deployer.start_bot()
    else:
        # Полное развертывание
        deployer.deploy()