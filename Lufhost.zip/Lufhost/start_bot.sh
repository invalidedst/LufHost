#!/bin/bash

# Скрипт запуска LufHost бота
# Замените YOUR_BOT_TOKEN на реальный токен от @BotFather

export BOT_TOKEN="7951273022:AAGwlOtv_079CjAsNQ32zRKspEedwlCmOa4"
export ADMIN_IDS="7785427704"  # Замените на ваш Telegram ID

echo "Запуск LufHost бота..."
python main.py