#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LufHost User States
Состояния пользователей для FSM
"""

from aiogram.fsm.state import State, StatesGroup

# === ПОПОЛНЕНИЕ БАЛАНСА ===
class PaymentProcess(StatesGroup):
    """Процесс пополнения баланса"""
    waiting_for_amount = State()
    waiting_for_screenshot = State()

# === НАСТРОЙКИ ВАЛЮТЫ ===
class CurrencySettings(StatesGroup):
    """Настройки валюты"""
    waiting_for_currency_choice = State()

# === ПОКУПКА ЮЗЕРБОТА ===
class BuyUserbot(StatesGroup):
    """Покупка юзербота"""
    waiting_for_tariff_choice = State()
    waiting_for_period_choice = State()

# === АДМИНИСТРИРОВАНИЕ ===
class AdminStates(StatesGroup):
    """Административные состояния"""
    waiting_for_maintenance_message = State()
    waiting_for_user_id_for_balance = State()
    waiting_for_balance_amount = State()