#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LufHost Database Functions
Функции для работы с базой данных
"""

import sqlite3
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, List, Any
from contextlib import contextmanager

# Исправлено: DATABASE_FILE -> DATABASE_PATH
from config import DATABASE_PATH, BALANCE_DEFAULT, CURRENCY_DEFAULT, REG_DATE_DEFAULT

logger = logging.getLogger(__name__)

@contextmanager
def get_db_connection():
    """Контекстный менеджер для работы с базой данных"""
    conn = None
    try:
        conn = sqlite3.connect(DATABASE_PATH)
        conn.row_factory = sqlite3.Row
        yield conn
    except Exception as e:
        if conn:
            conn.rollback()
        logger.error(f"Ошибка базы данных: {e}")
        raise
    finally:
        if conn:
            conn.close()

def init_database():
    """Инициализация базы данных"""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        
        # Таблица пользователей
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                full_name TEXT,
                agreed_to_terms BOOLEAN DEFAULT 0,
                balance REAL DEFAULT 0.0,
                currency TEXT DEFAULT 'RUB',
                registration_date TEXT,
                last_activity TEXT,
                is_active BOOLEAN DEFAULT 1
            )
        ''')
        
        # Таблица контейнеров
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS containers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                docker_name TEXT UNIQUE,
                tariff TEXT,
                status TEXT DEFAULT 'creating',
                created_at TEXT,
                expires_at TEXT,
                port INTEGER,
                install_url TEXT,
                FOREIGN KEY (user_id) REFERENCES users (user_id)
            )
        ''')
        
        # Таблица платежей
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS payments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                amount REAL,
                currency TEXT DEFAULT 'RUB',
                payment_method TEXT,
                status TEXT DEFAULT 'pending',
                created_at TEXT,
                approved_at TEXT,
                approved_by INTEGER,
                FOREIGN KEY (user_id) REFERENCES users (user_id)
            )
        ''')
        
        # Таблица настроек системы
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS system_settings (
                key TEXT PRIMARY KEY,
                value TEXT,
                updated_at TEXT
            )
        ''')
        
        # Таблица логов админских действий
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS admin_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                admin_id INTEGER,
                action TEXT,
                target_user_id INTEGER,
                details TEXT,
                timestamp TEXT
            )
        ''')
        
        # Инициализация системных настроек
        cursor.execute('''
            INSERT OR IGNORE INTO system_settings (key, value, updated_at)
            VALUES ('maintenance_mode', 'false', ?)
        ''', (datetime.now().isoformat(),))
        
        cursor.execute('''
            INSERT OR IGNORE INTO system_settings (key, value, updated_at)
            VALUES ('maintenance_message', 'Ведутся технические работы. Скоро всё будет готово!', ?)
        ''', (datetime.now().isoformat(),))
        
        conn.commit()
        logger.info("База данных инициализирована")

# === ФУНКЦИИ ПОЛЬЗОВАТЕЛЕЙ ===

def create_user_if_not_exists(user_id: int, username: str = None, full_name: str = None, agreed: bool = False):
    """Создает пользователя если его нет в базе"""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        
        # Проверяем существование пользователя
        cursor.execute("SELECT user_id FROM users WHERE user_id = ?", (user_id,))
        if cursor.fetchone():
            return
        
        # Создаем нового пользователя
        cursor.execute('''
            INSERT INTO users (user_id, username, full_name, agreed_to_terms, balance, currency, registration_date, last_activity)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (user_id, username, full_name, agreed, BALANCE_DEFAULT, CURRENCY_DEFAULT, REG_DATE_DEFAULT, datetime.now().isoformat()))
        
        conn.commit()
        logger.info(f"Создан новый пользователь: {user_id}")

def check_user_agreement(user_id: int) -> bool:
    """Проверяет принятие пользовательского соглашения"""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT agreed_to_terms FROM users WHERE user_id = ?", (user_id,))
        result = cursor.fetchone()
        return bool(result and result[0]) if result else False

def record_user_agreement(user_id: int):
    """Записывает принятие пользовательского соглашения"""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE users SET agreed_to_terms = 1 WHERE user_id = ?", (user_id,))
        conn.commit()

def get_user_data(user_id: int) -> Optional[Dict]:
    """Получает данные пользователя"""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
        result = cursor.fetchone()
        return dict(result) if result else None

def get_user_balance(user_id: int) -> float:
    """Получает баланс пользователя"""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
        result = cursor.fetchone()
        return float(result[0]) if result else BALANCE_DEFAULT

def set_user_balance(user_id: int, balance: float) -> bool:
    """Устанавливает баланс пользователя"""
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE users SET balance = ? WHERE user_id = ?", (balance, user_id))
            conn.commit()
            return True
    except Exception as e:
        logger.error(f"Ошибка установки баланса для пользователя {user_id}: {e}")
        return False

def get_user_currency(user_id: int) -> str:
    """Получает валюту пользователя"""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT currency FROM users WHERE user_id = ?", (user_id,))
        result = cursor.fetchone()
        return result[0] if result else CURRENCY_DEFAULT

def set_user_currency(user_id: int, currency: str) -> bool:
    """Устанавливает валюту пользователя"""
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE users SET currency = ? WHERE user_id = ?", (currency, user_id))
            conn.commit()
            return True
    except Exception as e:
        logger.error(f"Ошибка установки валюты для пользователя {user_id}: {e}")
        return False

def get_user_reg_date(user_id: int) -> str:
    """Получает дату регистрации пользователя"""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT registration_date FROM users WHERE user_id = ?", (user_id,))
        result = cursor.fetchone()
        return result[0] if result else REG_DATE_DEFAULT

# === ФУНКЦИИ КОНТЕЙНЕРОВ ===

def create_container_record(user_id: int, docker_name: str, tariff: str, port: int, install_url: str = None, expires_at: str = None) -> int:
    """Создает запись о контейнере"""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO containers (user_id, docker_name, tariff, status, created_at, expires_at, port, install_url)
            VALUES (?, ?, ?, 'active', ?, ?, ?, ?)
        ''', (user_id, docker_name, tariff, datetime.now().isoformat(), expires_at, port, install_url))
        conn.commit()
        return cursor.lastrowid

def get_user_containers(user_id: int) -> List[Dict]:
    """Получает контейнеры пользователя"""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM containers WHERE user_id = ? ORDER BY created_at DESC", (user_id,))
        results = cursor.fetchall()
        return [dict(row) for row in results]

def get_container_by_id(container_id: int) -> Optional[Dict]:
    """Получает контейнер по ID"""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM containers WHERE id = ?", (container_id,))
        result = cursor.fetchone()
        return dict(result) if result else None

def update_container_status(container_id: int, status: str) -> bool:
    """Обновляет статус контейнера"""
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE containers SET status = ? WHERE id = ?", (status, container_id))
            conn.commit()
            return True
    except Exception as e:
        logger.error(f"Ошибка обновления статуса контейнера {container_id}: {e}")
        return False

def delete_container_from_db(container_id: int) -> bool:
    """Удаляет контейнер из базы данных"""
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM containers WHERE id = ?", (container_id,))
            conn.commit()
            return True
    except Exception as e:
        logger.error(f"Ошибка удаления контейнера {container_id}: {e}")
        return False

# === ФУНКЦИИ ПЛАТЕЖЕЙ ===

def create_payment_request(user_id: int, amount: float, payment_method: str) -> int:
    """Создает запрос на платеж"""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO payments (user_id, amount, payment_method, status, created_at)
            VALUES (?, ?, ?, 'pending', ?)
        ''', (user_id, amount, payment_method, datetime.now().isoformat()))
        conn.commit()
        return cursor.lastrowid

def get_payment_request(payment_id: int) -> Optional[Dict]:
    """Получает запрос на платеж"""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM payments WHERE id = ?", (payment_id,))
        result = cursor.fetchone()
        return dict(result) if result else None

def approve_payment_request(payment_id: int, approved_by: int = None) -> bool:
    """Одобряет платеж"""
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE payments 
                SET status = 'approved', approved_at = ?, approved_by = ?
                WHERE id = ?
            ''', (datetime.now().isoformat(), approved_by, payment_id))
            conn.commit()
            return True
    except Exception as e:
        logger.error(f"Ошибка одобрения платежа {payment_id}: {e}")
        return False

def reject_payment_request(payment_id: int, rejected_by: int = None) -> bool:
    """Отклоняет платеж"""
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE payments 
                SET status = 'rejected', approved_at = ?, approved_by = ?
                WHERE id = ?
            ''', (datetime.now().isoformat(), rejected_by, payment_id))
            conn.commit()
            return True
    except Exception as e:
        logger.error(f"Ошибка отклонения платежа {payment_id}: {e}")
        return False

# === ФУНКЦИИ СИСТЕМНЫХ НАСТРОЕК ===

def get_system_setting(key: str) -> Optional[str]:
    """Получает системную настройку"""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT value FROM system_settings WHERE key = ?", (key,))
        result = cursor.fetchone()
        return result[0] if result else None

def set_system_setting(key: str, value: str) -> bool:
    """Устанавливает системную настройку"""
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT OR REPLACE INTO system_settings (key, value, updated_at)
                VALUES (?, ?, ?)
            ''', (key, value, datetime.now().isoformat()))
            conn.commit()
            return True
    except Exception as e:
        logger.error(f"Ошибка установки настройки {key}: {e}")
        return False

def check_maintenance_mode() -> Dict[str, Any]:
    """Проверяет режим технических работ"""
    enabled = get_system_setting('maintenance_mode') == 'true'
    message = get_system_setting('maintenance_message') or 'Ведутся технические работы'
    return {"enabled": enabled, "message": message}

# === СТАТИСТИКА ===

def get_all_users_stats() -> Dict[str, Any]:
    """Получает статистику по всем пользователям"""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        
        # Общее количество пользователей
        cursor.execute("SELECT COUNT(*) FROM users")
        total = cursor.fetchone()[0]
        
        # Количество пользователей, принявших соглашение
        cursor.execute("SELECT COUNT(*) FROM users WHERE agreed_to_terms = 1")
        agreed = cursor.fetchone()[0]
        
        # Общий баланс всех пользователей
        cursor.execute("SELECT SUM(balance) FROM users")
        total_balance = cursor.fetchone()[0] or 0
        
        # Средний баланс
        avg_balance = total_balance / total if total > 0 else 0
        
        return {
            "total": total,
            "agreed": agreed,
            "total_balance": total_balance,
            "avg_balance": avg_balance
        }

def get_all_containers_stats() -> Dict[str, Any]:
    """Получает статистику по всем контейнерам"""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        
        # Общее количество контейнеров
        cursor.execute("SELECT COUNT(*) FROM containers")
        total = cursor.fetchone()[0]
        
        # Активные контейнеры
        cursor.execute("SELECT COUNT(*) FROM containers WHERE status = 'active'")
        active = cursor.fetchone()[0]
        
        # Неактивные контейнеры
        inactive = total - active
        
        return {
            "total": total,
            "active": active,
            "inactive": inactive
        }

def log_admin_action(admin_id: int, action: str, details: Dict = None):
    """Логирует действие администратора"""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO admin_logs (admin_id, action, target_user_id, details, timestamp)
            VALUES (?, ?, ?, ?, ?)
        ''', (admin_id, action, details.get('user_id') if details else None, 
              str(details) if details else None, datetime.now().isoformat()))
        conn.commit()
