#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LufHost Database Utilities
Утилиты для работы с JSON базой данных
"""

import json
import logging
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any

from config import DATABASE_FILE, BALANCE_DEFAULT, CURRENCY_DEFAULT, REG_DATE_DEFAULT

logger = logging.getLogger(__name__)

def load_database() -> Dict[str, Any]:
    """Загружает базу данных из JSON файла"""
    try:
        if not os.path.exists(DATABASE_FILE):
            # Создаем пустую базу данных
            default_db = {
                "users": {},
                "containers": {},
                "payments": {},
                "settings": {
                    "next_container_id": 1,
                    "next_payment_id": 1,
                    "maintenance": {
                        "enabled": False,
                        "message": "Проводятся технические работы. Ожидаемое время завершения: в течение часа."
                    }
                }
            }
            save_database(default_db)
            return default_db
        
        with open(DATABASE_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Ошибка загрузки базы данных: {e}")
        return {
            "users": {},
            "containers": {},
            "payments": {},
            "settings": {
                "next_container_id": 1,
                "next_payment_id": 1,
                "maintenance": {"enabled": False, "message": ""}
            }
        }

def save_database(db: Dict[str, Any]) -> bool:
    """Сохраняет базу данных в JSON файл"""
    try:
        with open(DATABASE_FILE, 'w', encoding='utf-8') as f:
            json.dump(db, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        logger.error(f"Ошибка сохранения базы данных: {e}")
        return False

def init_database():
    """Инициализирует базу данных"""
    db = load_database()
    logger.info("База данных LufHost инициализирована")
    return db

# === ПОЛЬЗОВАТЕЛИ ===

def create_user_if_not_exists(user_id: int, agreed: bool = False) -> bool:
    """Создает пользователя, если его нет в базе"""
    try:
        db = load_database()
        user_id_str = str(user_id)
        
        if user_id_str not in db["users"]:
            db["users"][user_id_str] = {
                "user_id": user_id,
                "balance": BALANCE_DEFAULT,
                "currency": CURRENCY_DEFAULT,
                "registration_date": datetime.now().strftime("%Y-%m-%d"),
                "agreement_accepted": agreed,
                "last_activity": datetime.now().isoformat(),
                "total_spent": 0.0,
                "containers_count": 0
            }
            save_database(db)
            logger.info(f"Создан новый пользователь: {user_id}")
        
        return True
    except Exception as e:
        logger.error(f"Ошибка создания пользователя {user_id}: {e}")
        return False

def check_user_agreement(user_id: int) -> bool:
    """Проверяет, принял ли пользователь соглашение"""
    try:
        db = load_database()
        user_id_str = str(user_id)
        
        if user_id_str in db["users"]:
            return db["users"][user_id_str].get("agreement_accepted", False)
        
        return False
    except Exception as e:
        logger.error(f"Ошибка проверки соглашения для {user_id}: {e}")
        return False

def record_user_agreement(user_id: int) -> bool:
    """Записывает принятие пользователем соглашения"""
    try:
        db = load_database()
        user_id_str = str(user_id)
        
        # Создаем пользователя, если его нет
        if user_id_str not in db["users"]:
            create_user_if_not_exists(user_id, agreed=True)
        else:
            db["users"][user_id_str]["agreement_accepted"] = True
            db["users"][user_id_str]["last_activity"] = datetime.now().isoformat()
            save_database(db)
        
        return True
    except Exception as e:
        logger.error(f"Ошибка записи соглашения для {user_id}: {e}")
        return False

def get_user_data(user_id: int) -> Optional[Dict[str, Any]]:
    """Получает данные пользователя"""
    try:
        db = load_database()
        user_id_str = str(user_id)
        
        if user_id_str in db["users"]:
            return db["users"][user_id_str]
        
        return None
    except Exception as e:
        logger.error(f"Ошибка получения данных пользователя {user_id}: {e}")
        return None

def get_user_balance(user_id: int) -> float:
    """Получает баланс пользователя"""
    try:
        user_data = get_user_data(user_id)
        if user_data:
            return float(user_data.get("balance", BALANCE_DEFAULT))
        return BALANCE_DEFAULT
    except Exception as e:
        logger.error(f"Ошибка получения баланса для {user_id}: {e}")
        return BALANCE_DEFAULT

def set_user_balance(user_id: int, new_balance: float) -> bool:
    """Устанавливает баланс пользователя"""
    try:
        db = load_database()
        user_id_str = str(user_id)
        
        if user_id_str in db["users"]:
            db["users"][user_id_str]["balance"] = float(new_balance)
            db["users"][user_id_str]["last_activity"] = datetime.now().isoformat()
            save_database(db)
            return True
        
        return False
    except Exception as e:
        logger.error(f"Ошибка установки баланса для {user_id}: {e}")
        return False

def get_user_currency(user_id: int) -> str:
    """Получает валюту пользователя"""
    try:
        user_data = get_user_data(user_id)
        if user_data:
            return user_data.get("currency", CURRENCY_DEFAULT)
        return CURRENCY_DEFAULT
    except Exception as e:
        logger.error(f"Ошибка получения валюты для {user_id}: {e}")
        return CURRENCY_DEFAULT

def set_user_currency(user_id: int, currency: str) -> bool:
    """Устанавливает валюту пользователя"""
    try:
        db = load_database()
        user_id_str = str(user_id)
        
        if user_id_str in db["users"]:
            db["users"][user_id_str]["currency"] = currency
            db["users"][user_id_str]["last_activity"] = datetime.now().isoformat()
            save_database(db)
            return True
        
        return False
    except Exception as e:
        logger.error(f"Ошибка установки валюты для {user_id}: {e}")
        return False

def get_user_reg_date(user_id: int) -> str:
    """Получает дату регистрации пользователя"""
    try:
        user_data = get_user_data(user_id)
        if user_data:
            return user_data.get("registration_date", REG_DATE_DEFAULT)
        return REG_DATE_DEFAULT
    except Exception as e:
        logger.error(f"Ошибка получения даты регистрации для {user_id}: {e}")
        return REG_DATE_DEFAULT

# === КОНТЕЙНЕРЫ ===

def get_user_containers(user_id: int) -> List[Dict[str, Any]]:
    """Получает список контейнеров пользователя"""
    try:
        db = load_database()
        containers = []
        
        for container_id, container_data in db["containers"].items():
            if container_data.get("user_id") == user_id:
                container_data["container_db_id"] = int(container_id)
                containers.append(container_data)
        
        return containers
    except Exception as e:
        logger.error(f"Ошибка получения контейнеров для {user_id}: {e}")
        return []

def get_container_by_id(container_db_id: int) -> Optional[Dict[str, Any]]:
    """Получает контейнер по ID"""
    try:
        db = load_database()
        container_id_str = str(container_db_id)
        
        if container_id_str in db["containers"]:
            container_data = db["containers"][container_id_str].copy()
            container_data["container_db_id"] = container_db_id
            return container_data
        
        return None
    except Exception as e:
        logger.error(f"Ошибка получения контейнера {container_db_id}: {e}")
        return None

def add_container_to_db(container_data: Dict[str, Any]) -> int:
    """Добавляет контейнер в базу данных"""
    try:
        db = load_database()
        
        # Получаем следующий ID
        next_id = db["settings"]["next_container_id"]
        db["settings"]["next_container_id"] += 1
        
        # Добавляем временные метки
        container_data["created_at"] = datetime.now().isoformat()
        container_data["updated_at"] = datetime.now().isoformat()
        
        # Сохраняем контейнер
        db["containers"][str(next_id)] = container_data
        
        # Обновляем счетчик контейнеров пользователя
        user_id_str = str(container_data["user_id"])
        if user_id_str in db["users"]:
            db["users"][user_id_str]["containers_count"] = db["users"][user_id_str].get("containers_count", 0) + 1
        
        save_database(db)
        logger.info(f"Добавлен контейнер {next_id} для пользователя {container_data['user_id']}")
        
        return next_id
    except Exception as e:
        logger.error(f"Ошибка добавления контейнера: {e}")
        return 0

def update_container_status(container_db_id: int, new_status: str) -> bool:
    """Обновляет статус контейнера"""
    try:
        db = load_database()
        container_id_str = str(container_db_id)
        
        if container_id_str in db["containers"]:
            db["containers"][container_id_str]["status"] = new_status
            db["containers"][container_id_str]["updated_at"] = datetime.now().isoformat()
            save_database(db)
            logger.info(f"Обновлен статус контейнера {container_db_id}: {new_status}")
            return True
        
        return False
    except Exception as e:
        logger.error(f"Ошибка обновления статуса контейнера {container_db_id}: {e}")
        return False

def remove_container_from_db(container_db_id: int) -> bool:
    """Удаляет контейнер из базы данных"""
    try:
        db = load_database()
        container_id_str = str(container_db_id)
        
        if container_id_str in db["containers"]:
            container_data = db["containers"][container_id_str]
            user_id_str = str(container_data["user_id"])
            
            # Удаляем контейнер
            del db["containers"][container_id_str]
            
            # Обновляем счетчик контейнеров пользователя
            if user_id_str in db["users"]:
                db["users"][user_id_str]["containers_count"] = max(0, db["users"][user_id_str].get("containers_count", 1) - 1)
            
            save_database(db)
            logger.info(f"Удален контейнер {container_db_id}")
            return True
        
        return False
    except Exception as e:
        logger.error(f"Ошибка удаления контейнера {container_db_id}: {e}")
        return False

# === ПЛАТЕЖИ ===

def create_payment_request(user_id: int, amount: float, payment_method: str) -> int:
    """Создает запрос на платеж"""
    try:
        db = load_database()
        
        # Получаем следующий ID
        next_id = db["settings"]["next_payment_id"]
        db["settings"]["next_payment_id"] += 1
        
        payment_data = {
            "payment_id": next_id,
            "user_id": user_id,
            "amount": float(amount),
            "payment_method": payment_method,
            "status": "pending",
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat(),
            "expires_at": (datetime.now() + timedelta(hours=24)).isoformat()
        }
        
        db["payments"][str(next_id)] = payment_data
        save_database(db)
        
        logger.info(f"Создан запрос на платеж {next_id} для пользователя {user_id}")
        return next_id
    except Exception as e:
        logger.error(f"Ошибка создания запроса на платеж: {e}")
        return 0

def get_payment_request(payment_id: int) -> Optional[Dict[str, Any]]:
    """Получает данные платежа"""
    try:
        db = load_database()
        payment_id_str = str(payment_id)
        
        if payment_id_str in db["payments"]:
            return db["payments"][payment_id_str]
        
        return None
    except Exception as e:
        logger.error(f"Ошибка получения платежа {payment_id}: {e}")
        return None

def approve_payment_request(payment_id: int) -> bool:
    """Одобряет платеж"""
    try:
        db = load_database()
        payment_id_str = str(payment_id)
        
        if payment_id_str in db["payments"]:
            db["payments"][payment_id_str]["status"] = "approved"
            db["payments"][payment_id_str]["updated_at"] = datetime.now().isoformat()
            save_database(db)
            logger.info(f"Одобрен платеж {payment_id}")
            return True
        
        return False
    except Exception as e:
        logger.error(f"Ошибка одобрения платежа {payment_id}: {e}")
        return False

def reject_payment_request(payment_id: int) -> bool:
    """Отклоняет платеж"""
    try:
        db = load_database()
        payment_id_str = str(payment_id)
        
        if payment_id_str in db["payments"]:
            db["payments"][payment_id_str]["status"] = "rejected"
            db["payments"][payment_id_str]["updated_at"] = datetime.now().isoformat()
            save_database(db)
            logger.info(f"Отклонен платеж {payment_id}")
            return True
        
        return False
    except Exception as e:
        logger.error(f"Ошибка отклонения платежа {payment_id}: {e}")
        return False

# === ТЕХНИЧЕСКИЕ РАБОТЫ ===

def check_maintenance_mode() -> Dict[str, Any]:
    """Проверяет режим технических работ"""
    try:
        db = load_database()
        maintenance = db["settings"].get("maintenance", {"enabled": False, "message": ""})
        return maintenance
    except Exception as e:
        logger.error(f"Ошибка проверки режима технических работ: {e}")
        return {"enabled": False, "message": ""}

# === СТАТИСТИКА ===

def get_all_users_stats() -> Dict[str, Any]:
    """Получает статистику пользователей"""
    try:
        db = load_database()
        users = db["users"]
        
        total_users = len(users)
        agreed_users = sum(1 for user in users.values() if user.get("agreement_accepted", False))
        total_balance = sum(user.get("balance", 0) for user in users.values())
        avg_balance = total_balance / total_users if total_users > 0 else 0
        
        return {
            "total": total_users,
            "agreed": agreed_users,
            "total_balance": total_balance,
            "avg_balance": avg_balance
        }
    except Exception as e:
        logger.error(f"Ошибка получения статистики пользователей: {e}")
        return {"total": 0, "agreed": 0, "total_balance": 0, "avg_balance": 0}

def get_all_containers_stats() -> Dict[str, Any]:
    """Получает статистику контейнеров"""
    try:
        db = load_database()
        containers = db["containers"]
        
        total_containers = len(containers)
        active_containers = sum(1 for container in containers.values() if container.get("status") == "🟢")
        inactive_containers = total_containers - active_containers
        
        return {
            "total": total_containers,
            "active": active_containers,
            "inactive": inactive_containers
        }
    except Exception as e:
        logger.error(f"Ошибка получения статистики контейнеров: {e}")
        return {"total": 0, "active": 0, "inactive": 0}


def get_container_by_id(container_id: int) -> Optional[Dict[str, Any]]:
    """Получает контейнер по ID"""
    try:
        db = load_database()
        container_str = str(container_id)
        if container_str in db["containers"]:
            container = db["containers"][container_str].copy()
            container["id"] = container_id
            return container
        return None
    except Exception as e:
        logger.error(f"Ошибка получения контейнера {container_id}: {e}")
        return None


def delete_container_from_db(container_id: int) -> bool:
    """Удаляет контейнер из базы данных"""
    try:
        db = load_database()
        container_str = str(container_id)
        if container_str in db["containers"]:
            del db["containers"][container_str]
            save_database(db)
            logger.info(f"Контейнер {container_id} удален из базы данных")
            return True
        return False
    except Exception as e:
        logger.error(f"Ошибка удаления контейнера {container_id}: {e}")
        return False


def get_all_containers() -> List[Dict[str, Any]]:
    """Получает список всех контейнеров"""
    try:
        db = load_database()
        containers = []
        for container_id, container_data in db["containers"].items():
            container = container_data.copy()
            container["id"] = int(container_id)
            containers.append(container)
        return containers
    except Exception as e:
        logger.error(f"Ошибка получения списка контейнеров: {e}")
        return []


def get_user_by_id(user_id: int) -> Optional[Dict[str, Any]]:
    """Получает пользователя по ID"""
    try:
        db = load_database()
        user_str = str(user_id)
        if user_str in db["users"]:
            user = db["users"][user_str].copy()
            user["id"] = user_id
            return user
        return None
    except Exception as e:
        logger.error(f"Ошибка получения пользователя {user_id}: {e}")
        return None