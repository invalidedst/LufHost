#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LufHost Admin Utilities
Административные утилиты
"""

import json
import logging
from typing import Dict, Any, Optional, List
from datetime import datetime

from config import ADMIN_IDS, MAINTENANCE_FILE
from .database import load_database, save_database

logger = logging.getLogger(__name__)

def is_admin(user_id: int) -> bool:
    """
    Проверяет, является ли пользователь администратором
    
    Args:
        user_id: ID пользователя
    
    Returns:
        True если пользователь админ, False иначе
    """
    return user_id in ADMIN_IDS

def load_maintenance_config() -> Dict[str, Any]:
    """
    Загружает конфигурацию технических работ
    
    Returns:
        Конфигурация технических работ
    """
    try:
        db = load_database()
        maintenance = db["settings"].get("maintenance", {
            "enabled": False,
            "message": "Проводятся технические работы. Ожидаемое время завершения: в течение часа.",
            "started_at": None,
            "started_by": None
        })
        return maintenance
    except Exception as e:
        logger.error(f"Ошибка загрузки конфигурации технических работ: {e}")
        return {
            "enabled": False,
            "message": "Проводятся технические работы. Ожидаемое время завершения: в течение часа.",
            "started_at": None,
            "started_by": None
        }

def save_maintenance_config(config: Dict[str, Any]) -> bool:
    """
    Сохраняет конфигурацию технических работ
    
    Args:
        config: Конфигурация для сохранения
    
    Returns:
        True если сохранение успешно, False иначе
    """
    try:
        db = load_database()
        db["settings"]["maintenance"] = config
        return save_database(db)
    except Exception as e:
        logger.error(f"Ошибка сохранения конфигурации технических работ: {e}")
        return False

def toggle_maintenance_mode(admin_id: Optional[int] = None) -> Dict[str, Any]:
    """
    Переключает режим технических работ
    
    Args:
        admin_id: ID администратора, который переключает режим
    
    Returns:
        Новая конфигурация технических работ
    """
    try:
        config = load_maintenance_config()
        
        # Переключаем режим
        config["enabled"] = not config.get("enabled", False)
        config["updated_at"] = datetime.now().isoformat()
        
        if config["enabled"]:
            config["started_at"] = datetime.now().isoformat()
            config["started_by"] = admin_id
            logger.info(f"Режим технических работ ВКЛЮЧЕН администратором {admin_id}")
        else:
            config["ended_at"] = datetime.now().isoformat()
            config["ended_by"] = admin_id
            logger.info(f"Режим технических работ ВЫКЛЮЧЕН администратором {admin_id}")
        
        save_maintenance_config(config)
        return config
        
    except Exception as e:
        logger.error(f"Ошибка переключения режима технических работ: {e}")
        return load_maintenance_config()

def set_maintenance_message(message: str, admin_id: Optional[int] = None) -> bool:
    """
    Устанавливает сообщение о технических работах
    
    Args:
        message: Новое сообщение
        admin_id: ID администратора
    
    Returns:
        True если сообщение установлено, False иначе
    """
    try:
        config = load_maintenance_config()
        config["message"] = message
        config["message_updated_at"] = datetime.now().isoformat()
        config["message_updated_by"] = admin_id
        
        success = save_maintenance_config(config)
        if success:
            logger.info(f"Сообщение о тех. работах обновлено администратором {admin_id}")
        
        return success
        
    except Exception as e:
        logger.error(f"Ошибка установки сообщения о технических работах: {e}")
        return False

def get_maintenance_status() -> Dict[str, Any]:
    """
    Получает статус технических работ
    
    Returns:
        Статус технических работ
    """
    return load_maintenance_config()

def enable_maintenance_mode(message: str = None, admin_id: Optional[int] = None) -> Dict[str, Any]:
    """
    Включает режим технических работ
    
    Args:
        message: Сообщение о технических работах
        admin_id: ID администратора
    
    Returns:
        Конфигурация технических работ
    """
    try:
        config = load_maintenance_config()
        config["enabled"] = True
        config["started_at"] = datetime.now().isoformat()
        config["started_by"] = admin_id
        config["updated_at"] = datetime.now().isoformat()
        
        if message:
            config["message"] = message
        
        save_maintenance_config(config)
        logger.info(f"Режим технических работ ВКЛЮЧЕН администратором {admin_id}")
        
        return config
        
    except Exception as e:
        logger.error(f"Ошибка включения режима технических работ: {e}")
        return load_maintenance_config()

def disable_maintenance_mode(admin_id: Optional[int] = None) -> Dict[str, Any]:
    """
    Выключает режим технических работ
    
    Args:
        admin_id: ID администратора
    
    Returns:
        Конфигурация технических работ
    """
    try:
        config = load_maintenance_config()
        config["enabled"] = False
        config["ended_at"] = datetime.now().isoformat()
        config["ended_by"] = admin_id
        config["updated_at"] = datetime.now().isoformat()
        
        save_maintenance_config(config)
        logger.info(f"Режим технических работ ВЫКЛЮЧЕН администратором {admin_id}")
        
        return config
        
    except Exception as e:
        logger.error(f"Ошибка выключения режима технических работ: {e}")
        return load_maintenance_config()

def get_admin_statistics() -> Dict[str, Any]:
    """
    Получает административную статистику
    
    Returns:
        Статистика для админ-панели
    """
    try:
        from .database import get_all_users_stats, get_all_containers_stats
        
        users_stats = get_all_users_stats()
        containers_stats = get_all_containers_stats()
        maintenance_config = load_maintenance_config()
        
        # Дополнительная статистика
        db = load_database()
        payments_stats = {
            "total_payments": len(db.get("payments", {})),
            "pending_payments": sum(1 for p in db.get("payments", {}).values() if p.get("status") == "pending"),
            "approved_payments": sum(1 for p in db.get("payments", {}).values() if p.get("status") == "approved"),
            "rejected_payments": sum(1 for p in db.get("payments", {}).values() if p.get("status") == "rejected")
        }
        
        return {
            "users": users_stats,
            "containers": containers_stats,
            "payments": payments_stats,
            "maintenance": maintenance_config,
            "system": {
                "database_size": len(str(db)),
                "last_updated": datetime.now().isoformat()
            }
        }
        
    except Exception as e:
        logger.error(f"Ошибка получения административной статистики: {e}")
        return {
            "users": {"total": 0, "agreed": 0, "total_balance": 0, "avg_balance": 0},
            "containers": {"total": 0, "active": 0, "inactive": 0},
            "payments": {"total_payments": 0, "pending_payments": 0, "approved_payments": 0, "rejected_payments": 0},
            "maintenance": {"enabled": False, "message": ""},
            "error": str(e)
        }

def log_admin_action(admin_id: int, action: str, details: Dict[str, Any] = None) -> bool:
    """
    Логирует действия администраторов
    
    Args:
        admin_id: ID администратора
        action: Выполненное действие
        details: Детали действия
    
    Returns:
        True если логирование успешно, False иначе
    """
    try:
        db = load_database()
        
        # Создаем секцию логов админов если её нет
        if "admin_logs" not in db:
            db["admin_logs"] = []
        
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "admin_id": admin_id,
            "action": action,
            "details": details or {},
            "log_id": len(db["admin_logs"]) + 1
        }
        
        db["admin_logs"].append(log_entry)
        
        # Ограничиваем количество логов (последние 1000)
        if len(db["admin_logs"]) > 1000:
            db["admin_logs"] = db["admin_logs"][-1000:]
        
        success = save_database(db)
        if success:
            logger.info(f"Действие администратора {admin_id} залогировано: {action}")
        
        return success
        
    except Exception as e:
        logger.error(f"Ошибка логирования действия администратора: {e}")
        return False

def get_admin_logs(limit: int = 50) -> List[Dict[str, Any]]:
    """
    Получает логи действий администраторов
    
    Args:
        limit: Максимальное количество записей
    
    Returns:
        Список логов действий
    """
    try:
        db = load_database()
        logs = db.get("admin_logs", [])
        
        # Возвращаем последние записи
        return logs[-limit:] if len(logs) > limit else logs
        
    except Exception as e:
        logger.error(f"Ошибка получения логов администраторов: {e}")
        return []

def cleanup_old_data(days_to_keep: int = 30) -> Dict[str, int]:
    """
    Очищает старые данные из базы
    
    Args:
        days_to_keep: Количество дней для хранения данных
    
    Returns:
        Статистика очистки
    """
    try:
        from datetime import timedelta
        
        db = load_database()
        cleanup_stats = {
            "payments_cleaned": 0,
            "logs_cleaned": 0,
            "containers_cleaned": 0
        }
        
        cutoff_date = datetime.now() - timedelta(days=days_to_keep)
        cutoff_iso = cutoff_date.isoformat()
        
        # Очищаем старые платежи
        payments_to_remove = []
        for payment_id, payment_data in db.get("payments", {}).items():
            if payment_data.get("created_at", "") < cutoff_iso and payment_data.get("status") != "pending":
                payments_to_remove.append(payment_id)
        
        for payment_id in payments_to_remove:
            del db["payments"][payment_id]
            cleanup_stats["payments_cleaned"] += 1
        
        # Очищаем старые логи
        logs = db.get("admin_logs", [])
        old_logs_count = len(logs)
        db["admin_logs"] = [log for log in logs if log.get("timestamp", "") >= cutoff_iso]
        cleanup_stats["logs_cleaned"] = old_logs_count - len(db["admin_logs"])
        
        # Сохраняем изменения
        save_database(db)
        
        logger.info(f"Очистка данных завершена: {cleanup_stats}")
        return cleanup_stats
        
    except Exception as e:
        logger.error(f"Ошибка очистки старых данных: {e}")
        return {"payments_cleaned": 0, "logs_cleaned": 0, "containers_cleaned": 0, "error": str(e)}

def backup_database(backup_path: str = None) -> bool:
    """
    Создает резервную копию базы данных
    
    Args:
        backup_path: Путь для сохранения резервной копии
    
    Returns:
        True если резервное копирование успешно, False иначе
    """
    try:
        import shutil
        
        if not backup_path:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = f"database_backup_{timestamp}.json"
        
        db = load_database()
        
        with open(backup_path, 'w', encoding='utf-8') as f:
            json.dump(db, f, ensure_ascii=False, indent=2)
        
        logger.info(f"Резервная копия базы данных создана: {backup_path}")
        return True
        
    except Exception as e:
        logger.error(f"Ошибка создания резервной копии: {e}")
        return False