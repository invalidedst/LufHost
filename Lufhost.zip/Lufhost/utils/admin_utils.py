#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LufHost Admin Utils
Утилиты для администрирования
"""

import logging
from typing import Dict, Any
from config import ADMIN_IDS
from .database import get_system_setting, set_system_setting

logger = logging.getLogger(__name__)

def is_admin(user_id: int) -> bool:
    """Проверяет, является ли пользователь администратором"""
    return user_id in ADMIN_IDS

def get_maintenance_status() -> Dict[str, Any]:
    """Получает статус технических работ"""
    enabled = get_system_setting('maintenance_mode') == 'true'
    message = get_system_setting('maintenance_message') or 'Ведутся технические работы'
    return {"enabled": enabled, "message": message}

def toggle_maintenance_mode() -> Dict[str, Any]:
    """Переключает режим технических работ"""
    current_status = get_maintenance_status()
    new_status = not current_status['enabled']
    
    set_system_setting('maintenance_mode', 'true' if new_status else 'false')
    
    return {
        "enabled": new_status,
        "message": current_status['message']
    }

def set_maintenance_message(message: str) -> bool:
    """Устанавливает сообщение о технических работах"""
    return set_system_setting('maintenance_message', message)

def log_admin_action(admin_id: int, action: str, details: Dict = None):
    """Логирует действие администратора"""
    from .database import log_admin_action as db_log_admin_action
    db_log_admin_action(admin_id, action, details)
    logger.info(f"Админ {admin_id} выполнил действие: {action}")
