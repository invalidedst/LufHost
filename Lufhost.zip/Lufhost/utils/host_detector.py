#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LufHost Host Detector
Утилиты для определения типа хоста и брендинга
"""

import logging
import re
from typing import Dict, Any

from config import HOST_NAME, SERVER_NAME

logger = logging.getLogger(__name__)

def get_host_info(container_name: str = "") -> Dict[str, Any]:
    """
    Определяет информацию о хосте на основе контейнера
    
    Args:
        container_name: Имя Docker контейнера
    
    Returns:
        Словарь с информацией о хосте
    """
    try:
        # Базовая информация о хосте
        host_info = {
            "name": HOST_NAME,
            "server": SERVER_NAME,
            "type": "container",
            "platform": "LufHost"
        }
        
        # Если передано имя контейнера, анализируем его
        if container_name:
            # Проверяем, является ли это контейнером LufHost
            if is_lufhost_container(container_name):
                host_info.update({
                    "name": HOST_NAME,
                    "description": f"Контейнер {HOST_NAME}",
                    "branding": "LufHost",
                    "detected": True
                })
            # Проверяем другие типы контейнеров
            elif is_docker_container(container_name):
                host_info.update({
                    "name": "Docker",
                    "description": "Стандартный Docker контейнер",
                    "branding": "Docker",
                    "detected": True
                })
            else:
                # Неопознанный тип контейнера
                host_info.update({
                    "name": "Unknown",
                    "description": "Неопознанный контейнер",
                    "branding": "Unknown",
                    "detected": False
                })
        
        logger.debug(f"Определен хост для контейнера '{container_name}': {host_info['name']}")
        return host_info
        
    except Exception as e:
        logger.error(f"Ошибка определения хоста для контейнера '{container_name}': {e}")
        return {
            "name": HOST_NAME,
            "server": SERVER_NAME,
            "type": "unknown",
            "platform": "LufHost",
            "error": str(e)
        }

def is_lufhost_container(container_name: str) -> bool:
    """
    Проверяет, является ли контейнер контейнером LufHost
    
    Args:
        container_name: Имя контейнера
    
    Returns:
        True если это контейнер LufHost, False иначе
    """
    try:
        if not container_name:
            return False
        
        # Паттерны имен контейнеров LufHost
        lufhost_patterns = [
            r"^lufhost_.*",  # Начинается с lufhost_
            r".*_lufhost_.*",  # Содержит _lufhost_
            r".*lufhost.*userbot.*",  # Содержит lufhost и userbot
        ]
        
        container_lower = container_name.lower()
        
        for pattern in lufhost_patterns:
            if re.match(pattern, container_lower):
                return True
        
        return False
        
    except Exception as e:
        logger.error(f"Ошибка проверки LufHost контейнера '{container_name}': {e}")
        return False

def is_docker_container(container_name: str) -> bool:
    """
    Проверяет, является ли контейнер стандартным Docker контейнером
    
    Args:
        container_name: Имя контейнера
    
    Returns:
        True если это стандартный Docker контейнер, False иначе
    """
    try:
        if not container_name:
            return False
        
        # Паттерны стандартных Docker контейнеров
        docker_patterns = [
            r"^[a-f0-9]{12}$",  # Стандартный ID контейнера Docker
            r"^[a-f0-9]{64}$",  # Полный ID контейнера Docker
            r".*_container_.*",  # Содержит _container_
            r"docker_.*",  # Начинается с docker_
        ]
        
        for pattern in docker_patterns:
            if re.match(pattern, container_name):
                return True
        
        return False
        
    except Exception as e:
        logger.error(f"Ошибка проверки Docker контейнера '{container_name}': {e}")
        return False

def format_host_info_for_userbot(container_name: str = "") -> str:
    """
    Форматирует информацию о хосте для отображения в юзерботе
    
    Args:
        container_name: Имя контейнера
    
    Returns:
        Отформатированная строка с информацией о хосте
    """
    try:
        host_info = get_host_info(container_name)
        
        # Форматируем вывод в зависимости от типа хоста
        if host_info.get("branding") == "LufHost":
            return f"Host: {HOST_NAME}"
        elif host_info.get("branding") == "Docker":
            return "Host: Docker"
        else:
            return f"Host: {host_info.get('name', 'Unknown')}"
            
    except Exception as e:
        logger.error(f"Ошибка форматирования информации о хосте: {e}")
        return f"Host: {HOST_NAME}"

def get_host_branding_emoji() -> str:
    """
    Возвращает эмодзи для брендинга хоста
    
    Returns:
        Эмодзи для LufHost
    """
    return "🏴‍☠️"  # Пиратский флаг в честь Луффи

def detect_host_from_environment() -> Dict[str, Any]:
    """
    Определяет хост из переменных окружения контейнера
    
    Returns:
        Информация о хосте из переменных окружения
    """
    try:
        import os
        
        # Проверяем переменные окружения LufHost
        lufhost_server = os.getenv("LUFHOST_SERVER")
        lufhost_port = os.getenv("LUFHOST_PORT")
        lufhost_tariff = os.getenv("LUFHOST_TARIFF")
        
        if lufhost_server or lufhost_port or lufhost_tariff:
            return {
                "detected": True,
                "host": HOST_NAME,
                "server": lufhost_server or SERVER_NAME,
                "port": lufhost_port,
                "tariff": lufhost_tariff,
                "source": "environment"
            }
        
        # Проверяем стандартные переменные Docker
        hostname = os.getenv("HOSTNAME", "")
        if hostname and len(hostname) == 12 and hostname.isalnum():
            return {
                "detected": True,
                "host": "Docker",
                "hostname": hostname,
                "source": "docker_hostname"
            }
        
        return {
            "detected": False,
            "host": HOST_NAME,  # По умолчанию LufHost
            "source": "default"
        }
        
    except Exception as e:
        logger.error(f"Ошибка определения хоста из окружения: {e}")
        return {
            "detected": False,
            "host": HOST_NAME,
            "error": str(e)
        }

def inject_host_info_to_userbot_config(container_name: str) -> Dict[str, Any]:
    """
    Внедряет информацию о хосте в конфигурацию юзербота
    
    Args:
        container_name: Имя контейнера
    
    Returns:
        Конфигурация с информацией о хосте
    """
    try:
        host_info = get_host_info(container_name)
        
        userbot_config = {
            "host_name": host_info["name"],
            "host_server": host_info["server"],
            "host_platform": host_info["platform"],
            "host_branding": get_host_branding_emoji(),
            "container_name": container_name
        }
        
        # Добавляем специфичные для LufHost настройки
        if host_info.get("branding") == "LufHost":
            userbot_config.update({
                "custom_host_command": True,
                "host_info_format": f"Host: {HOST_NAME}",
                "show_custom_branding": True
            })
        
        return userbot_config
        
    except Exception as e:
        logger.error(f"Ошибка внедрения информации о хосте: {e}")
        return {
            "host_name": HOST_NAME,
            "host_server": SERVER_NAME,
            "error": str(e)
        }

def get_host_status_emoji(status: str) -> str:
    """
    Возвращает эмодзи статуса для хоста
    
    Args:
        status: Статус (online, offline, maintenance, etc.)
    
    Returns:
        Соответствующий эмодзи
    """
    status_emojis = {
        "online": "🟢",
        "offline": "🔴",
        "maintenance": "🟡",
        "restarting": "🔄",
        "unknown": "❓",
        "error": "❌"
    }
    
    return status_emojis.get(status.lower(), "❓")
