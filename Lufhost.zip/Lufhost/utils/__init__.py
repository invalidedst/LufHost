#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LufHost Utils Module
Модуль утилит для LufHost бота
"""

from .database import *
from .docker_utils import *
from .host_detector import *
from .admin_utils import *

__all__ = [
    # Database utilities
    'init_database', 'load_database', 'save_database',
    'create_user_if_not_exists', 'check_user_agreement', 'record_user_agreement',
    'get_user_data', 'get_user_balance', 'set_user_balance',
    'get_user_currency', 'set_user_currency', 'get_user_reg_date',
    'get_user_containers', 'get_container_by_id', 'add_container_to_db',
    'update_container_status', 'remove_container_from_db',
    'create_payment_request', 'get_payment_request', 'approve_payment_request',
    'reject_payment_request', 'check_maintenance_mode',
    'get_all_users_stats', 'get_all_containers_stats',
    
    # Docker utilities
    'create_docker_container', 'control_docker_container', 'remove_docker_container',
    'get_container_status', 'get_container_logs', 'cleanup_expired_containers',
    'get_container_resource_usage', 'get_available_port',
    
    # Host detection utilities
    'get_host_info', 'is_lufhost_container', 'is_docker_container',
    'format_host_info_for_userbot', 'get_host_branding_emoji',
    'detect_host_from_environment', 'inject_host_info_to_userbot_config',
    'get_host_status_emoji',
    
    # Admin utilities
    'is_admin', 'load_maintenance_config', 'save_maintenance_config',
    'toggle_maintenance_mode', 'set_maintenance_message', 'get_maintenance_status',
    'enable_maintenance_mode', 'disable_maintenance_mode',
    'get_admin_statistics', 'log_admin_action', 'get_admin_logs',
    'cleanup_old_data', 'backup_database'
]
