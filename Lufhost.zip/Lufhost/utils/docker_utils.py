#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LufHost Docker Utilities
Утилиты для работы с Docker контейнерами
"""

import logging
import subprocess
import random
from typing import Dict, Any

from config import PORT_RANGE_START, PORT_RANGE_END, SERVER_NAME, TARIFFS

logger = logging.getLogger(__name__)

def get_available_port() -> int:
    """Получает доступный порт из диапазона"""
    try:
        # В реальной реализации здесь должна быть проверка занятых портов
        # Для демонстрации используем случайный порт из диапазона
        return random.randint(PORT_RANGE_START, PORT_RANGE_END)
    except Exception as e:
        logger.error(f"Ошибка получения доступного порта: {e}")
        return PORT_RANGE_START

def create_docker_container(container_name: str, tariff_key: str) -> Dict[str, Any]:
    """
    Создает Docker контейнер для юзербота
    
    Args:
        container_name: Имя контейнера
        tariff_key: Ключ тарифа (lite, standard, premium)
    
    Returns:
        Dict с результатом создания контейнера
    """
    try:
        tariff_info = TARIFFS.get(tariff_key, TARIFFS["lite"])
        port = get_available_port()
        
        # Генерируем уникальное имя Docker контейнера
        docker_name = f"lufhost_{container_name}_{port}"
        
        # Параметры ресурсов на основе тарифа
        memory_limit = tariff_info.get("ram", "512MB")
        cpu_limit = tariff_info.get("cpu", "0.5")
        
        # В реальной реализации здесь будет создание Docker контейнера
        # Пример команды:
        docker_command = [
            "docker", "run", "-d",
            "--name", docker_name,
            "-p", f"{port}:8080",
            "--memory", memory_limit,
            "--cpus", cpu_limit.split()[0],
            "--restart", "unless-stopped",
            "-e", f"LUFHOST_SERVER={SERVER_NAME}",
            "-e", f"LUFHOST_PORT={port}",
            "-e", f"LUFHOST_TARIFF={tariff_key}",
            "lufhost/userbot:latest"  # Образ юзербота
        ]
        
        # Для демонстрации просто логируем команду
        logger.info(f"Создание Docker контейнера: {' '.join(docker_command)}")
        
        # В реальной реализации:
        # result = subprocess.run(docker_command, capture_output=True, text=True)
        # if result.returncode != 0:
        #     raise Exception(f"Ошибка создания контейнера: {result.stderr}")
        
        # Имитируем успешное создание
        logger.info(f"Docker контейнер {docker_name} успешно создан на порту {port}")
        
        return {
            "success": True,
            "container_name": docker_name,
            "port": port,
            "tariff": tariff_key,
            "resources": {
                "memory": memory_limit,
                "cpu": cpu_limit
            }
        }
        
    except Exception as e:
        logger.error(f"Ошибка создания Docker контейнера {container_name}: {e}")
        return {
            "success": False,
            "error": str(e),
            "container_name": None,
            "port": None
        }

def control_docker_container(docker_name: str, action: str) -> bool:
    """
    Управляет Docker контейнером (start, stop, restart)
    
    Args:
        docker_name: Имя Docker контейнера
        action: Действие (start, stop, restart)
    
    Returns:
        True если операция успешна, False иначе
    """
    try:
        valid_actions = ["start", "stop", "restart"]
        if action not in valid_actions:
            raise ValueError(f"Недопустимое действие: {action}")
        
        docker_command = ["docker", action, docker_name]
        
        # Для демонстрации просто логируем команду
        logger.info(f"Выполнение Docker команды: {' '.join(docker_command)}")
        
        # В реальной реализации:
        # result = subprocess.run(docker_command, capture_output=True, text=True)
        # if result.returncode != 0:
        #     logger.error(f"Ошибка выполнения {action} для {docker_name}: {result.stderr}")
        #     return False
        
        # Имитируем успешное выполнение
        logger.info(f"Docker контейнер {docker_name} успешно {action}")
        return True
        
    except Exception as e:
        logger.error(f"Ошибка управления Docker контейнером {docker_name} ({action}): {e}")
        return False

def remove_docker_container(docker_name: str) -> bool:
    """
    Удаляет Docker контейнер
    
    Args:
        docker_name: Имя Docker контейнера
    
    Returns:
        True если операция успешна, False иначе
    """
    try:
        # Сначала останавливаем контейнер
        stop_command = ["docker", "stop", docker_name]
        remove_command = ["docker", "rm", docker_name]
        
        # Для демонстрации просто логируем команды
        logger.info(f"Остановка контейнера: {' '.join(stop_command)}")
        logger.info(f"Удаление контейнера: {' '.join(remove_command)}")
        
        # В реальной реализации:
        # subprocess.run(stop_command, capture_output=True)
        # result = subprocess.run(remove_command, capture_output=True, text=True)
        # if result.returncode != 0:
        #     logger.error(f"Ошибка удаления {docker_name}: {result.stderr}")
        #     return False
        
        # Имитируем успешное удаление
        logger.info(f"Docker контейнер {docker_name} успешно удален")
        return True
        
    except Exception as e:
        logger.error(f"Ошибка удаления Docker контейнера {docker_name}: {e}")
        return False

def get_container_status(docker_name: str) -> str:
    """
    Получает статус Docker контейнера
    
    Args:
        docker_name: Имя Docker контейнера
    
    Returns:
        Статус контейнера в виде эмодзи
    """
    try:
        status_command = ["docker", "inspect", "--format={{.State.Status}}", docker_name]
        
        # Для демонстрации просто логируем команду
        logger.debug(f"Проверка статуса: {' '.join(status_command)}")
        
        # В реальной реализации:
        # result = subprocess.run(status_command, capture_output=True, text=True)
        # if result.returncode != 0:
        #     return "❓"
        # 
        # status = result.stdout.strip()
        # if status == "running":
        #     return "🟢"
        # elif status == "exited":
        #     return "🔴"
        # elif status == "restarting":
        #     return "🔄"
        # else:
        #     return "❓"
        
        # Имитируем работающий контейнер
        return "🟢"
        
    except Exception as e:
        logger.error(f"Ошибка получения статуса контейнера {docker_name}: {e}")
        return "❓"


# Псевдоним для совместимости
def delete_docker_container(docker_name: str) -> bool:
    """
    Псевдоним для remove_docker_container для совместимости
    """
    return remove_docker_container(docker_name)

def get_container_logs(docker_name: str, lines: int = 50) -> str:
    """
    Получает логи Docker контейнера
    
    Args:
        docker_name: Имя Docker контейнера
        lines: Количество последних строк
    
    Returns:
        Логи контейнера
    """
    try:
        logs_command = ["docker", "logs", "--tail", str(lines), docker_name]
        
        # Для демонстрации просто логируем команду
        logger.debug(f"Получение логов: {' '.join(logs_command)}")
        
        # В реальной реализации:
        # result = subprocess.run(logs_command, capture_output=True, text=True)
        # if result.returncode != 0:
        #     return f"Ошибка получения логов: {result.stderr}"
        # 
        # return result.stdout
        
        # Имитируем логи
        return f"[LufHost] Контейнер {docker_name} запущен успешно\n[LufHost] Юзербот готов к работе"
        
    except Exception as e:
        logger.error(f"Ошибка получения логов контейнера {docker_name}: {e}")
        return f"Ошибка получения логов: {e}"

def cleanup_expired_containers():
    """Очищает истекшие контейнеры (запускается по расписанию)"""
    try:
        # В реальной реализации здесь будет проверка истекших подписок
        # и удаление соответствующих контейнеров
        logger.info("Запуск очистки истекших контейнеров")
        
        # Пример команды для получения всех контейнеров LufHost
        # list_command = ["docker", "ps", "-a", "--filter", "name=lufhost_*", "--format", "{{.Names}}"]
        # result = subprocess.run(list_command, capture_output=True, text=True)
        # containers = result.stdout.strip().split('\n') if result.stdout.strip() else []
        
        # Проверяем каждый контейнер на истечение подписки
        # и удаляем истекшие
        
        logger.info("Очистка истекших контейнеров завершена")
        
    except Exception as e:
        logger.error(f"Ошибка очистки истекших контейнеров: {e}")

def get_container_resource_usage(docker_name: str) -> Dict[str, Any]:
    """
    Получает информацию об использовании ресурсов контейнера
    
    Args:
        docker_name: Имя Docker контейнера
    
    Returns:
        Словарь с информацией об использовании ресурсов
    """
    try:
        stats_command = ["docker", "stats", "--no-stream", "--format", 
                        "table {{.CPUPerc}}\t{{.MemUsage}}\t{{.NetIO}}", docker_name]
        
        # Для демонстрации просто логируем команду
        logger.debug(f"Получение статистики: {' '.join(stats_command)}")
        
        # В реальной реализации:
        # result = subprocess.run(stats_command, capture_output=True, text=True)
        # if result.returncode != 0:
        #     return {"error": result.stderr}
        
        # Имитируем статистику ресурсов
        return {
            "cpu_percent": "15.32%",
            "memory_usage": "245.2MiB / 512MiB",
            "memory_percent": "47.9%",
            "network_io": "1.2MB / 2.5MB"
        }
        
    except Exception as e:
        logger.error(f"Ошибка получения статистики контейнера {docker_name}: {e}")
        return {"error": str(e)}