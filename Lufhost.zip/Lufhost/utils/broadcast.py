# --- START OF FILE utils/broadcast.py ---
import asyncio
import logging
from aiogram import Bot
from aiogram.exceptions import TelegramForbiddenError, TelegramBadRequest, TelegramRetryAfter
from typing import List # Добавим импорт List

# --- Измененная сигнатура: принимает список ID ---
async def send_broadcast(bot: Bot, user_ids: List[int], text: str, parse_mode: str = "HTML"):
    """Sends a message to all users in the provided list of IDs."""
    count = 0
    failed = 0
    blocked = 0
    # user_ids уже является списком

    total_users = len(user_ids)

    logging.info(f"[Broadcast] Функция вызвана. Цель: {total_users} пользователей. ID: {user_ids}")

    if not user_ids:
        logging.warning("[Broadcast] Список ID пользователей пуст. Рассылка невозможна.")
        return count, failed, blocked

    logging.info(f"[Broadcast] Начинаю итерацию по {total_users} пользователям для рассылки...")

    # --- Цикл теперь идет напрямую по user_ids ---
    for i, user_id in enumerate(user_ids, 1):
        logging.info(f"[Broadcast] Попытка {i}/{total_users}: Отправка пользователю {user_id}")
        try:
            await bot.send_message(user_id, text, parse_mode=parse_mode, disable_web_page_preview=True)
            count += 1
            logging.info(f"[Broadcast] Успешно отправлено пользователю {user_id}")
        except TelegramForbiddenError:
            logging.warning(f"[Broadcast] Пользователь {user_id} заблокировал бота.")
            failed += 1
            blocked += 1
        except TelegramBadRequest as e:
            logging.warning(f"[Broadcast] Не удалось отправить сообщение пользователю {user_id}: {e}")
            failed += 1
        except TelegramRetryAfter as e:
            logging.warning(f"[Broadcast] Превышен лимит Telegram для user {user_id}. Ожидание {e.retry_after} секунд...")
            await asyncio.sleep(e.retry_after)
            try:
                logging.info(f"[Broadcast] Повторная попытка отправки пользователю {user_id} после ожидания.")
                await bot.send_message(user_id, text, parse_mode=parse_mode, disable_web_page_preview=True)
                count += 1
                logging.info(f"[Broadcast] Успешно отправлено (повторно) пользователю {user_id}.")
            except Exception as retry_e:
                logging.error(f"[Broadcast] Ошибка при повторной отправке пользователю {user_id}: {retry_e}")
                failed += 1
        except Exception as e:
            logging.error(f"[Broadcast] Непредвиденная ошибка при отправке сообщения пользователю {user_id}: {e}", exc_info=True)
            failed += 1

        # Задержка
        if i % 25 == 0:
            logging.debug(f"[Broadcast] Пауза после {i} сообщений...")
            await asyncio.sleep(1)
        elif i % 10 == 0:
             await asyncio.sleep(0.2)

    logging.info(f"[Broadcast] Итерация по пользователям завершена.")
    logging.info(f"[Broadcast] Итог рассылки. Всего цель: {total_users}, Отправлено успешно: {count}, Ошибок: {failed} (Из них заблокировали: {blocked})")
    return count, failed, blocked
# --- END OF FILE utils/broadcast.py ---