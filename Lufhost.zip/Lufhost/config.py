#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LufHost Configuration
Simplified configuration file
"""

import os

# =============================================================================
# BASIC SETTINGS
# =============================================================================

# Bot token from BotFather
BOT_TOKEN = os.getenv("BOT_TOKEN", "7951273022:AAGwlOtv_079CjAsNQ32zRKspEedwlCmOa4")

# Admin user IDs (comma-separated)
ADMIN_IDS = [int(x.strip()) for x in os.getenv("ADMIN_IDS", "7785427704").split(",")]

# Host information
HOST_NAME = os.getenv("HOST_NAME", "LufHost")
HOST_DESCRIPTION = os.getenv("HOST_DESCRIPTION", "Надежный хостинг юзерботов Telegram")
SERVER_LOCATION = os.getenv("SERVER_LOCATION", "Москва, RU")

# =============================================================================
# DATABASE SETTINGS
# =============================================================================

DATABASE_PATH = os.getenv("DATABASE_PATH", "lufhost.db")

# =============================================================================
# CONTAINER SETTINGS
# =============================================================================

# Maximum containers per user
MAX_CONTAINERS_PER_USER = int(os.getenv("MAX_CONTAINERS_PER_USER", "5"))

# Resource monitoring settings
CPU_THRESHOLD = float(os.getenv("CPU_THRESHOLD", "35.0"))  # CPU threshold in %
MAX_VIOLATIONS = int(os.getenv("MAX_VIOLATIONS", "2"))  # Max violations before deletion

# Container port range
CONTAINER_PORT_START = int(os.getenv("CONTAINER_PORT_START", "8000"))
CONTAINER_PORT_END = int(os.getenv("CONTAINER_PORT_END", "9000"))

# =============================================================================
# PAYMENT SETTINGS
# =============================================================================

# Payment methods
PAYMENT_METHODS = {
    "qiwi": {
        "name": "💳 QIWI",
        "number": "+79999999999",
        "enabled": True
    },
    "card": {
        "name": "💳 Банковская карта",
        "number": "2202 2020 2020 2020",
        "enabled": True
    },
    "crypto": {
        "name": "₿ Криптовалюта",
        "number": "TRX: TVN3fJ3kq9j3kq9j3kq9j3kq9j3kq9j3kq",
        "enabled": False
    }
}

# Auto-approve payments (for testing)
AUTO_APPROVE_PAYMENTS = os.getenv("AUTO_APPROVE_PAYMENTS", "False").lower() == "true"

# =============================================================================
# TARIFF SETTINGS
# =============================================================================

TARIFFS = {
    "lite": {
        "name": "Lite",
        "description": "Базовый тариф",
        "ram": "512MB",
        "cpu": "1 Core",
        "storage": "5GB",
        "monthly_prices": {
            1: {"name": "1 месяц", "price": 100.0},
            3: {"name": "3 месяца", "price": 270.0},
            6: {"name": "6 месяцев", "price": 500.0},
            12: {"name": "1 год", "price": 900.0}
        }
    },
    "standard": {
        "name": "Standard",
        "description": "Стандартный тариф",
        "ram": "1GB",
        "cpu": "2 Cores",
        "storage": "10GB",
        "monthly_prices": {
            1: {"name": "1 месяц", "price": 200.0},
            3: {"name": "3 месяца", "price": 540.0},
            6: {"name": "6 месяцев", "price": 1000.0},
            12: {"name": "1 год", "price": 1800.0}
        }
    },
    "premium": {
        "name": "Premium",
        "description": "Премиум тариф",
        "ram": "2GB",
        "cpu": "4 Cores",
        "storage": "20GB",
        "monthly_prices": {
            1: {"name": "1 месяц", "price": 400.0},
            3: {"name": "3 месяца", "price": 1080.0},
            6: {"name": "6 месяцев", "price": 2000.0},
            12: {"name": "1 год", "price": 3600.0}
        }
    }
}

# =============================================================================
# DEFAULT VALUES
# =============================================================================

BALANCE_DEFAULT = 0.0
CURRENCY_DEFAULT = "RUB"
REG_DATE_DEFAULT = "2025-01-01"

# =============================================================================
# LINKS
# =============================================================================

HOST_SUPPORT_LINK = os.getenv("HOST_SUPPORT_LINK", "https://t.me/lufhost_support")
HOST_DONATE_LINK = os.getenv("HOST_DONATE_LINK", "https://t.me/lufhost_donate")

# =============================================================================
# IMAGES (Optional)
# =============================================================================

IMG_MAIN = os.getenv("IMG_MAIN", "images/main.jpg")
IMG_PROFILE = os.getenv("IMG_PROFILE", "images/profile.jpg")
IMG_SETTINGS = os.getenv("IMG_SETTINGS", "images/settings.jpg")
IMG_USERBOTS_MENU = os.getenv("IMG_USERBOTS_MENU", "images/userbots_menu.jpg")
IMG_USERBOTS_LIST = os.getenv("IMG_USERBOTS_LIST", "images/userbots_list.jpg")
IMG_USERBOTS_PANEL = os.getenv("IMG_USERBOTS_PANEL", "images/userbots_panel.jpg")
IMG_BUY_USERBOT = os.getenv("IMG_BUY_USERBOT", "images/buy_userbot.jpg")

# =============================================================================
# LOGGING
# =============================================================================

LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")