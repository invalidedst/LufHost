#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LufHost Configuration
Конфигурационный файл бота
"""

import os
from datetime import datetime

# === ОСНОВНЫЕ НАСТРОЙКИ ===
BOT_TOKEN = os.getenv("BOT_TOKEN", "7951273022:AAGwlOtv_079CjAsNQ32zRKspEedwlCmOa4")
HOST_NAME = os.getenv("HOST_NAME", "LufHost")
HOST_DESCRIPTION = os.getenv("HOST_DESCRIPTION", "Надежный хостинг юзерботов Telegram")
HOST_SUPPORT_LINK = os.getenv("HOST_SUPPORT_LINK", "https://t.me/lufhost_support")
HOST_DONATE_LINK = os.getenv("HOST_DONATE_LINK", "https://t.me/lufhost_donate")
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")

# === БАЗА ДАННЫХ ===
DATABASE_PATH = os.getenv("DATABASE_PATH", "lufhost.db")  # Исправлено: DATABASE_FILE -> DATABASE_PATH
BALANCE_DEFAULT = float(os.getenv("BALANCE_DEFAULT", "0.0"))
CURRENCY_DEFAULT = os.getenv("CURRENCY_DEFAULT", "RUB")
REG_DATE_DEFAULT = datetime.now().strftime("%Y-%m-%d")

# === АДМИНИСТРИРОВАНИЕ ===
ADMIN_IDS = [int(x) for x in os.getenv("ADMIN_IDS", "7785427704").split(",")]

# === ОГРАНИЧЕНИЯ ===
MAX_CONTAINERS_PER_USER = int(os.getenv("MAX_CONTAINERS_PER_USER", "5"))
MIN_BALANCE_FOR_CONTAINER = float(os.getenv("MIN_BALANCE_FOR_CONTAINER", "100.0"))

# === СЕРВЕР ===
SERVER_LOCATION = os.getenv("SERVER_LOCATION", "Moscow, Russia")
SERVER_IP = os.getenv("SERVER_IP", "77.222.47.27")
SERVER_SSH_HOST = os.getenv("SERVER_SSH_HOST", "77.222.47.27")
SERVER_SSH_USER = os.getenv("SERVER_SSH_USER", "root")
SERVER_SSH_PASSWORD = os.getenv("SERVER_SSH_PASSWORD", "2chUenQFso^rpfRH")
SERVER_PORTAINER_URL = os.getenv("SERVER_PORTAINER_URL", "https://77-222-47-27.swtest.ru/")
SERVER_PORTAINER_USER = os.getenv("SERVER_PORTAINER_USER", "admin")
SERVER_PORTAINER_PASSWORD = os.getenv("SERVER_PORTAINER_PASSWORD", "2chUenQFso^rpfRH")

# === ИЗОБРАЖЕНИЯ ===
ASSETS_DIR = "assets"
IMG_MAIN = os.path.join(ASSETS_DIR, "main.jpg")
IMG_PROFILE = os.path.join(ASSETS_DIR, "profile.jpg")
IMG_SETTINGS = os.path.join(ASSETS_DIR, "settings.jpg")
IMG_USERBOTS_MENU = os.path.join(ASSETS_DIR, "userbots_menu.jpg")
IMG_USERBOTS_LIST = os.path.join(ASSETS_DIR, "userbots_list.jpg")
IMG_USERBOTS_PANEL = os.path.join(ASSETS_DIR, "userbots_panel.jpg")
IMG_BUY_USERBOT = os.path.join(ASSETS_DIR, "buy_userbot.jpg")

# === ТАРИФЫ ===
TARIFFS = {
    "lite": {
        "name": "Lite",
        "description": "Базовый тариф для начинающих",
        "cpu": "1 Core",
        "ram": "512 MB",
        "storage": "5 GB",
        "monthly_prices": {
            1: {"name": "1 месяц", "price": 100.0},
            3: {"name": "3 месяца", "price": 270.0},
            6: {"name": "6 месяцев", "price": 480.0},
            12: {"name": "1 год", "price": 900.0}
        }
    },
    "standard": {
        "name": "Standard",
        "description": "Стандартный тариф для активных пользователей",
        "cpu": "2 Cores",
        "ram": "1 GB",
        "storage": "10 GB",
        "monthly_prices": {
            1: {"name": "1 месяц", "price": 200.0},
            3: {"name": "3 месяца", "price": 540.0},
            6: {"name": "6 месяцев", "price": 960.0},
            12: {"name": "1 год", "price": 1800.0}
        }
    },
    "premium": {
        "name": "Premium",
        "description": "Премиум тариф для профессионалов",
        "cpu": "4 Cores",
        "ram": "2 GB",
        "storage": "20 GB",
        "monthly_prices": {
            1: {"name": "1 месяц", "price": 400.0},
            3: {"name": "3 месяца", "price": 1080.0},
            6: {"name": "6 месяцев", "price": 1920.0},
            12: {"name": "1 год", "price": 3600.0}
        }
    }
}

# === ПЛАТЕЖИ ===
PAYMENT_METHODS = {
    "sberbank": {
        "name": "💳 Сбербанк",
        "number": "2202200000000000",
        "enabled": True
    },
    "tinkoff": {
        "name": "💳 Тинькофф",
        "number": "5536913700000000",
        "enabled": True
    },
    "qiwi": {
        "name": "🥝 QIWI",
        "number": "+79000000000",
        "enabled": False
    },
    "yoomoney": {
        "name": "💰 ЮMoney",
        "number": "410000000000000",
        "enabled": False
    }
}

# Автоматическое одобрение платежей (для тестирования)
AUTO_APPROVE_PAYMENTS = os.getenv("AUTO_APPROVE_PAYMENTS", "False").lower() == "true"

# === DOCKER НАСТРОЙКИ ===
DOCKER_HOST = os.getenv("DOCKER_HOST", f"ssh://{SERVER_SSH_USER}@{SERVER_SSH_HOST}")
DOCKER_NETWORK = os.getenv("DOCKER_NETWORK", "lufhost-network")
DOCKER_IMAGE = os.getenv("DOCKER_IMAGE", "lufhost/userbot:latest")
DOCKER_BASE_PORT = int(os.getenv("DOCKER_BASE_PORT", "8000"))
DOCKER_API_URL = os.getenv("DOCKER_API_URL", f"tcp://{SERVER_IP}:2376")
DOCKER_REMOTE_HOST = os.getenv("DOCKER_REMOTE_HOST", SERVER_IP)
