# LufHost - Telegram Bot для Управления Юзерботами

![LufHost Logo](https://img.shields.io/badge/LufHost-Hosting-blue?style=for-the-badge&logo=docker)
![Python](https://img.shields.io/badge/Python-3.8+-green?style=for-the-badge&logo=python)
![aiogram](https://img.shields.io/badge/aiogram-3.x-orange?style=for-the-badge&logo=telegram)

**LufHost** - это современная платная система хостинга юзерботов Telegram с полной админ-панелью, системой технических работ и удобным управлением через бота.

## 🏴‍☠️ Особенности

- **Кастомный брендинг LufHost** (в честь Луффи из One Piece)
- **Система технических работ** с админ-панелью
- **Платная система** с реквизитами и подтверждением платежей
- **Автоматическое определение хоста** вместо стандартного "Docker"
- **Гибкие тарифы** с различными периодами оплаты
- **JSON база данных** (без SQLite)
- **Полная настройка через конфиги**

## 🚀 Быстрый старт

### 1. Установка зависимостей

```bash
pip install aiogram python-dotenv
