#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LufHost Telegram Bot
Главный файл запуска бота
"""

import asyncio
import logging
import os
import sys
from pathlib import Path

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage

# Добавляем текущую директорию в PATH для импортов
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from handlers import handlers_router
from utils.database import init_database
from config import BOT_TOKEN, LOG_LEVEL, HOST_NAME

# Настройка логирования
logging.basicConfig(
    level=getattr(logging, LOG_LEVEL.upper(), logging.INFO),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('bot.log'),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger(__name__)

async def main():
    """Основная функция запуска бота"""
    logger.info(f"Запуск {HOST_NAME} бота...")
    
    # Инициализация базы данных
    try:
        init_database()
        logger.info("База данных успешно инициализирована")
    except Exception as e:
        logger.error(f"Ошибка инициализации базы данных: {e}")
        return
    
    # Инициализация бота и диспетчера
    bot = Bot(
        token=BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML)
    )
    
    storage = MemoryStorage()
    dp = Dispatcher(storage=storage)
    
    # Регистрация главного роутера
    dp.include_router(handlers_router)
    
    logger.info("Роутеры зарегистрированы")
    
    # Создаем папку для ресурсов если не существует
    os.makedirs("assets", exist_ok=True)
    
    try:
        logger.info("Бот запущен и готов к работе")
        await dp.start_polling(bot)
    except Exception as e:
        logger.error(f"Критическая ошибка при запуске бота: {e}")
    finally:
        await bot.session.close()
        logger.info("Бот остановлен")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Бот остановлен пользователем")
    except Exception as e:
        logger.error(f"Критическая ошибка: {e}")
        sys.exit(1)
