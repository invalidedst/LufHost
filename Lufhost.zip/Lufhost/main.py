#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LufHost - Enhanced Telegram Bot for Container Management
Main application entry point with time-based rentals and resource monitoring
"""

import asyncio
import logging
import sys
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage

# Import handlers
from handlers import (
    common, admin, payment, profile, 
    settings, userbots, errors
)

# Import utilities
from utils.database import init_database
from utils.resource_monitor import start_resource_monitor
from config import BOT_TOKEN, ADMIN_IDS, LOG_LEVEL

# Configure logging
logging.basicConfig(
    level=getattr(logging, LOG_LEVEL.upper()),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('bot.log'),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger(__name__)

async def main():
    """Main application function"""
    try:
        # Initialize database
        logger.info("Initializing database...")
        init_database()
        
        # Initialize bot and dispatcher
        bot = Bot(
            token=BOT_TOKEN,
            default=DefaultBotProperties(parse_mode=ParseMode.HTML)
        )
        
        dp = Dispatcher(storage=MemoryStorage())
        
        # Register handlers
        dp.include_router(common.router)
        dp.include_router(admin.router)
        dp.include_router(payment.router)
        dp.include_router(profile.router)
        dp.include_router(settings.router)
        dp.include_router(userbots.router)
        dp.include_router(errors.router)  # Error handler should be last
        
        # Start resource monitoring
        logger.info("Starting resource monitoring...")
        asyncio.create_task(start_resource_monitor(bot))
        
        # Start polling
        logger.info("Starting bot polling...")
        await dp.start_polling(bot)
        
    except Exception as e:
        logger.error(f"Critical error in main: {e}")
        sys.exit(1)

if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        sys.exit(1)