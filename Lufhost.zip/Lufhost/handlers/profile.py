#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LufHost Profile Handlers
Обработчики профиля пользователя
"""

import logging
from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery, FSInputFile
from aiogram.utils.markdown import hbold, hcode
from aiogram.exceptions import TelegramBadRequest

from keyboards.inline import setup_profile_keyboard, setup_top_up_methods_keyboard
from utils.database import (
    get_user_balance, get_user_currency, get_user_reg_date,
    create_user_if_not_exists, get_user_data
)
from config import IMG_PROFILE, BALANCE_DEFAULT, CURRENCY_DEFAULT, REG_DATE_DEFAULT, HOST_NAME

router = Router()

async def show_profile_message(target, bot: Bot):
    """Отображает профиль пользователя"""
    user_id = target.from_user.id
    chat_id = target.message.chat.id if isinstance(target, CallbackQuery) else target.chat.id
    user_name = target.from_user.full_name

    create_user_if_not_exists(user_id)
    balance = get_user_balance(user_id)
    currency = get_user_currency(user_id)
    reg_date = get_user_reg_date(user_id)

    markup = setup_profile_keyboard()

    try:
        balance_str = f"{float(balance):.2f}"
    except (ValueError, TypeError):
        balance_str = f"{BALANCE_DEFAULT:.2f}"

    profile_text = (
        f"👤 {hbold('Ваш профиль в')} {HOST_NAME}\n\n"
        f"📝 Имя: {hbold(user_name)}\n"
        f"🆔 ID: {hcode(user_id)}\n"
        f"💰 Баланс: {hbold(balance_str)} {currency}\n"
        f"📅 Дата регистрации: {reg_date}\n\n"
        f"💎 Статус: {hbold('Активный пользователь')}\n"
        f"🎯 Доступные действия:"
    )

    photo_sent = False
    message_to_delete = target.message if isinstance(target, CallbackQuery) else None

    try:
        photo = FSInputFile(IMG_PROFILE)
        await bot.send_photo(
            chat_id, 
            photo=photo, 
            caption=profile_text,
            reply_markup=markup.as_markup(), 
            parse_mode="HTML"
        )
        photo_sent = True
        if message_to_delete:
            try: 
                await message_to_delete.delete()
            except Exception: 
                pass
    except FileNotFoundError:
        logging.error(f"Фото профиля не найдено: {IMG_PROFILE}")
    except Exception as e:
        logging.error(f"Ошибка при отправке профиля с фото: {e}")

    if not photo_sent:
        try:
            if isinstance(target, CallbackQuery):
                try: 
                    await target.message.edit_text(
                        profile_text, 
                        reply_markup=markup.as_markup(), 
                        parse_mode="HTML"
                    )
                except TelegramBadRequest as e_edit:
                    if "message can't be edited" in str(e_edit):
                        await bot.send_message(
                            chat_id, 
                            profile_text, 
                            reply_markup=markup.as_markup(), 
                            parse_mode="HTML"
                        )
                        if message_to_delete:
                            try: 
                                await message_to_delete.delete()
                            except Exception: 
                                pass
                    else: 
                        raise e_edit
            else:
                await bot.send_message(
                    chat_id, 
                    profile_text, 
                    reply_markup=markup.as_markup(), 
                    parse_mode="HTML"
                )
        except Exception as e:
            logging.error(f"Критическая ошибка при отправке профиля: {e}")


@router.callback_query(F.data == "profile")
async def profile_handler(query: CallbackQuery, bot: Bot):
    """Обработчик открытия профиля"""
    await query.answer()
    await show_profile_message(query, bot)


@router.callback_query(F.data == "top_up_balance")
async def top_up_balance_handler(query: CallbackQuery):
    """Обработчик пополнения баланса"""
    markup = setup_top_up_methods_keyboard()
    text = (
        f"💰 {hbold('Пополнение баланса')} {HOST_NAME}\n\n"
        f"🏦 Выберите удобный способ пополнения:\n\n"
        f"ℹ️ После выбора способа вы получите реквизиты для оплаты.\n"
        f"📸 Не забудьте прислать скриншот об оплате для быстрого зачисления средств!"
    )
    
    try:
        await query.message.edit_text(
            text, 
            reply_markup=markup.as_markup(),
            parse_mode="HTML"
        )
    except Exception as e:
        logging.error(f"Ошибка при показе методов пополнения: {e}")
        await query.answer("Ошибка при загрузке методов пополнения.", show_alert=True)
        return

    await query.answer()