#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LufHost Userbots Handlers
Интеграция с VDS Docker для создания контейнеров
"""

import logging
from datetime import datetime, timedelta
from aiogram import Router, F, Bot, types
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, CallbackQuery, FSInputFile
from aiogram.utils.markdown import hbold, hcode, hlink

# Импорт VDS интеграции
from docker_vds_manager import (
    create_userbot_for_telegram_user, 
    get_user_containers_list, 
    manage_container,
    get_container_logs_for_user
)

from keyboards.inline import (
    setup_userbots_menu_keyboard, setup_list_userbots_keyboard,
    setup_control_userbot_keyboard, setup_buy_userbot_keyboard,
    setup_tariff_period_keyboard, setup_reinstall_confirmation_keyboard
)
from states.user_states import BuyUserbot
from utils.database import (
    get_user_balance, set_user_balance, get_user_currency, 
    create_user_if_not_exists
)
from config import (
    IMG_USERBOTS_MENU, IMG_USERBOTS_LIST, IMG_USERBOTS_PANEL,
    IMG_BUY_USERBOT, SERVER_LOCATION, TARIFFS, HOST_NAME, MAX_CONTAINERS_PER_USER
)

router = Router()

async def show_userbots_menu(target, bot: Bot):
    """Отображает главное меню управления юзерботами"""
    user_id = target.from_user.id
    chat_id = target.message.chat.id if isinstance(target, CallbackQuery) else target.chat.id
    
    # Получаем контейнеры пользователя через VDS
    containers = await get_user_containers_list(user_id)
    active_containers = len([c for c in containers if "Up" in c.get('status', '')])
    
    markup = setup_userbots_menu_keyboard()
    
    menu_text = (
        f"🤖 {hbold('Управление юзерботами')} {HOST_NAME}\n\n"
        f"🎯 Выберите нужное действие:\n\n"
        f"📊 Статистика:\n"
        f"• Активных контейнеров: {active_containers}/{len(containers)}\n"
        f"• Максимум контейнеров: {MAX_CONTAINERS_PER_USER}\n"
        f"• Локация: {SERVER_LOCATION}\n"
        f"• Статус: 🟢 Онлайн"
    )
    
    # Отправляем сообщение
    try:
        if isinstance(target, CallbackQuery):
            await target.message.edit_text(
                menu_text, 
                reply_markup=markup.as_markup(), 
                parse_mode="HTML"
            )
        else:
            await bot.send_message(
                chat_id, 
                menu_text, 
                reply_markup=markup.as_markup(), 
                parse_mode="HTML"
            )
    except Exception as e:
        logging.error(f"Ошибка в show_userbots_menu: {e}")


@router.callback_query(F.data == "userbots_menu")
async def userbots_menu_handler(query: CallbackQuery, bot: Bot):
    """Обработчик меню юзерботов"""
    await query.answer()
    await show_userbots_menu(query, bot)


async def show_list_userbots(target, bot: Bot):
    """Отображает список юзерботов пользователя"""
    user_id = target.from_user.id
    chat_id = target.message.chat.id if isinstance(target, CallbackQuery) else target.chat.id
    
    # Получаем список контейнеров через VDS
    containers = await get_user_containers_list(user_id)
    
    if containers:
        list_text = (
            f"🤖 {hbold('Ваши юзерботы')} {HOST_NAME}\n\n"
            f"📊 Всего контейнеров: {len(containers)}/{MAX_CONTAINERS_PER_USER}\n\n"
        )
        
        for i, container in enumerate(containers, 1):
            name = container.get('name', 'N/A')
            status = "🟢" if "Up" in container.get('status', '') else "🔴"
            ports = container.get('ports', 'N/A')
            
            list_text += f"{i}. {status} {name}\n"
            list_text += f"   📊 Статус: {container.get('status', 'Неизвестно')}\n"
            list_text += f"   🔌 Порты: {ports}\n\n"
        
        list_text += f"🪪 Выберите юзербота для управления:"
    else:
        list_text = (
            f"🤖 {hbold('Ваши юзерботы')} {HOST_NAME}\n\n"
            f"📊 У вас пока нет активных юзерботов.\n\n"
            f"💡 Хотите создать первого юзербота? Нажмите \"Купить юзербота\" в главном меню!"
        )
    
    try:
        if isinstance(target, CallbackQuery):
            await target.message.edit_text(
                list_text, 
                parse_mode="HTML"
            )
        else:
            await bot.send_message(
                chat_id, 
                list_text, 
                parse_mode="HTML"
            )
    except Exception as e:
        logging.error(f"Ошибка в show_list_userbots: {e}")


@router.callback_query(F.data == "list_userbots")
async def list_userbots_handler(query: CallbackQuery, bot: Bot):
    """Обработчик списка юзерботов"""
    await query.answer()
    await show_list_userbots(query, bot)


@router.callback_query(F.data == "buy_userbot")
async def buy_userbot_handler(query: CallbackQuery, bot: Bot):
    """Обработчик покупки юзербота - интеграция с VDS"""
    await query.answer("🔄 Создаем ваш юзербот...")
    
    user_id = query.from_user.id
    username = query.from_user.username or query.from_user.first_name
    
    try:
        # Создаем пользователя в базе если не существует
        create_user_if_not_exists(user_id, username)
        
        # Создаем контейнер через VDS
        result = await create_userbot_for_telegram_user(user_id)
        
        if result["success"]:
            success_text = f"""
✅ {hbold('Юзербот успешно создан!')}

📦 Контейнер: {hcode(result['container_name'])}
🌐 Ссылка доступа: {hcode(result['url'])}
🔌 Порт: {result['port']}
🆔 ID пользователя: {user_id}

🚀 Ваш юзербот запущен и готов к работе!
💡 Перейдите по ссылке выше для настройки.

⚡ Контейнер автоматически перезапускается при перезагрузке сервера.
            """
            
            await bot.send_message(
                query.message.chat.id,
                success_text,
                parse_mode="HTML"
            )
        else:
            error_text = f"""
❌ {hbold('Ошибка создания юзербота')}

🔍 Причина: {result.get('error', 'Неизвестная ошибка')}

💡 Попробуйте позже или обратитесь в поддержку.
            """
            
            await bot.send_message(
                query.message.chat.id,
                error_text,
                parse_mode="HTML"
            )
            
    except Exception as e:
        logging.error(f"Ошибка при создании юзербота: {e}")
        await bot.send_message(
            query.message.chat.id,
            f"❌ Произошла критическая ошибка: {str(e)}",
            parse_mode="HTML"
        )


@router.callback_query(F.data.startswith("container_action_"))
async def container_action_handler(query: CallbackQuery, bot: Bot):
    """Обработчик действий с контейнерами"""
    await query.answer("🔄 Выполняется...")
    
    try:
        # Парсим callback data: container_action_START_container_name
        parts = query.data.split('_')
        action = parts[2].lower()  # start, stop, remove
        container_name = '_'.join(parts[3:])  # имя контейнера
        
        user_id = query.from_user.id
        
        # Проверяем принадлежность контейнера пользователю
        if not container_name.startswith(f"userbot_{user_id}"):
            await query.answer("❌ Этот контейнер вам не принадлежит", show_alert=True)
            return
        
        # Выполняем действие через VDS
        success = await manage_container(container_name, action)
        
        if success:
            action_texts = {
                "start": "запущен",
                "stop": "остановлен", 
                "remove": "удален"
            }
            
            await bot.send_message(
                query.message.chat.id,
                f"✅ Контейнер {hcode(container_name)} {action_texts.get(action, 'обновлен')}",
                parse_mode="HTML"
            )
            
            # Обновляем список контейнеров
            await show_list_userbots(query, bot)
        else:
            await query.answer(f"❌ Не удалось {action} контейнер", show_alert=True)
            
    except Exception as e:
        logging.error(f"Ошибка при управлении контейнером: {e}")
        await query.answer("❌ Ошибка выполнения действия", show_alert=True)


@router.callback_query(F.data.startswith("logs_"))
async def container_logs_handler(query: CallbackQuery, bot: Bot):
    """Обработчик получения логов контейнера"""
    await query.answer("📋 Получаю логи...")
    
    try:
        container_name = query.data.replace("logs_", "")
        user_id = query.from_user.id
        
        # Проверяем принадлежность
        if not container_name.startswith(f"userbot_{user_id}"):
            await query.answer("❌ Этот контейнер вам не принадлежит", show_alert=True)
            return
        
        # Получаем логи через VDS
        logs = await get_container_logs_for_user(container_name)
        
        logs_text = f"""
📋 {hbold('Логи контейнера')} {hcode(container_name)}

{hcode(logs[:3000])}...
        """
        
        await bot.send_message(
            query.message.chat.id,
            logs_text,
            parse_mode="HTML"
        )
        
    except Exception as e:
        logging.error(f"Ошибка при получении логов: {e}")
        await query.answer("❌ Ошибка получения логов", show_alert=True)


# Дополнительные обработчики для совместимости
@router.callback_query(F.data == "back_to_userbots")
async def back_to_userbots_handler(query: CallbackQuery, bot: Bot):
    """Возврат в меню юзерботов"""
    await query.answer()
    await show_userbots_menu(query, bot)


# Обработчик текстовых команд
@router.message(F.text.startswith('/userbots'))
async def userbots_command_handler(message: Message, bot: Bot):
    """Команда для открытия меню юзерботов"""
    await show_userbots_menu(message, bot)
