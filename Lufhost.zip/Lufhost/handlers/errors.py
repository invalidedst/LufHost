#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LufHost Error Handlers
Обработчики ошибок и неопознанных действий
"""

import logging
from aiogram import Router, F
from aiogram.types import CallbackQuery, Message
from aiogram.fsm.context import FSMContext

router = Router()

@router.callback_query()
async def unhandled_callback_handler(query: CallbackQuery, state: FSMContext):
    """Ловит все необработанные колбэки"""
    logging.warning(f"Необработанный callback: {query.data} от пользователя {query.from_user.id}")
    
    # Очищаем состояние при неопознанном колбэке
    current_state = await state.get_state()
    if current_state:
        await state.clear()
        logging.info(f"Очищено состояние {current_state} для пользователя {query.from_user.id}")
    
    try:
        await query.answer(
            "🤔 Это действие не распознано или кнопка устарела.\n"
            "Попробуйте вернуться в главное меню.", 
            show_alert=True
        )
    except Exception as e:
        logging.warning(f"Не удалось ответить на необработанный колбэк: {e}")


@router.message()
async def unhandled_message_handler(message: Message, state: FSMContext):
    """Ловит все необработанные сообщения"""
    user_id = message.from_user.id
    message_text = message.text
    
    # Проверяем, ожидается ли ввод в каком-то состоянии
    current_state = await state.get_state()
    if current_state:
        logging.warning(f"Неожиданное сообщение '{message_text}' в состоянии {current_state} от пользователя {user_id}")
        await message.answer(
            "❌ Неожиданный ввод. Попробуйте следовать инструкциям или вернитесь в главное меню.\n"
            "Используйте команду /start для перезапуска."
        )
        return
    
    logging.info(f"Необработанное сообщение '{message_text}' от пользователя {user_id}")
    
    await message.answer(
        "🤖 Я понимаю только команды из меню.\n"
        "Используйте кнопки или команду /start для начала работы."
    )