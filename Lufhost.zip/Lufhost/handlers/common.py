#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LufHost Common Handlers
Общие обработчики команд
"""

import logging
from aiogram import Router, F, Bot
from aiogram.filters import CommandStart
from aiogram.types import Message, CallbackQuery, FSInputFile
from aiogram.utils.markdown import hbold, hlink

from keyboards.inline import (
    setup_main_menu_keyboard,
    setup_agreement_keyboard
)
from utils.database import (
    check_user_agreement,
    record_user_agreement,
    create_user_if_not_exists,
    check_maintenance_mode
)
from config import IMG_MAIN, HOST_NAME, HOST_DESCRIPTION, HOST_SUPPORT_LINK

router = Router()

async def show_main_menu(target, bot: Bot):
    """
    Отображает главное меню LufHost
    """
    user_id = target.from_user.id
    user_name = target.from_user.full_name
    chat_id = target.message.chat.id if isinstance(target, CallbackQuery) else target.chat.id

    # Проверка технических работ
    from config import ADMIN_IDS
    maintenance_info = check_maintenance_mode()
    if maintenance_info['enabled'] and user_id not in ADMIN_IDS:
        await bot.send_message(
            chat_id,
            f"🔧 {hbold('Технические работы')}\n\n"
            f"{maintenance_info['message']}\n\n"
            f"Приносим извинения за неудобства."
        )
        return

    # Создание пользователя в БД, если его нет
    create_user_if_not_exists(user_id)

    markup = setup_main_menu_keyboard()
    welcome_text = (
        f"👋 Добро пожаловать в {hbold(HOST_NAME)}, {hbold(user_name)}!\n\n"
        f"🚀 {HOST_DESCRIPTION}\n\n"
        f"💎 Преимущества {HOST_NAME}:\n"
        f"• Стабильная работа 24/7\n"
        f"• Быстрое развертывание\n"
        f"• Техническая поддержка\n"
        f"• Гибкие тарифы\n\n"
        f"🎯 Выберите нужное действие в меню ниже:"
    )

    try:
        photo = FSInputFile(IMG_MAIN)
        logging.debug(f"Отправка главного меню (фото+текст) в чат {chat_id}")
        
        if isinstance(target, CallbackQuery):
            await bot.send_photo(
                chat_id,
                photo=photo,
                caption=welcome_text,
                reply_markup=markup.as_markup(),
                parse_mode="HTML"
            )
            try:
                await target.message.delete()
            except Exception as e:
                logging.warning(f"Не удалось удалить сообщение: {e}")
        else:
            await bot.send_photo(
                chat_id,
                photo=photo,
                caption=welcome_text,
                reply_markup=markup.as_markup(),
                parse_mode="HTML"
            )

    except FileNotFoundError:
        logging.error(f"Фото главного меню не найдено: {IMG_MAIN}")
        if isinstance(target, CallbackQuery):
            try:
                await target.message.edit_text(
                    welcome_text, 
                    reply_markup=markup.as_markup(), 
                    parse_mode="HTML"
                )
            except Exception:
                await bot.send_message(
                    chat_id, 
                    welcome_text, 
                    reply_markup=markup.as_markup(), 
                    parse_mode="HTML"
                )
                try: 
                    await target.message.delete()
                except Exception: 
                    pass
        else:
            await bot.send_message(
                chat_id, 
                welcome_text, 
                reply_markup=markup.as_markup(), 
                parse_mode="HTML"
            )

    except Exception as e:
        logging.error(f"Ошибка при отправке главного меню: {e}")
        # Отправляем текстовое сообщение без фото
        if isinstance(target, CallbackQuery):
            try:
                await target.message.edit_text(
                    text=welcome_text,
                    reply_markup=markup.as_markup(),
                    parse_mode="HTML"
                )
            except Exception:
                await bot.send_message(
                    chat_id, 
                    welcome_text, 
                    reply_markup=markup.as_markup(),
                    parse_mode="HTML"
                )
        else:
            await bot.send_message(
                chat_id, 
                welcome_text, 
                reply_markup=markup.as_markup(),
                parse_mode="HTML"
            )


@router.message(CommandStart())
async def command_start_handler(message: Message, bot: Bot):
    """Обработчик команды /start"""
    user_id = message.from_user.id
    logging.info(f"Пользователь {user_id} ({message.from_user.username}) нажал /start")

    # Проверка соглашения
    if not check_user_agreement(user_id):
        markup_agreement = setup_agreement_keyboard()
        agreement_text = f"""
⚠️ <b>Пользовательское соглашение {HOST_NAME}</b> ⚠️

<blockquote>Добро пожаловать в <b>{HOST_NAME}</b> - надежный хостинг юзерботов.</blockquote>

<blockquote><b>Важные условия использования:</b></blockquote>

<blockquote>1. <b>Ответственность пользователя:</b> Вы несете полную ответственность за действия ваших юзерботов.
2. <b>Соблюдение правил:</b> Запрещается использование для спама, рассылок и нарушения правил Telegram.
3. <b>Техническая поддержка:</b> Мы предоставляем техническую поддержку в рабочее время.
4. <b>Оплата услуг:</b> Все услуги предоставляются на платной основе согласно действующим тарифам.
5. <b>Возврат средств:</b> Возврат средств осуществляется в соответствии с правилами сервиса.</blockquote>

<blockquote>Нажимая кнопку «Согласен», вы подтверждаете, что ознакомлены и согласны с условиями использования {HOST_NAME}.</blockquote>

<b>Для продолжения работы с ботом примите соглашение.</b>
        """
        try:
            await message.answer(
                text=agreement_text,
                reply_markup=markup_agreement.as_markup(),
                parse_mode="HTML"
            )
            logging.info(f"Пользователю {user_id} отправлено соглашение.")
        except Exception as e:
            logging.error(f"Не удалось отправить соглашение пользователю {user_id}: {e}")
    else:
        logging.info(f"Пользователь {user_id} уже принял соглашение.")
        create_user_if_not_exists(user_id, agreed=True)
        await show_main_menu(message, bot)


@router.callback_query(F.data == "agree_policy")
async def agreement_handler(query: CallbackQuery, bot: Bot):
    """Обработчик принятия соглашения"""
    user_id = query.from_user.id
    record_user_agreement(user_id)
    logging.info(f"Пользователь {user_id} принял соглашение.")
    await query.answer("✅ Соглашение принято. Добро пожаловать в LufHost!", show_alert=False)
    
    await show_main_menu(query, bot)


@router.callback_query(F.data == "main_menu")
async def back_to_main_menu_handler(query: CallbackQuery, bot: Bot):
    """Обработчик возврата в главное меню"""
    await query.answer()
    await show_main_menu(query, bot)