#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LufHost Payment Handlers
Обработчики платежной системы
"""

import logging
from aiogram import Router, F, Bot
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, CallbackQuery, ContentType
from aiogram.utils.markdown import hbold, hcode

from keyboards.inline import (
    setup_payment_confirmation_keyboard,
    setup_admin_payment_review_keyboard
)
from states.user_states import PaymentProcess
from utils.database import (
    create_payment_request, get_payment_request,
    approve_payment_request, reject_payment_request,
    get_user_balance, set_user_balance, get_user_currency
)
from utils.admin_utils import is_admin
from config import PAYMENT_METHODS, AUTO_APPROVE_PAYMENTS, ADMIN_IDS, HOST_NAME

router = Router()

@router.callback_query(F.data.startswith("payment_method_"))
async def payment_method_handler(query: CallbackQuery, state: FSMContext):
    """Обработчик выбора способа пополнения"""
    try:
        method_key = query.data.split('_')[2]
        
        if method_key not in PAYMENT_METHODS:
            await query.answer("❌ Неизвестный способ оплаты", show_alert=True)
            return
        
        method_info = PAYMENT_METHODS[method_key]
        
        if not method_info.get('enabled', False):
            await query.answer("❌ Этот способ оплаты временно недоступен", show_alert=True)
            return
        
        await state.update_data(payment_method=method_key)
        
        method_text = (
            f"💳 {hbold('Пополнение через')} {method_info['name']}\n\n"
            f"📝 {hbold('Реквизиты для оплаты:')}\n"
            f"{hcode(method_info['number'])}\n\n"
            f"💰 Введите сумму пополнения в рублях:\n"
            f"(Минимум: 100 RUB, Максимум: 50000 RUB)"
        )
        
        await query.message.edit_text(
            method_text,
            parse_mode="HTML"
        )
        
        await state.set_state(PaymentProcess.waiting_for_amount)
        await query.answer()
        
    except Exception as e:
        logging.error(f"Ошибка в payment_method_handler: {e}")
        await query.answer("❌ Ошибка при выборе способа оплаты", show_alert=True)


@router.message(PaymentProcess.waiting_for_amount)
async def payment_amount_handler(message: Message, state: FSMContext, bot: Bot):
    """Обработчик ввода суммы пополнения"""
    try:
        amount_text = message.text.replace(',', '.')
        amount = float(amount_text)
        
        if amount < 100:
            await message.answer("❌ Минимальная сумма пополнения: 100 RUB")
            return
        
        if amount > 50000:
            await message.answer("❌ Максимальная сумма пополнения: 50000 RUB")
            return
        
        state_data = await state.get_data()
        payment_method = state_data.get('payment_method')
        
        if not payment_method:
            await message.answer("❌ Ошибка: способ оплаты не выбран")
            await state.clear()
            return
        
        method_info = PAYMENT_METHODS[payment_method]
        user_id = message.from_user.id
        
        # Создаем запрос на пополнение
        payment_id = create_payment_request(user_id, amount, payment_method)
        
        await state.update_data(payment_id=payment_id, amount=amount)
        
        payment_text = (
            f"💳 {hbold('Детали пополнения')}\n\n"
            f"💰 Сумма: {hbold(f'{amount:.2f} RUB')}\n"
            f"🏦 Способ: {method_info['name']}\n"
            f"📱 Реквизиты: {hcode(method_info['number'])}\n\n"
            f"📋 {hbold('Инструкция:')}\n"
            f"1. Переведите {amount:.2f} RUB на указанные реквизиты\n"
            f"2. Сделайте скриншот подтверждения оплаты\n"
            f"3. Отправьте скриншот в этот чат\n\n"
            f"⚠️ {hbold('Важно:')} Переводите точную сумму без комиссий!\n"
            f"🆔 ID платежа: {hcode(payment_id)}"
        )
        
        markup = setup_payment_confirmation_keyboard(payment_id)
        
        await message.answer(
            payment_text,
            reply_markup=markup.as_markup(),
            parse_mode="HTML"
        )
        
        await state.set_state(PaymentProcess.waiting_for_screenshot)
        
        # Удаляем сообщение с суммой
        try:
            await message.delete()
        except Exception:
            pass
        
    except ValueError:
        await message.answer(
            "❌ Неверная сумма. Введите число (например: 500 или 1250.50)"
        )
    except Exception as e:
        logging.error(f"Ошибка в payment_amount_handler: {e}")
        await message.answer("❌ Произошла ошибка при обработке суммы")


@router.message(PaymentProcess.waiting_for_screenshot, F.content_type == ContentType.PHOTO)
async def payment_screenshot_handler(message: Message, state: FSMContext, bot: Bot):
    """Обработчик скриншота оплаты"""
    try:
        state_data = await state.get_data()
        payment_id = state_data.get('payment_id')
        amount = state_data.get('amount')
        
        if not payment_id or not amount:
            await message.answer("❌ Ошибка: данные платежа не найдены")
            await state.clear()
            return
        
        user_id = message.from_user.id
        user_name = message.from_user.full_name
        
        # Проверяем автоматическое одобрение
        if AUTO_APPROVE_PAYMENTS:
            # Автоматически одобряем платеж
            success = approve_payment_request(payment_id)
            if success:
                current_balance = get_user_balance(user_id)
                new_balance = current_balance + amount
                set_user_balance(user_id, new_balance)
                
                await message.answer(
                    f"✅ {hbold('Платеж автоматически одобрен!')}\n\n"
                    f"💰 Зачислено: {amount:.2f} RUB\n"
                    f"💳 Новый баланс: {new_balance:.2f} RUB\n\n"
                    f"🎉 Спасибо за пополнение!",
                    parse_mode="HTML"
                )
                
                await state.clear()
                logging.info(f"Автоматически одобрен платеж {payment_id} пользователя {user_id}")
                return
        
        # Отправляем админам на проверку
        admin_text = (
            f"💳 {hbold('Новый платеж на проверку')}\n\n"
            f"👤 Пользователь: {user_name} ({hcode(user_id)})\n"
            f"💰 Сумма: {hbold(f'{amount:.2f} RUB')}\n"
            f"🆔 ID платежа: {hcode(payment_id)}\n"
            f"📸 Скриншот прикреплен ниже"
        )
        
        markup = setup_admin_payment_review_keyboard(payment_id)
        
        for admin_id in ADMIN_IDS:
            try:
                await bot.send_message(
                    admin_id,
                    admin_text,
                    parse_mode="HTML"
                )
                await bot.send_photo(
                    admin_id,
                    message.photo[-1].file_id,
                    caption=f"💳 Скриншот платежа {payment_id}",
                    reply_markup=markup.as_markup()
                )
            except Exception as e:
                logging.warning(f"Не удалось отправить уведомление админу {admin_id}: {e}")
        
        await message.answer(
            f"📸 {hbold('Скриншот получен!')}\n\n"
            f"🔍 Ваш платеж отправлен на проверку администраторам.\n"
            f"⏱ Обычно проверка занимает 5-30 минут.\n"
            f"📱 Мы уведомим вас о результате.\n\n"
            f"🆔 ID платежа: {hcode(payment_id)}",
            parse_mode="HTML"
        )
        
        await state.clear()
        logging.info(f"Получен скриншот для платежа {payment_id} от пользователя {user_id}")
        
    except Exception as e:
        logging.error(f"Ошибка в payment_screenshot_handler: {e}")
        await message.answer("❌ Произошла ошибка при обработке скриншота")


@router.message(PaymentProcess.waiting_for_screenshot)
async def payment_invalid_content_handler(message: Message):
    """Обработчик неверного контента вместо скриншота"""
    await message.answer(
        "📸 Пожалуйста, отправьте скриншот подтверждения оплаты.\n"
        "Принимаются только изображения."
    )


@router.callback_query(F.data.startswith("approve_payment_"))
async def approve_payment_handler(query: CallbackQuery, bot: Bot):
    """Обработчик одобрения платежа админом"""
    user_id = query.from_user.id
    
    if not is_admin(user_id):
        await query.answer("❌ Нет доступа", show_alert=True)
        return
    
    try:
        payment_id = int(query.data.split('_')[2])
        payment_data = get_payment_request(payment_id)
        
        if not payment_data:
            await query.answer("❌ Платеж не найден", show_alert=True)
            return
        
        if payment_data['status'] != 'pending':
            await query.answer("❌ Платеж уже обработан", show_alert=True)
            return
        
        # Одобряем платеж
        success = approve_payment_request(payment_id)
        if success:
            # Зачисляем средства
            customer_id = payment_data['user_id']
            amount = payment_data['amount']
            current_balance = get_user_balance(customer_id)
            new_balance = current_balance + amount
            set_user_balance(customer_id, new_balance)
            
            # Уведомляем пользователя
            try:
                await bot.send_message(
                    customer_id,
                    f"✅ {hbold('Платеж одобрен!')}\n\n"
                    f"💰 Зачислено: {amount:.2f} RUB\n"
                    f"💳 Новый баланс: {new_balance:.2f} RUB\n\n"
                    f"🎉 Спасибо за пополнение баланса в {HOST_NAME}!",
                    parse_mode="HTML"
                )
            except Exception as e:
                logging.warning(f"Не удалось уведомить пользователя {customer_id}: {e}")
            
            # Обновляем сообщение админа
            await query.message.edit_text(
                f"✅ {hbold('Платеж одобрен')}\n\n"
                f"💰 Сумма: {amount:.2f} RUB зачислена\n"
                f"👤 Пользователь: {customer_id}\n"
                f"👨‍💼 Одобрил: {query.from_user.full_name}",
                parse_mode="HTML"
            )
            
            await query.answer("✅ Платеж одобрен и средства зачислены")
            logging.info(f"Админ {user_id} одобрил платеж {payment_id}")
            
        else:
            await query.answer("❌ Ошибка при одобрении платежа", show_alert=True)
    
    except Exception as e:
        logging.error(f"Ошибка в approve_payment_handler: {e}")
        await query.answer("❌ Произошла ошибка", show_alert=True)


@router.callback_query(F.data.startswith("reject_payment_"))
async def reject_payment_handler(query: CallbackQuery, bot: Bot):
    """Обработчик отклонения платежа админом"""
    user_id = query.from_user.id
    
    if not is_admin(user_id):
        await query.answer("❌ Нет доступа", show_alert=True)
        return
    
    try:
        payment_id = int(query.data.split('_')[2])
        payment_data = get_payment_request(payment_id)
        
        if not payment_data:
            await query.answer("❌ Платеж не найден", show_alert=True)
            return
        
        if payment_data['status'] != 'pending':
            await query.answer("❌ Платеж уже обработан", show_alert=True)
            return
        
        # Отклоняем платеж
        success = reject_payment_request(payment_id)
        if success:
            customer_id = payment_data['user_id']
            amount = payment_data['amount']
            
            # Уведомляем пользователя
            try:
                await bot.send_message(
                    customer_id,
                    f"❌ {hbold('Платеж отклонен')}\n\n"
                    f"💰 Сумма: {amount:.2f} RUB\n"
                    f"🆔 ID платежа: {payment_id}\n\n"
                    f"📞 Обратитесь в поддержку для уточнения причины.",
                    parse_mode="HTML"
                )
            except Exception as e:
                logging.warning(f"Не удалось уведомить пользователя {customer_id}: {e}")
            
            # Обновляем сообщение админа
            await query.message.edit_text(
                f"❌ {hbold('Платеж отклонен')}\n\n"
                f"💰 Сумма: {amount:.2f} RUB\n"
                f"👤 Пользователь: {customer_id}\n"
                f"👨‍💼 Отклонил: {query.from_user.full_name}",
                parse_mode="HTML"
            )
            
            await query.answer("❌ Платеж отклонен")
            logging.info(f"Админ {user_id} отклонил платеж {payment_id}")
            
        else:
            await query.answer("❌ Ошибка при отклонении платежа", show_alert=True)
    
    except Exception as e:
        logging.error(f"Ошибка в reject_payment_handler: {e}")
        await query.answer("❌ Произошла ошибка", show_alert=True)
