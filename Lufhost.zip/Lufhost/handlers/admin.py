#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LufHost Admin Handlers
Административные функции
"""

import logging
from aiogram import Router, F, Bot
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from aiogram.utils.markdown import hbold, hcode

from utils.database import (
    get_all_users_stats, get_all_containers_stats,
    get_user_data, set_user_balance
)
from utils.admin_utils import (
    toggle_maintenance_mode, get_maintenance_status,
    set_maintenance_message, is_admin, log_admin_action
)
from keyboards.inline import setup_admin_keyboard
from config import ADMIN_IDS, HOST_NAME

router = Router()

@router.message(Command("admin"))
async def admin_panel_handler(message: Message):
    """Главная админ-панель"""
    user_id = message.from_user.id
    
    if not is_admin(user_id):
        await message.answer("❌ У вас нет доступа к админ-панели.")
        return
    
    users_stats = get_all_users_stats()
    containers_stats = get_all_containers_stats()
    maintenance_status = get_maintenance_status()
    
    admin_text = (
        f"🛠 {hbold('Админ-панель')} {HOST_NAME}\n\n"
        f"📊 {hbold('Статистика:')}\n"
        f"👥 Всего пользователей: {users_stats['total']}\n"
        f"✅ Принявших соглашение: {users_stats['agreed']}\n"
        f"💰 Средний баланс: {users_stats['avg_balance']:.2f} RUB\n\n"
        f"🤖 {hbold('Контейнеры:')}\n"
        f"📦 Всего контейнеров: {containers_stats['total']}\n"
        f"🟢 Активных: {containers_stats['active']}\n"
        f"🔴 Неактивных: {containers_stats['inactive']}\n\n"
        f"🔧 {hbold('Техническое обслуживание:')}\n"
        f"Статус: {'🟡 Включен' if maintenance_status['enabled'] else '🟢 Выключен'}\n"
        f"Сообщение: {maintenance_status['message'][:50]}..."
    )
    
    markup = setup_admin_keyboard(maintenance_status['enabled'])
    
    await message.answer(
        admin_text, 
        reply_markup=markup.as_markup(),
        parse_mode="HTML"
    )


@router.callback_query(F.data == "toggle_maintenance")
async def toggle_maintenance_handler(query: CallbackQuery):
    """Переключение режима технических работ"""
    user_id = query.from_user.id
    
    if not is_admin(user_id):
        await query.answer("❌ Нет доступа", show_alert=True)
        return
    
    result = toggle_maintenance_mode()
    status_text = "включен" if result['enabled'] else "выключен"
    
    await query.answer(f"🔧 Режим технических работ {status_text}")
    
    # Обновляем панель
    users_stats = get_all_users_stats()
    containers_stats = get_all_containers_stats()
    maintenance_status = get_maintenance_status()
    
    admin_text = (
        f"🛠 {hbold('Админ-панель')} {HOST_NAME}\n\n"
        f"📊 {hbold('Статистика:')}\n"
        f"👥 Всего пользователей: {users_stats['total']}\n"
        f"✅ Принявших соглашение: {users_stats['agreed']}\n"
        f"💰 Средний баланс: {users_stats['avg_balance']:.2f} RUB\n\n"
        f"🤖 {hbold('Контейнеры:')}\n"
        f"📦 Всего контейнеров: {containers_stats['total']}\n"
        f"🟢 Активных: {containers_stats['active']}\n"
        f"🔴 Неактивных: {containers_stats['inactive']}\n\n"
        f"🔧 {hbold('Техническое обслуживание:')}\n"
        f"Статус: {'🟡 Включен' if maintenance_status['enabled'] else '🟢 Выключен'}\n"
        f"Сообщение: {maintenance_status['message'][:50]}..."
    )
    
    markup = setup_admin_keyboard(maintenance_status['enabled'])
    
    try:
        await query.message.edit_text(
            admin_text,
            reply_markup=markup.as_markup(),
            parse_mode="HTML"
        )
    except Exception as e:
        logging.error(f"Ошибка обновления админ-панели: {e}")


@router.message(Command("users"))
async def list_users_handler(message: Message):
    """Список пользователей для админов"""
    user_id = message.from_user.id
    
    if not is_admin(user_id):
        await message.answer("❌ У вас нет доступа к этой команде.")
        return
    
    users_stats = get_all_users_stats()
    
    response = (
        f"👥 {hbold('Пользователи')} {HOST_NAME}\n\n"
        f"📊 Всего: {users_stats['total']}\n"
        f"✅ Принявших соглашение: {users_stats['agreed']}\n"
        f"💰 Общий баланс всех пользователей: {users_stats['total_balance']:.2f} RUB\n"
        f"📈 Средний баланс: {users_stats['avg_balance']:.2f} RUB"
    )
    
    await message.answer(response, parse_mode="HTML")


@router.message(Command("setbalance"))
async def set_balance_handler(message: Message):
    """Установка баланса пользователя (только для админов)"""
    user_id = message.from_user.id
    
    if not is_admin(user_id):
        await message.answer("❌ У вас нет доступа к этой команде.")
        return
    
    try:
        args = message.text.split()
        if len(args) != 3:
            await message.answer(
                "📝 Использование: /setbalance [user_id] [amount]\n"
                "Пример: /setbalance 123456789 1000"
            )
            return
        
        target_user_id = int(args[1])
        new_balance = float(args[2])
        
        if new_balance < 0:
            await message.answer("❌ Баланс не может быть отрицательным.")
            return
        
        user_data = get_user_data(target_user_id)
        if not user_data:
            await message.answer(f"❌ Пользователь {target_user_id} не найден в базе данных.")
            return
        
        old_balance = user_data.get('balance', 0)
        success = set_user_balance(target_user_id, new_balance)
        
        if success:
            await message.answer(
                f"✅ {hbold('Баланс изменен')}\n\n"
                f"👤 Пользователь: {hcode(target_user_id)}\n"
                f"💰 Было: {old_balance:.2f} RUB\n"
                f"💰 Стало: {new_balance:.2f} RUB\n"
                f"📊 Изменение: {new_balance - old_balance:+.2f} RUB",
                parse_mode="HTML"
            )
            logging.info(f"Админ {user_id} изменил баланс пользователя {target_user_id}: {old_balance} -> {new_balance}")
        else:
            await message.answer("❌ Ошибка при изменении баланса.")
    
    except (ValueError, IndexError):
        await message.answer(
            "❌ Неверный формат команды.\n"
            "📝 Использование: /setbalance [user_id] [amount]"
        )
    except Exception as e:
        logging.error(f"Ошибка в set_balance_handler: {e}")
        await message.answer("❌ Произошла ошибка при выполнении команды.")


@router.message(Command("maintenance"))
async def maintenance_command_handler(message: Message):
    """Быстрое переключение режима технических работ"""
    user_id = message.from_user.id
    
    if not is_admin(user_id):
        await message.answer("❌ У вас нет доступа к этой команде.")
        return
    
    # Если есть аргументы - устанавливаем сообщение
    args = message.text.split(maxsplit=1)
    if len(args) > 1:
        maintenance_message = args[1]
        set_maintenance_message(maintenance_message)
        await message.answer(f"📝 Сообщение о тех. работах обновлено:\n{maintenance_message}")
        return
    
    # Иначе переключаем режим
    result = toggle_maintenance_mode()
    status_text = "включен" if result['enabled'] else "выключен"
    
    await message.answer(
        f"🔧 {hbold('Режим технических работ')} {status_text}\n\n"
        f"📝 Сообщение: {result['message']}\n\n"
        f"💡 Для изменения сообщения используйте:\n"
        f"{hcode('/maintenance Ваше сообщение')}",
        parse_mode="HTML"
    )
