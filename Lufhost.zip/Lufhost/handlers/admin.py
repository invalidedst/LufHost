#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LufHost Admin Handlers
Административные функции
"""

import logging
from aiogram import Router, F, Bot
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from aiogram.utils.markdown import hbold, hcode

from utils.database import (
    get_all_users_stats, get_all_containers_stats,
    get_user_data, set_user_balance
)
from utils.admin_utils import (
    toggle_maintenance_mode, get_maintenance_status,
    set_maintenance_message, is_admin
)
from keyboards.inline import setup_admin_keyboard
from config import ADMIN_IDS, HOST_NAME

router = Router()

@router.message(Command("admin"))
async def admin_panel_handler(message: Message):
    """Главная админ-панель"""
    user_id = message.from_user.id
    
    if not is_admin(user_id):
        await message.answer("❌ У вас нет доступа к админ-панели.")
        return
    
    users_stats = get_all_users_stats()
    containers_stats = get_all_containers_stats()
    maintenance_status = get_maintenance_status()
    
    admin_text = (
        f"🛠 {hbold('Админ-панель')} {HOST_NAME}\n\n"
        f"📊 {hbold('Статистика:')}\n"
        f"👥 Всего пользователей: {users_stats['total']}\n"
        f"✅ Принявших соглашение: {users_stats['agreed']}\n"
        f"💰 Средний баланс: {users_stats['avg_balance']:.2f} RUB\n\n"
        f"🤖 {hbold('Контейнеры:')}\n"
        f"📦 Всего контейнеров: {containers_stats['total']}\n"
        f"🟢 Активных: {containers_stats['active']}\n"
        f"🔴 Неактивных: {containers_stats['inactive']}\n\n"
        f"🔧 {hbold('Техническое обслуживание:')}\n"
        f"Статус: {'🟡 Включен' if maintenance_status['enabled'] else '🟢 Выключен'}\n"
        f"Сообщение: {maintenance_status['message'][:50]}..."
    )
    
    markup = setup_admin_keyboard(maintenance_status['enabled'])
    
    await message.answer(
        admin_text, 
        reply_markup=markup.as_markup(),
        parse_mode="HTML"
    )


@router.callback_query(F.data == "toggle_maintenance")
async def toggle_maintenance_handler(query: CallbackQuery):
    """Переключение режима технических работ"""
    user_id = query.from_user.id
    
    if not is_admin(user_id):
        await query.answer("❌ Нет доступа", show_alert=True)
        return
    
    result = toggle_maintenance_mode()
    status_text = "включен" if result['enabled'] else "выключен"
    
    await query.answer(f"🔧 Режим технических работ {status_text}")
    
    # Обновляем панель
    users_stats = get_all_users_stats()
    containers_stats = get_all_containers_stats()
    maintenance_status = get_maintenance_status()
    
    admin_text = (
        f"🛠 {hbold('Админ-панель')} {HOST_NAME}\n\n"
        f"📊 {hbold('Статистика:')}\n"
        f"👥 Всего пользователей: {users_stats['total']}\n"
        f"✅ Принявших соглашение: {users_stats['agreed']}\n"
        f"💰 Средний баланс: {users_stats['avg_balance']:.2f} RUB\n\n"
        f"🤖 {hbold('Контейнеры:')}\n"
        f"📦 Всего контейнеров: {containers_stats['total']}\n"
        f"🟢 Активных: {containers_stats['active']}\n"
        f"🔴 Неактивных: {containers_stats['inactive']}\n\n"
        f"🔧 {hbold('Техническое обслуживание:')}\n"
        f"Статус: {'🟡 Включен' if maintenance_status['enabled'] else '🟢 Выключен'}\n"
        f"Сообщение: {maintenance_status['message'][:50]}..."
    )
    
    markup = setup_admin_keyboard(maintenance_status['enabled'])
    
    try:
        await query.message.edit_text(
            admin_text,
            reply_markup=markup.as_markup(),
            parse_mode="HTML"
        )
    except Exception as e:
        logging.error(f"Ошибка обновления админ-панели: {e}")


@router.message(Command("users"))
async def list_users_handler(message: Message):
    """Список пользователей для админов"""
    user_id = message.from_user.id
    
    if not is_admin(user_id):
        await message.answer("❌ У вас нет доступа к этой команде.")
        return
    
    users_stats = get_all_users_stats()
    
    response = (
        f"👥 {hbold('Пользователи')} {HOST_NAME}\n\n"
        f"📊 Всего: {users_stats['total']}\n"
        f"✅ Принявших соглашение: {users_stats['agreed']}\n"
        f"💰 Общий баланс всех пользователей: {users_stats['total_balance']:.2f} RUB\n"
        f"📈 Средний баланс: {users_stats['avg_balance']:.2f} RUB"
    )
    
    await message.answer(response, parse_mode="HTML")


@router.message(Command("setbalance"))
async def set_balance_handler(message: Message):
    """Установка баланса пользователя (только для админов)"""
    user_id = message.from_user.id
    
    if not is_admin(user_id):
        await message.answer("❌ У вас нет доступа к этой команде.")
        return
    
    try:
        args = message.text.split()
        if len(args) != 3:
            await message.answer(
                "📝 Использование: /setbalance [user_id] [amount]\n"
                "Пример: /setbalance 123456789 1000"
            )
            return
        
        target_user_id = int(args[1])
        new_balance = float(args[2])
        
        if new_balance < 0:
            await message.answer("❌ Баланс не может быть отрицательным.")
            return
        
        user_data = get_user_data(target_user_id)
        if not user_data:
            await message.answer(f"❌ Пользователь {target_user_id} не найден в базе данных.")
            return
        
        old_balance = user_data.get('balance', 0)
        success = set_user_balance(target_user_id, new_balance)
        
        if success:
            await message.answer(
                f"✅ {hbold('Баланс изменен')}\n\n"
                f"👤 Пользователь: {hcode(target_user_id)}\n"
                f"💰 Было: {old_balance:.2f} RUB\n"
                f"💰 Стало: {new_balance:.2f} RUB\n"
                f"📊 Изменение: {new_balance - old_balance:+.2f} RUB",
                parse_mode="HTML"
            )
            logging.info(f"Админ {user_id} изменил баланс пользователя {target_user_id}: {old_balance} -> {new_balance}")
        else:
            await message.answer("❌ Ошибка при изменении баланса.")
    
    except (ValueError, IndexError):
        await message.answer(
            "❌ Неверный формат команды.\n"
            "📝 Использование: /setbalance [user_id] [amount]"
        )
    except Exception as e:
        logging.error(f"Ошибка в set_balance_handler: {e}")
        await message.answer("❌ Произошла ошибка при выполнении команды.")


@router.message(Command("maintenance"))
async def maintenance_command_handler(message: Message):
    """Быстрое переключение режима технических работ"""
    user_id = message.from_user.id
    
    if not is_admin(user_id):
        await message.answer("❌ У вас нет доступа к этой команде.")
        return
    
    # Если есть аргументы - устанавливаем сообщение
    args = message.text.split(maxsplit=1)
    if len(args) > 1:
        maintenance_message = args[1]
        set_maintenance_message(maintenance_message)
        await message.answer(f"📝 Сообщение о тех. работах обновлено:\n{maintenance_message}")
        return
    
    # Иначе переключаем режим
    result = toggle_maintenance_mode()
    status_text = "включен" if result['enabled'] else "выключен"
    
    await message.answer(
        f"🔧 {hbold('Режим технических работ')} {status_text}\n\n"
        f"📝 Сообщение: {result['message']}\n\n"
        f"💡 Для изменения сообщения используйте:\n"
        f"{hcode('/maintenance Ваше сообщение')}",
        parse_mode="HTML"
    )


@router.message(Command("delcontainer"))
async def delete_container_handler(message: Message):
    """Удаление контейнера по ID (только для админов)"""
    user_id = message.from_user.id
    
    if not is_admin(user_id):
        await message.answer("❌ У вас нет доступа к этой команде.")
        return
    
    try:
        args = message.text.split()
        if len(args) != 2:
            await message.answer(
                "📝 Использование: /delcontainer [container_id]\n"
                "Пример: /delcontainer 1"
            )
            return
        
        container_id = int(args[1])
        
        # Получаем информацию о контейнере
        from utils.database import get_container_by_id, delete_container_from_db
        from utils.docker_utils import delete_docker_container
        
        container = get_container_by_id(container_id)
        if not container:
            await message.answer(f"❌ Контейнер с ID {container_id} не найден")
            return
        
        # Удаляем Docker контейнер
        docker_success = delete_docker_container(container['docker_name'])
        
        # Удаляем из базы данных
        db_success = delete_container_from_db(container_id)
        
        if db_success:
            status = "✅ Контейнер удален из базы данных"
            if docker_success:
                status += " и Docker"
            else:
                status += " (Docker контейнер не найден или уже удален)"
            
            await message.answer(
                f"{status}\n"
                f"🆔 ID: {container_id}\n"
                f"👤 Пользователь: {container['user_id']}\n"
                f"📦 Имя: {container['docker_name']}"
            )
            
            log_admin_action(user_id, "delete_container", {
                "container_id": container_id,
                "user_id": container['user_id'],
                "docker_name": container['docker_name']
            })
        else:
            await message.answer("❌ Ошибка при удалении контейнера из базы данных")
    
    except ValueError:
        await message.answer("❌ Неверный формат. Используйте число для ID контейнера")
    except Exception as e:
        logging.error(f"Ошибка при удалении контейнера: {e}")
        await message.answer("❌ Произошла ошибка при удалении контейнера")


@router.message(Command("givecontainer"))
async def give_container_handler(message: Message):
    """Выдача контейнера пользователю по ID (только для админов)"""
    user_id = message.from_user.id
    
    if not is_admin(user_id):
        await message.answer("❌ У вас нет доступа к этой команде.")
        return
    
    try:
        args = message.text.split()
        if len(args) != 4:
            await message.answer(
                "📝 Использование: /givecontainer [user_id] [tariff] [period]\n"
                "Тарифы: standard, premium, ultimate\n"
                "Периоды: 1m, 3m, 6m, 1y\n"
                "Пример: /givecontainer 123456789 standard 1m"
            )
            return
        
        target_user_id = int(args[1])
        tariff = args[2]
        period = args[3]
        
        # Проверяем валидность тарифа и периода
        valid_tariffs = ['standard', 'premium', 'ultimate']
        valid_periods = ['1m', '3m', '6m', '1y']
        
        if tariff not in valid_tariffs:
            await message.answer(f"❌ Неверный тариф. Доступные: {', '.join(valid_tariffs)}")
            return
        
        if period not in valid_periods:
            await message.answer(f"❌ Неверный период. Доступные: {', '.join(valid_periods)}")
            return
        
        # Создаем контейнер
        from utils.docker_utils import create_userbot_container
        from utils.database import add_container_to_db, get_user_by_id
        
        # Проверяем существование пользователя
        user = get_user_by_id(target_user_id)
        if not user:
            await message.answer(f"❌ Пользователь с ID {target_user_id} не найден в базе данных")
            return
        
        container_result = create_userbot_container(target_user_id, tariff, period)
        
        if container_result['success']:
            # Добавляем в базу данных
            container_db_id = add_container_to_db(
                user_id=target_user_id,
                tariff=tariff,
                period=period,
                docker_name=container_result['container_name'],
                port=container_result['port']
            )
            
            await message.answer(
                f"✅ Контейнер успешно создан и выдан пользователю {target_user_id}\n"
                f"📦 Тариф: {tariff}\n"
                f"⏱ Период: {period}\n"
                f"🐳 Контейнер: {container_result['container_name']}\n"
                f"🔌 Порт: {container_result['port']}\n"
                f"🆔 ID в базе: {container_db_id}"
            )
            
            log_admin_action(user_id, "give_container", {
                "target_user": target_user_id,
                "tariff": tariff,
                "period": period,
                "container_name": container_result['container_name'],
                "port": container_result['port']
            })
        else:
            await message.answer(f"❌ Ошибка при создании контейнера: {container_result.get('error', 'Неизвестная ошибка')}")
    
    except ValueError:
        await message.answer("❌ Неверный формат. Используйте число для ID пользователя")
    except Exception as e:
        logging.error(f"Ошибка при выдаче контейнера: {e}")
        await message.answer("❌ Произошла ошибка при выдаче контейнера")


@router.message(Command("listcontainers"))
async def list_containers_handler(message: Message):
    """Список всех контейнеров (только для админов)"""
    user_id = message.from_user.id
    
    if not is_admin(user_id):
        await message.answer("❌ У вас нет доступа к этой команде.")
        return
    
    try:
        from utils.database import get_all_containers
        
        containers = get_all_containers()
        
        if not containers:
            await message.answer("📋 Контейнеры не найдены")
            return
        
        text = f"📋 {hbold('Все контейнеры')} ({len(containers)} шт.):\n\n"
        
        for container in containers:
            text += f"🔹 {hbold('ID:')} {container['id']}\n"
            text += f"👤 {hbold('Пользователь:')} {container['user_id']}\n"
            text += f"📦 {hbold('Тариф:')} {container['tariff']}\n"
            text += f"⏱ {hbold('Период:')} {container['period']}\n"
            text += f"🐳 {hbold('Контейнер:')} {container['docker_name']}\n"
            text += f"🔌 {hbold('Порт:')} {container['port']}\n"
            text += f"📅 {hbold('Создан:')} {container['created_at']}\n"
            text += "─" * 30 + "\n\n"
        
        # Разбиваем длинное сообщение на части
        if len(text) > 4000:
            chunks = [text[i:i+4000] for i in range(0, len(text), 4000)]
            for chunk in chunks:
                await message.answer(chunk, parse_mode="HTML")
        else:
            await message.answer(text, parse_mode="HTML")
    
    except Exception as e:
        logging.error(f"Ошибка при получении списка контейнеров: {e}")
        await message.answer("❌ Произошла ошибка при получении списка контейнеров")


@router.message(Command("help"))
async def help_command_handler(message: Message):
    """Показывает список всех доступных команд"""
    user_id = message.from_user.id
    
    # Обычные команды для всех пользователей
    help_text = f"📋 {hbold('Команды LufHost')}\n\n"
    help_text += f"🔹 {hcode('/start')} - Запуск бота и главное меню\n"
    help_text += f"🔹 {hcode('/help')} - Показать этот список команд\n\n"
    
    # Админские команды (только для админов)
    if is_admin(user_id):
        help_text += f"🛠 {hbold('Команды администратора:')}\n\n"
        help_text += f"🔹 {hcode('/admin')} - Открыть админ-панель\n"
        help_text += f"🔹 {hcode('/users')} - Статистика пользователей\n"
        help_text += f"🔹 {hcode('/maintenance')} - Переключить режим тех. работ\n"
        help_text += f"🔹 {hcode('/setbalance [user_id] [amount]')} - Установить баланс пользователю\n\n"
        
        help_text += f"📦 {hbold('Управление контейнерами:')}\n\n"
        help_text += f"🔹 {hcode('/listcontainers')} - Показать все контейнеры\n"
        help_text += f"🔹 {hcode('/givecontainer [user_id] [tariff] [period]')} - Выдать контейнер\n"
        help_text += f"🔹 {hcode('/delcontainer [container_id]')} - Удалить контейнер\n\n"
        
        help_text += f"💡 {hbold('Примеры:')}\n"
        help_text += f"• {hcode('/setbalance 123456789 1000')}\n"
        help_text += f"• {hcode('/givecontainer 123456789 standard 1m')}\n"
        help_text += f"• {hcode('/delcontainer 1')}\n\n"
        
        help_text += f"📌 {hbold('Доступные тарифы:')} standard, premium, ultimate\n"
        help_text += f"📌 {hbold('Доступные периоды:')} 1m, 3m, 6m, 1y"
    else:
        help_text += f"💡 {hbold('Навигация:')} Используйте кнопки в меню для удобной навигации\n"
        help_text += f"📞 {hbold('Поддержка:')} Обратитесь к администратору через меню бота"
    
    await message.answer(help_text, parse_mode="HTML")
