#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LufHost Handlers Module
Модуль обработчиков для бота
"""

from aiogram import Router

# Импортируем роутеры из каждого модуля обработчиков
from . import common
from . import profile
from . import settings
from . import userbots
from . import errors
from . import admin
from . import payment

# Собираем все роутеры в один главный роутер
handlers_router = Router()
handlers_router.include_router(common.router)
handlers_router.include_router(profile.router)
handlers_router.include_router(settings.router)
handlers_router.include_router(userbots.router)
handlers_router.include_router(payment.router)
handlers_router.include_router(admin.router)
handlers_router.include_router(errors.router)  # errors.router должен идти последним, чтобы ловить необработанные колбэки
