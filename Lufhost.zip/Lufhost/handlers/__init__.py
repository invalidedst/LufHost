#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LufHost Handlers Module
Модуль обработчиков для бота
"""

from aiogram import Router

# Импортируем роутеры из каждого модуля обработчиков
from . import common
from . import profile
from . import settings
from . import userbots
from . import errors
from . import admin
from . import payment

# Собираем все роутеры в один главный роутер
handlers_router = Router()
handlers_router.include_routers(
    common.router,
    profile.router,
    settings.router,
    userbots.router,
    payment.router,
    admin.router,
    errors.router,  # errors.router должен идти последним, чтобы ловить необработанные колбэки
)
