#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Пример интеграции Docker VDS Manager с Telegram ботом
"""

import asyncio
from docker_vds_manager import create_userbot_for_telegram_user, get_user_containers_list, manage_container

# Примеры функций для добавления в ваш бот

async def handle_buy_userbot(user_id: int, message_obj):
    """
    Обработчик покупки юзербота
    Вызывается когда пользователь нажимает "Купить юзербот"
    """
    try:
        # Создаем контейнер для пользователя
        result = await create_userbot_for_telegram_user(user_id)
        
        if result["success"]:
            # Успешно создан
            response = f"""
✅ Юзербот создан!

📦 Контейнер: {result['container_name']}
🌐 Доступ: {result['url']}
🔌 Порт: {result['port']}

Ваш юзербот запущен и готов к работе!
            """
            
            # Отправляем сообщение пользователю
            await message_obj.answer(response)
            
        else:
            # Ошибка создания
            error_msg = f"❌ Ошибка создания юзербота: {result['error']}"
            await message_obj.answer(error_msg)
            
    except Exception as e:
        await message_obj.answer(f"❌ Произошла ошибка: {str(e)}")

async def handle_list_userbots(user_id: int, message_obj):
    """
    Показать список юзерботов пользователя
    """
    try:
        containers = await get_user_containers_list(user_id)
        
        if containers:
            response = "📋 Ваши юзерботы:\n\n"
            
            for i, container in enumerate(containers, 1):
                status_emoji = "✅" if "Up" in container["status"] else "❌"
                response += f"{i}. {status_emoji} {container['name']}\n"
                response += f"   📊 Статус: {container['status']}\n"
                response += f"   🔌 Порты: {container['ports']}\n\n"
                
            await message_obj.answer(response)
        else:
            await message_obj.answer("📋 У вас пока нет юзерботов")
            
    except Exception as e:
        await message_obj.answer(f"❌ Ошибка получения списка: {str(e)}")

async def handle_container_action(user_id: int, container_name: str, action: str, message_obj):
    """
    Управление контейнером (start/stop/remove)
    """
    try:
        # Проверяем, что контейнер принадлежит пользователю
        if not container_name.startswith(f"userbot_{user_id}"):
            await message_obj.answer("❌ Этот контейнер вам не принадлежит")
            return
        
        # Выполняем действие
        success = await manage_container(container_name, action)
        
        if success:
            action_texts = {
                "start": "запущен",
                "stop": "остановлен", 
                "remove": "удален"
            }
            
            response = f"✅ Контейнер {container_name} {action_texts.get(action, 'обновлен')}"
            await message_obj.answer(response)
        else:
            await message_obj.answer(f"❌ Не удалось {action} контейнер")
            
    except Exception as e:
        await message_obj.answer(f"❌ Ошибка: {str(e)}")

# Пример добавления в существующий бот
"""
Добавьте эти функции в ваш userbots_1751548412827.py:

1. В функцию buy_userbot_handler замените создание контейнера:
   result = await handle_buy_userbot(user_id, message)

2. В функцию list_userbots_handler добавьте:
   await handle_list_userbots(user_id, message)

3. В функцию container_action_handler добавьте:
   await handle_container_action(user_id, container_name, action, message)
"""

# Пример использования в коде бота
async def example_bot_usage():
    """Пример использования в боте"""
    
    # Когда пользователь хочет купить юзербот
    user_id = 123456789
    
    print("Создание юзербота...")
    result = await create_userbot_for_telegram_user(user_id)
    
    if result["success"]:
        print(f"✅ Юзербот создан: {result['container_name']}")
        print(f"🌐 Доступ: {result['url']}")
        
        # Показать список
        print("\nСписок контейнеров:")
        containers = await get_user_containers_list(user_id)
        for container in containers:
            print(f"- {container['name']}: {container['status']}")
            
    else:
        print(f"❌ Ошибка: {result['error']}")

if __name__ == "__main__":
    # Запуск примера
    asyncio.run(example_bot_usage())