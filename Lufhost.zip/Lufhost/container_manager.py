#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LufHost Container Manager
Автоматическое создание и управление контейнерами для юзерботов
"""

import docker
import logging
import json
import os
import tempfile
from pathlib import Path
from typing import Dict, List, Optional

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ContainerManager:
    def __init__(self):
        try:
            self.docker_client = docker.from_env()
            logger.info("Docker клиент подключен")
        except Exception as e:
            logger.error(f"Ошибка подключения к Docker: {e}")
            self.docker_client = None
    
    def create_userbot_container(self, user_id: int, telegram_id: str) -> Dict:
        """Создание контейнера для юзербота"""
        if not self.docker_client:
            return {"success": False, "error": "Docker недоступен"}
        
        try:
            container_name = f"userbot_{telegram_id}_{user_id}"
            
            # Проверяем, существует ли уже контейнер
            existing = self.get_container_by_name(container_name)
            if existing:
                return {
                    "success": False,
                    "error": f"Контейнер {container_name} уже существует"
                }
            
            # Создаем Dockerfile для юзербота
            dockerfile_content = self._create_userbot_dockerfile()
            
            # Создаем временную папку для сборки
            with tempfile.TemporaryDirectory() as temp_dir:
                dockerfile_path = Path(temp_dir) / "Dockerfile"
                with open(dockerfile_path, 'w') as f:
                    f.write(dockerfile_content)
                
                # Создаем образ
                image_tag = f"lufhost-userbot:{user_id}"
                logger.info(f"Создаю образ {image_tag}...")
                
                image, build_logs = self.docker_client.images.build(
                    path=str(temp_dir),
                    tag=image_tag,
                    rm=True
                )
                
                # Создаем контейнер
                port = self._get_available_port()
                
                container = self.docker_client.containers.create(
                    image=image_tag,
                    name=container_name,
                    ports={'8080/tcp': port},
                    environment={
                        'USER_ID': str(user_id),
                        'TELEGRAM_ID': str(telegram_id),
                        'PORT': '8080'
                    },
                    restart_policy={"Name": "unless-stopped"},
                    detach=True
                )
                
                # Запускаем контейнер
                container.start()
                
                logger.info(f"Контейнер {container_name} создан и запущен")
                
                return {
                    "success": True,
                    "container_name": container_name,
                    "container_id": container.id,
                    "port": port,
                    "url": f"http://localhost:{port}",
                    "status": "running"
                }
                
        except Exception as e:
            logger.error(f"Ошибка создания контейнера: {e}")
            return {"success": False, "error": str(e)}
    
    def _create_userbot_dockerfile(self) -> str:
        """Создание Dockerfile для юзербота"""
        return """
FROM python:3.10-slim

# Установка системных зависимостей
RUN apt-get update && apt-get install -y \\
    git \\
    curl \\
    && rm -rf /var/lib/apt/lists/*

# Создание пользователя
RUN useradd -m -s /bin/bash userbot

# Установка Python зависимостей
RUN pip install --no-cache-dir \\
    aiogram>=3.0.0 \\
    python-dotenv \\
    aiofiles \\
    aiohttp \\
    requests \\
    asyncio

# Создание рабочей директории
WORKDIR /app
RUN chown userbot:userbot /app

# Переключение на пользователя
USER userbot

# Копирование базового юзербота
COPY --chown=userbot:userbot userbot_template/ /app/

# Создание стартового скрипта
RUN echo '#!/bin/bash\\n\\
echo "Запуск юзербота для пользователя $USER_ID"\\n\\
echo "Telegram ID: $TELEGRAM_ID"\\n\\
echo "Порт: $PORT"\\n\\
\\n\\
# Проверка наличия токена\\n\\
if [ -z "$BOT_TOKEN" ]; then\\n\\
    echo "ОШИБКА: BOT_TOKEN не установлен"\\n\\
    echo "Установите токен через веб-интерфейс"\\n\\
    sleep 30\\n\\
    exit 1\\n\\
fi\\n\\
\\n\\
# Запуск бота\\n\\
python3 main.py' > /app/start.sh

RUN chmod +x /app/start.sh

# Создание базового main.py
RUN echo 'import asyncio\\n\\
import logging\\n\\
import os\\n\\
from aiogram import Bot, Dispatcher\\n\\
from aiogram.filters import CommandStart\\n\\
from aiogram.types import Message\\n\\
\\n\\
logging.basicConfig(level=logging.INFO)\\n\\
\\n\\
BOT_TOKEN = os.getenv("BOT_TOKEN")\\n\\
USER_ID = os.getenv("USER_ID")\\n\\
TELEGRAM_ID = os.getenv("TELEGRAM_ID")\\n\\
\\n\\
if not BOT_TOKEN:\\n\\
    print("ОШИБКА: BOT_TOKEN не установлен")\\n\\
    exit(1)\\n\\
\\n\\
bot = Bot(token=BOT_TOKEN)\\n\\
dp = Dispatcher()\\n\\
\\n\\
@dp.message(CommandStart())\\n\\
async def start_handler(message: Message):\\n\\
    await message.answer(f"Привет! Я юзербот пользователя {TELEGRAM_ID}")\\n\\
\\n\\
@dp.message()\\n\\
async def echo_handler(message: Message):\\n\\
    await message.answer(f"Эхо: {message.text}")\\n\\
\\n\\
async def main():\\n\\
    print(f"Запуск юзербота для пользователя {USER_ID} ({TELEGRAM_ID})")\\n\\
    await dp.start_polling(bot)\\n\\
\\n\\
if __name__ == "__main__":\\n\\
    asyncio.run(main())' > /app/main.py

EXPOSE 8080

CMD ["/app/start.sh"]
"""
    
    def _get_available_port(self) -> int:
        """Получение свободного порта"""
        import socket
        
        # Начинаем с порта 8000
        for port in range(8000, 9000):
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.bind(('', port))
                    return port
            except OSError:
                continue
        
        raise Exception("Нет свободных портов")
    
    def get_container_by_name(self, name: str) -> Optional[docker.models.containers.Container]:
        """Получение контейнера по имени"""
        if not self.docker_client:
            return None
            
        try:
            return self.docker_client.containers.get(name)
        except docker.errors.NotFound:
            return None
        except Exception as e:
            logger.error(f"Ошибка получения контейнера {name}: {e}")
            return None
    
    def list_user_containers(self, user_id: int) -> List[Dict]:
        """Список контейнеров пользователя"""
        if not self.docker_client:
            return []
        
        try:
            containers = []
            all_containers = self.docker_client.containers.list(all=True)
            
            for container in all_containers:
                if container.name.startswith(f"userbot_") and f"_{user_id}" in container.name:
                    containers.append({
                        "name": container.name,
                        "id": container.id,
                        "status": container.status,
                        "ports": container.ports,
                        "created": container.attrs['Created']
                    })
            
            return containers
            
        except Exception as e:
            logger.error(f"Ошибка получения списка контейнеров: {e}")
            return []
    
    def start_container(self, container_name: str) -> Dict:
        """Запуск контейнера"""
        try:
            container = self.get_container_by_name(container_name)
            if not container:
                return {"success": False, "error": "Контейнер не найден"}
            
            container.start()
            logger.info(f"Контейнер {container_name} запущен")
            
            return {"success": True, "message": "Контейнер запущен"}
            
        except Exception as e:
            logger.error(f"Ошибка запуска контейнера {container_name}: {e}")
            return {"success": False, "error": str(e)}
    
    def stop_container(self, container_name: str) -> Dict:
        """Остановка контейнера"""
        try:
            container = self.get_container_by_name(container_name)
            if not container:
                return {"success": False, "error": "Контейнер не найден"}
            
            container.stop()
            logger.info(f"Контейнер {container_name} остановлен")
            
            return {"success": True, "message": "Контейнер остановлен"}
            
        except Exception as e:
            logger.error(f"Ошибка остановки контейнера {container_name}: {e}")
            return {"success": False, "error": str(e)}
    
    def restart_container(self, container_name: str) -> Dict:
        """Перезапуск контейнера"""
        try:
            container = self.get_container_by_name(container_name)
            if not container:
                return {"success": False, "error": "Контейнер не найден"}
            
            container.restart()
            logger.info(f"Контейнер {container_name} перезапущен")
            
            return {"success": True, "message": "Контейнер перезапущен"}
            
        except Exception as e:
            logger.error(f"Ошибка перезапуска контейнера {container_name}: {e}")
            return {"success": False, "error": str(e)}
    
    def remove_container(self, container_name: str) -> Dict:
        """Удаление контейнера"""
        try:
            container = self.get_container_by_name(container_name)
            if not container:
                return {"success": False, "error": "Контейнер не найден"}
            
            # Останавливаем если запущен
            if container.status == 'running':
                container.stop()
            
            container.remove()
            logger.info(f"Контейнер {container_name} удален")
            
            return {"success": True, "message": "Контейнер удален"}
            
        except Exception as e:
            logger.error(f"Ошибка удаления контейнера {container_name}: {e}")
            return {"success": False, "error": str(e)}
    
    def get_container_logs(self, container_name: str) -> Dict:
        """Получение логов контейнера"""
        try:
            container = self.get_container_by_name(container_name)
            if not container:
                return {"success": False, "error": "Контейнер не найден"}
            
            logs = container.logs(tail=100).decode('utf-8')
            
            return {"success": True, "logs": logs}
            
        except Exception as e:
            logger.error(f"Ошибка получения логов {container_name}: {e}")
            return {"success": False, "error": str(e)}

# Глобальный экземпляр менеджера
container_manager = ContainerManager()

# Функции для интеграции с ботом
async def create_userbot_for_telegram_user(user_id: int, telegram_id: str = None) -> Dict:
    """Создание юзербота для пользователя Telegram"""
    if not telegram_id:
        telegram_id = str(user_id)
    
    return container_manager.create_userbot_container(user_id, telegram_id)

async def get_user_containers_list(user_id: int) -> List[Dict]:
    """Получение списка контейнеров пользователя"""
    return container_manager.list_user_containers(user_id)

async def manage_container(container_name: str, action: str) -> bool:
    """Управление контейнером"""
    if action == "start":
        result = container_manager.start_container(container_name)
    elif action == "stop":
        result = container_manager.stop_container(container_name)
    elif action == "restart":
        result = container_manager.restart_container(container_name)
    elif action == "remove":
        result = container_manager.remove_container(container_name)
    else:
        return False
    
    return result.get("success", False)

async def get_container_logs_for_user(container_name: str) -> str:
    """Получение логов контейнера"""
    result = container_manager.get_container_logs(container_name)
    if result.get("success"):
        return result.get("logs", "")
    else:
        return f"Ошибка: {result.get('error', 'Неизвестная ошибка')}"