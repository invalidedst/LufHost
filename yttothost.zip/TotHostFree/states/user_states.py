from aiogram.fsm.state import State, StatesGroup

# ------ FSM для пополнения баланса ------
class BalanceTopUp(StatesGroup):
    waiting_for_payment_method = State()
    waiting_for_amount = State()

# ------ FSM для настроек валюты ------
class CurrencySettings(StatesGroup):
    waiting_for_currency_choice = State()

# ------ FSM для покупки юзербота ------
class BuyUserbot(StatesGroup):
    waiting_for_tariff_choice = State() # Возможно, не понадобится, если сразу выбираем тариф кнопкой
    waiting_for_period_choice = State()