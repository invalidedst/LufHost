# --- START OF FILE handlers/common.py ---

import logging
import os
from aiogram import Router, F, Bot
from aiogram.filters import CommandStart
from aiogram.types import Message, CallbackQuery, FSInputFile
from aiogram.utils.markdown import hbold, hlink

from keyboards.inline import (
    setup_main_menu_keyboard,
    setup_agreement_keyboard
)
# ИМПОРТИРУЕМ НОВЫЕ ФУНКЦИИ БАЗЫ ДАННЫХ
from utils.database import (
    check_user_agreement,
    record_user_agreement,
    create_user_if_not_exists # Заменили txt_create_user_if_not_exists
)
from config import IMG_MAIN

router = Router()

async def show_main_menu(target, bot: Bot):
    """
    Отображает главное меню (может быть вызвано для Message или CallbackQuery).
    `target` - объект Message или CallbackQuery.
    `bot` - экземпляр бота.
    """
    user_id = target.from_user.id
    user_name = target.from_user.full_name
    chat_id = target.message.chat.id if isinstance(target, CallbackQuery) else target.chat.id

    # Создание пользователя в БД, если его нет (на случай, если /start пропущен)
    # Используем новую функцию
    create_user_if_not_exists(user_id)

    markup = setup_main_menu_keyboard()
    welcome_text = (
        f"👋 Привет, {hbold(user_name)}!\n\n"
        f"🤔 Это {hbold('неофициальный')} бот хостинга юзерботов "
        f"{hlink('ToTHosting', 'https://t.me/ToThosTing')}!"
    )

    try:
        photo = FSInputFile(IMG_MAIN)
        logging.debug(f"Отправка главного меню (фото+текст) в чат {chat_id}")
        # Используем send_photo, если он есть, иначе send_message
        if isinstance(target, CallbackQuery):
            # При колбэке лучше редактировать или отправлять новое и удалять старое
            await bot.send_photo(
                chat_id,
                photo=photo,
                caption=welcome_text,
                reply_markup=markup.as_markup(),
                parse_mode="HTML"
            )
            try:
                await target.message.delete()
            except Exception as e:
                logging.warning(f"Не удалось удалить сообщение в show_main_menu (callback) для {user_id}: {e}")
        else: # Если это Message
             await bot.send_photo(
                chat_id,
                photo=photo,
                caption=welcome_text,
                reply_markup=markup.as_markup(),
                parse_mode="HTML"
            )

    except FileNotFoundError:
        logging.error(f"Фото главного меню не найдено: {IMG_MAIN}. Отправляю текст.")
        if isinstance(target, CallbackQuery):
            try:
                # Пытаемся отредактировать предыдущее сообщение (если оно было текстовым или с фото)
                await target.message.edit_caption(caption=welcome_text, reply_markup=markup.as_markup(), parse_mode="HTML")
            except Exception:
                 try:
                      await target.message.edit_text(welcome_text, reply_markup=markup.as_markup(), parse_mode="HTML")
                 except Exception as e:
                     logging.error(f"Не удалось отредактировать сообщение в show_main_menu (callback, text fallback): {e}")
                     # Отправляем новое, если редактирование не удалось
                     await bot.send_message(chat_id, welcome_text, reply_markup=markup.as_markup(), parse_mode="HTML")
                     try: await target.message.delete()
                     except Exception: pass
        else:
             await bot.send_message(chat_id, welcome_text, reply_markup=markup.as_markup(), parse_mode="HTML")

    except Exception as e:
        logging.error(f"Ошибка при отправке главного меню в чат {chat_id}: {e}", exc_info=True)
        # Fallback на текст в любом случае при другой ошибке
        if isinstance(target, CallbackQuery):
             try: await target.message.edit_text(welcome_text, reply_markup=markup.as_markup(), parse_mode="HTML")
             except Exception: await bot.send_message(chat_id, welcome_text, reply_markup=markup.as_markup(), parse_mode="HTML") # Если редактирование не удалось
        else:
             await bot.send_message(chat_id, welcome_text, reply_markup=markup.as_markup(), parse_mode="HTML")


@router.message(CommandStart())
async def command_start_handler(message: Message, bot: Bot):
    user_id = message.from_user.id
    logging.info(f"Пользователь {user_id} ({message.from_user.username}) нажал /start")

    # Используем новую функцию проверки соглашения
    if not check_user_agreement(user_id):
        markup_agreement = setup_agreement_keyboard()
        agreement_text = """
⚠️ *Политика использования неофициального бота ToTHosting* ⚠️

> Вы используете *неофициальный* бот для управления юзерботами хостинга ToTHosting\.

> *Важно понимать следующее:*

> 1\. *Неофициальный статус:* Этот бот разработан сторонним разработчиком и не является официальным продуктом ToTHosting\.
> 2\. *Тестовое использование:* Бот предоставляется для целей тестирования и ознакомления с возможностями управления\.
> 3\. *Отсутствие ответственности:* Разработчики хостинга ToTHosting и создатель этого бота не несут ответственности за возможные блокировки ваших Telegram аккаунтов или иные последствия, связанные с использованием данного бота\.
> 4\. *Использование на свой страх и риск:* Вы используете этого бота на свой страх и риск\. Пожалуйста, соблюдайте меры предосторожности и правила использования Telegram\.

> Нажимая кнопку «Согласен», вы подтверждаете, что ознакомлены и согласны с вышеуказанными условиями использования неофициального бота\.

*Для продолжения использования бота, пожалуйста, примите соглашение\.*
        """
        try:
            await message.answer(
                text=agreement_text,
                reply_markup=markup_agreement.as_markup(),
                parse_mode="MarkdownV2"
            )
            logging.info(f"Пользователю {user_id} отправлено сообщение о соглашении.")
        except Exception as e:
            logging.error(f"Не удалось отправить сообщение о соглашении пользователю {user_id}: {e}")
    else:
        logging.info(f"Пользователь {user_id} уже принял соглашение.")
        # Создаем пользователя, если его еще нет (на всякий случай, если он принял, но запись удалилась)
        create_user_if_not_exists(user_id, agreed=True) # Передаем флаг согласия
        await show_main_menu(message, bot)


@router.callback_query(F.data == "agree_policy")
async def agreement_handler(query: CallbackQuery, bot: Bot):
    user_id = query.from_user.id
    # Используем новую функцию записи соглашения
    record_user_agreement(user_id) # Эта функция теперь сама может создать пользователя
    logging.info(f"Пользователь {user_id} принял соглашение (записано в БД).")
    await query.answer("✅ Соглашение принято.", show_alert=False)

    # Показываем главное меню после принятия
    await show_main_menu(query, bot)


@router.callback_query(F.data == "main_menu")
async def back_to_main_menu_handler(query: CallbackQuery, bot: Bot):
    """ Обработчик для кнопок 'Назад', ведущих в главное меню """
    await query.answer() # Отвечаем на колбэк
    await show_main_menu(query, bot)
# --- END OF FILE handlers/common.py ---