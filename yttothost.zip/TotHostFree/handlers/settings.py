# --- START OF FILE handlers/settings.py ---

import logging
from aiogram import Router, F, Bot
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, CallbackQuery, FSInputFile
from aiogram.utils.markdown import hbold

from keyboards.inline import setup_settings_keyboard, setup_select_currency_keyboard
from states.user_states import CurrencySettings
# ИМПОРТИРУЕМ НОВЫЕ ФУНКЦИИ БАЗЫ ДАННЫХ
from utils.database import set_user_currency, get_user_currency, create_user_if_not_exists
from config import IMG_SETTINGS

router = Router()

async def show_settings_message(target, bot: Bot):
    """ Отображает сообщение настроек """
    user_id = target.from_user.id
    chat_id = target.message.chat.id if isinstance(target, CallbackQuery) else target.chat.id
    # Убедимся, что пользователь есть в БД
    create_user_if_not_exists(user_id)
    markup = setup_settings_keyboard()
    settings_text = f"⚙️ {hbold('Настройки')}\n\n❔ Что вы хотите настроить?"

    # Логика отправки сообщения с фото или текстом (аналогично profile.py)
    photo_sent = False
    try:
        photo = FSInputFile(IMG_SETTINGS)
        if isinstance(target, CallbackQuery):
            await bot.send_photo(
                chat_id, photo=photo, caption=settings_text,
                reply_markup=markup.as_markup(), parse_mode="HTML"
            )
            try: await target.message.delete()
            except Exception: pass
        else:
             await bot.send_photo(
                 chat_id, photo=photo, caption=settings_text,
                 reply_markup=markup.as_markup(), parse_mode="HTML"
             )
        photo_sent = True
    except FileNotFoundError:
        logging.error(f"Фото настроек не найдено: {IMG_SETTINGS}. Отправляю текст.")
    except Exception as e:
        logging.error(f"Ошибка при отправке настроек с фото для {user_id}: {e}", exc_info=True)

    if not photo_sent:
        try:
            if isinstance(target, CallbackQuery):
                 try: await target.message.edit_caption(caption=settings_text, reply_markup=markup.as_markup(), parse_mode="HTML")
                 except Exception: await target.message.edit_text(settings_text, reply_markup=markup.as_markup(), parse_mode="HTML")
            else:
                 await bot.send_message(chat_id, settings_text, reply_markup=markup.as_markup(), parse_mode="HTML")
        except Exception as e:
             logging.error(f"Критическая ошибка при отправке/редактировании настроек (текст) для {user_id}: {e}", exc_info=True)
             if isinstance(target, CallbackQuery):
                  await bot.send_message(chat_id, settings_text, reply_markup=markup.as_markup(), parse_mode="HTML")


@router.callback_query(F.data == "settings")
async def settings_handler(query: CallbackQuery, bot: Bot):
    await query.answer()
    await show_settings_message(query, bot)


@router.callback_query(F.data == "select_currency")
async def select_currency_handler(query: CallbackQuery, state: FSMContext):
    markup = setup_select_currency_keyboard()
    # Используем новую функцию
    current_currency = get_user_currency(query.from_user.id)
    # Редактируем предыдущее сообщение (настройки)
    try:
        await query.message.edit_caption(
            caption=f"⚙️ Настройки\n\n"
                    f"Текущая валюта: {hbold(current_currency)}\n"
                    f"📋 Выберите новую валюту:",
            reply_markup=markup.as_markup(),
            parse_mode="HTML"
        )
    except Exception: # Если было текстом
         await query.message.edit_text(
             f"⚙️ Настройки\n\n"
             f"Текущая валюта: {hbold(current_currency)}\n"
             f"📋 Выберите новую валюту:",
             reply_markup=markup.as_markup(),
             parse_mode="HTML"
         )
    await query.answer()
    await state.set_state(CurrencySettings.waiting_for_currency_choice)


@router.callback_query(CurrencySettings.waiting_for_currency_choice, F.data.startswith("currency_"))
async def currency_choice_handler(query: CallbackQuery, state: FSMContext, bot: Bot):
    try:
        if len(query.data.split('_')) < 2:
             raise ValueError(f"Некорректный callback_data: {query.data}")

        currency = query.data.split('_')[1].upper()
        user_id = query.from_user.id

        allowed_currencies = ["RUB", "UAH", "KZT", "USD"]
        if currency not in allowed_currencies:
            raise ValueError(f"Недопустимая валюта: {currency}")

        # Используем новую функцию
        success = set_user_currency(user_id, currency)

        if success:
            logging.info(f"Пользователь {user_id} изменил валюту на {currency}")
            await query.answer(f"✅ Валюта изменена на {currency}")
            await state.clear()
            # Возврат в настройки
            await show_settings_message(query, bot)
        else:
             await query.answer("❌ Ошибка при сохранении валюты.", show_alert=True)
             await state.clear()
             await show_settings_message(query, bot)

    except (IndexError, ValueError) as e:
        logging.error(f"Ошибка выбора валюты: {e}. Callback data: {query.data}")
        await query.answer("❌ Ошибка выбора валюты.", show_alert=True)
        await state.clear()
        await show_settings_message(query, bot) # Возврат в настройки при ошибке
    except Exception as e:
        logging.error(f"Непредвиденная ошибка в currency_choice_handler для {query.from_user.id}: {e}", exc_info=True)
        await query.answer("❌ Произошла ошибка.", show_alert=True)
        await state.clear()
        await show_settings_message(query, bot)


@router.callback_query(F.data == "back_to_settings")
async def back_to_settings_handler(query: CallbackQuery, state: FSMContext, bot: Bot):
    current_state = await state.get_state()
    if current_state == CurrencySettings.waiting_for_currency_choice:
        await state.clear()
        logging.info(f"State cleared for user {query.from_user.id} returning to settings.")

    await query.answer()
    await show_settings_message(query, bot)
# --- END OF FILE handlers/settings.py ---