# --- START OF FILE handlers/profile.py ---

import logging
import asyncio # <<< --- ДОБАВЛЕН ИМПОРТ ASYNCIO ---
from aiogram import Router, F, Bot
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, CallbackQuery, FSInputFile
from aiogram.utils.markdown import hbold, hcode
from aiogram.exceptions import TelegramBadRequest

from keyboards.inline import (
    setup_profile_keyboard,
    setup_top_up_balance_keyboard,
    setup_cancel_top_up_keyboard
)
from states.user_states import BalanceTopUp
from utils.database import (
    get_user_balance, get_user_currency, get_user_reg_date,
    set_user_balance, create_user_if_not_exists, get_user_data
)
from config import IMG_PROFILE, BALANCE_DEFAULT, CURRENCY_DEFAULT, REG_DATE_DEFAULT

router = Router()

async def show_profile_message(target, bot: Bot):
    """ Отображает сообщение профиля """
    user_id = target.from_user.id
    chat_id = target.message.chat.id if isinstance(target, CallbackQuery) else target.chat.id
    user_name = target.from_user.full_name

    create_user_if_not_exists(user_id)
    balance = get_user_balance(user_id)
    currency = get_user_currency(user_id)
    reg_date = get_user_reg_date(user_id)

    markup = setup_profile_keyboard()

    try:
        balance_str = f"{float(balance):.2f}"
    except (ValueError, TypeError):
        balance_str = f"{BALANCE_DEFAULT:.2f}"

    profile_text = (
        f"💻 {hbold('Профиль')}\n\n"
        f"👤 | Имя: {hbold(user_name)}\n"
        f"🆔 | ID: {hcode(user_id)}\n"
        f"💰 | Баланс: {hbold(balance_str)} {currency}\n"
        f"🗓 | Дата регистрации: {reg_date}\n\n"
        f"🎫 Ваша реферальная ссылка: В этой версии ToThosT её нету!"
    )

    photo_sent = False
    message_to_delete = target.message if isinstance(target, CallbackQuery) else None

    try:
        photo = FSInputFile(IMG_PROFILE)
        await bot.send_photo(
            chat_id, photo=photo, caption=profile_text,
            reply_markup=markup.as_markup(), parse_mode="HTML"
        )
        photo_sent = True
        if message_to_delete:
            try: await message_to_delete.delete()
            except Exception: pass
    except FileNotFoundError:
        logging.error(f"Фото профиля не найдено: {IMG_PROFILE}. Отправляю текст.")
    except Exception as e:
        logging.error(f"Ошибка при отправке профиля с фото для {user_id}: {e}", exc_info=True)

    if not photo_sent:
        try:
            if isinstance(target, CallbackQuery):
                 try: await target.message.edit_caption(caption=profile_text, reply_markup=markup.as_markup(), parse_mode="HTML")
                 except Exception:
                     try:
                         await target.message.edit_text(profile_text, reply_markup=markup.as_markup(), parse_mode="HTML")
                     except TelegramBadRequest as e_edit:
                         if "message can't be edited" in str(e_edit):
                             logging.warning("Сообщение профиля не может быть отредактировано, отправляю новое.")
                             await bot.send_message(chat_id, profile_text, reply_markup=markup.as_markup(), parse_mode="HTML")
                             if message_to_delete:
                                 try: await message_to_delete.delete()
                                 except Exception: pass
                         else: raise e_edit
            else:
                 await bot.send_message(chat_id, profile_text, reply_markup=markup.as_markup(), parse_mode="HTML")
        except Exception as e:
            logging.error(f"Критическая ошибка при отправке/редактировании профиля (текст) для {user_id}: {e}", exc_info=True)
            if isinstance(target, CallbackQuery):
                 await bot.send_message(chat_id, profile_text, reply_markup=markup.as_markup(), parse_mode="HTML")
                 if message_to_delete:
                     try: await message_to_delete.delete()
                     except Exception: pass


@router.callback_query(F.data == "profile")
async def profile_handler(query: CallbackQuery, bot: Bot):
    await query.answer()
    await show_profile_message(query, bot)


@router.callback_query(F.data == "top_up_balance")
async def top_up_balance_handler(query: CallbackQuery, state: FSMContext):
    markup = setup_top_up_balance_keyboard()
    text = "💰 Пополнение баланса\n\n🗳 Выберите способ пополнения:"
    try:
        await query.message.edit_caption(caption=text, reply_markup=markup.as_markup())
    except TelegramBadRequest as e:
         if "there is no caption" in str(e) or "message can't be edited" in str(e) or "there is no text" in str(e):
             try: await query.message.edit_text(text, reply_markup=markup.as_markup())
             except Exception as e_text:
                 logging.error(f"Не удалось отредактировать сообщение (text) в top_up_balance_handler: {e_text}")
                 await query.answer("Не удалось обновить сообщение.", show_alert=True)
                 return
         else:
             logging.error(f"Неожиданная ошибка BadRequest в top_up_balance_handler: {e}")
             await query.answer("Ошибка при обновлении сообщения.", show_alert=True)
             return
    except Exception as e:
        logging.error(f"Ошибка при редактировании сообщения в top_up_balance_handler: {e}")
        await query.answer("Ошибка.", show_alert=True)
        return

    await query.answer()
    await state.set_state(BalanceTopUp.waiting_for_payment_method)


@router.callback_query(BalanceTopUp.waiting_for_payment_method, F.data == "russian_cards")
async def russian_cards_handler(query: CallbackQuery, state: FSMContext):
    markup = setup_cancel_top_up_keyboard()
    new_text = (
        "💰 Пополнение баланса (Карты РФ)\n\n"
        "⌨️ Введите сумму пополнения в рублях (например, 100 или 50.5):"
    )
    edited_message = None
    try:
        edited_message = await query.message.edit_caption(caption=new_text, reply_markup=markup.as_markup())
    except TelegramBadRequest as e:
        if "there is no caption" in str(e) or "message can't be edited" in str(e) or "there is no text" in str(e):
             try: edited_message = await query.message.edit_text(new_text, reply_markup=markup.as_markup())
             except Exception as e_text:
                  logging.error(f"Не удалось отредактировать сообщение ни как caption, ни как text в russian_cards_handler: {e_text}")
                  await query.answer("Не удалось обновить сообщение.", show_alert=True)
                  return
        else:
            logging.error(f"Неожиданная ошибка BadRequest при редактировании в russian_cards_handler: {e}")
            await query.answer("Ошибка при обновлении сообщения.", show_alert=True)
            return
    except Exception as e:
        logging.error(f"Ошибка при редактировании сообщения в russian_cards_handler: {e}")
        await query.answer("Ошибка.", show_alert=True)
        return

    if edited_message:
        await state.update_data(prompt_message_id=edited_message.message_id)
        logging.debug(f"Сохранен ID сообщения ({edited_message.message_id}) для запроса суммы.")
    else:
         logging.warning("Не удалось получить edited_message в russian_cards_handler.")

    await query.answer()
    await state.set_state(BalanceTopUp.waiting_for_amount)


@router.message(BalanceTopUp.waiting_for_amount)
async def process_top_up_amount(message: Message, state: FSMContext, bot: Bot):
    user_id = message.from_user.id
    amount_text = message.text
    current_balance = get_user_balance(user_id)
    fsm_data = await state.get_data()
    prompt_message_id = fsm_data.get("prompt_message_id")
    await state.clear() # Очищаем состояние

    # Сохраняем ID сообщения пользователя перед попыткой удаления
    user_message_id = message.message_id

    try:
        amount = float(amount_text.replace(',', '.'))
        if amount <= 0:
            raise ValueError("Сумма должна быть положительной")

        new_balance = current_balance + amount
        success = set_user_balance(user_id, new_balance)

        # --- УДАЛЯЕМ СООБЩЕНИЯ ПОСЛЕ ОБРАБОТКИ ---
        delete_tasks = []
        delete_tasks.append(bot.delete_message(chat_id=message.chat.id, message_id=user_message_id))
        logging.debug(f"Запланировано удаление сообщения пользователя ({user_message_id}) с суммой.")
        if prompt_message_id:
            delete_tasks.append(bot.delete_message(chat_id=message.chat.id, message_id=prompt_message_id))
            logging.debug(f"Запланировано удаление сообщения с запросом суммы ({prompt_message_id}).")

        # Используем asyncio.gather для параллельного удаления
        results = await asyncio.gather(*delete_tasks, return_exceptions=True)
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                 msg_type = "пользователя" if i == 0 else "запроса суммы"
                 msg_id = user_message_id if i == 0 else prompt_message_id
                 logging.warning(f"Не удалось удалить сообщение {msg_type} ({msg_id}): {result}")
        # -------------------------------------------

        if success:
            currency = get_user_currency(user_id)
            await bot.send_message(message.chat.id, f"✅ Баланс успешно пополнен на {hbold(f'{amount:.2f}')} {currency}.", parse_mode="HTML")
            logging.info(f"Пользователь {user_id} пополнил баланс на {amount:.2f}. Новый баланс: {new_balance:.2f}")
            await show_profile_message(message, bot) # Передаем message для chat_id

        else:
             await bot.send_message(message.chat.id, "❌ Произошла ошибка при сохранении нового баланса. Попробуйте позже.")
             await show_profile_message(message, bot)

    except ValueError:
        # Сообщение с неверной суммой не удаляем
        await message.answer(
            "❌ Неверная сумма.\n"
            "Пожалуйста, введите положительное число (например, 100 или 50.5)."
        )
        # Состояние не сброшено, можно ввести снова

    except Exception as e:
        logging.error(f"Ошибка в process_top_up_amount для {user_id}: {e}", exc_info=True)
        # Удаляем сообщение пользователя при любой другой ошибке
        try: await bot.delete_message(chat_id=message.chat.id, message_id=user_message_id)
        except Exception: pass
        await bot.send_message(message.chat.id, "❌ Произошла ошибка при пополнении. Попробуйте позже.")
        await show_profile_message(message, bot)


@router.callback_query(BalanceTopUp.waiting_for_payment_method, F.data.in_(["ukrainian_cards", "kazakh_cards", "crypto_pay"]))
async def payment_method_unavailable_handler(query: CallbackQuery):
    await query.answer("❌ Этот способ пополнения временно недоступен.", show_alert=True)


@router.callback_query(F.data == "cancel_top_up")
async def cancel_top_up_handler(query: CallbackQuery, state: FSMContext, bot: Bot):
    current_state = await state.get_state()
    if current_state is not None:
        logging.info(f"Отмена состояния {current_state} для пользователя {query.from_user.id}")
        await state.clear()

    await query.answer("🚫 Действие отменено.")
    await show_profile_message(query, bot)
# --- END OF FILE handlers/profile.py ---