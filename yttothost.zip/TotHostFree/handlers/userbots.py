# --- START OF FILE handlers/userbots.py ---

import logging
import asyncio
from random import randint
from aiogram import Router, F, Bot, types
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, CallbackQuery, FSInputFile
from aiogram.utils.markdown import hbold, hcode, hlink

from keyboards.inline import (
    setup_userbots_menu_keyboard, setup_list_userbots_keyboard,
    setup_control_userbot_keyboard, setup_buy_userbot_keyboard,
    setup_tariff_period_keyboard, setup_reinstall_confirmation_keyboard
)
from states.user_states import BuyUserbot
from utils.database import (
    get_user_containers, get_container_by_id,
    add_container_to_db, remove_container_from_db,
    update_container_status, get_user_balance, set_user_balance,
    get_user_currency, create_user_if_not_exists
)
from utils.docker_utils import (
    create_docker_container, control_docker_container
)
from config import (
    IMG_USERBOTS_MENU, IMG_USERBOTS_LIST, IMG_USERBOTS_PANEL,
    IMG_USERBOTS_BUY, SERVER_IP, TARIFFS
)

router = Router()

# --- Главное меню управления (без изменений) ---
async def show_userbots_menu(target, bot: Bot):
    user_id = target.from_user.id
    chat_id = target.message.chat.id if isinstance(target, CallbackQuery) else target.chat.id
    markup = setup_userbots_menu_keyboard()
    menu_text = f"🤖 {hbold('Меню управление юзерботами')}\n\n😉 Выберите нужное вам действие."
    photo_sent = False
    try:
        photo = FSInputFile(IMG_USERBOTS_MENU)
        if isinstance(target, CallbackQuery):
             try:
                 await target.message.edit_media(media=types.InputMediaPhoto(media=photo, caption=menu_text, parse_mode="HTML"), reply_markup=markup.as_markup())
                 photo_sent = True
             except Exception:
                 await bot.send_photo(chat_id, photo=photo, caption=menu_text, reply_markup=markup.as_markup(), parse_mode="HTML")
                 photo_sent = True
                 try: await target.message.delete()
                 except Exception: pass
        else:
             await bot.send_photo(chat_id, photo=photo, caption=menu_text, reply_markup=markup.as_markup(), parse_mode="HTML")
             photo_sent = True
    except FileNotFoundError: logging.error(f"Фото {IMG_USERBOTS_MENU} не найдено.")
    except Exception as e: logging.error(f"Ошибка фото в show_userbots_menu: {e}", exc_info=True)
    if not photo_sent:
         try:
             if isinstance(target, CallbackQuery):
                  try: await target.message.edit_caption(caption=menu_text, reply_markup=markup.as_markup(), parse_mode="HTML")
                  except Exception: await target.message.edit_text(menu_text, reply_markup=markup.as_markup(), parse_mode="HTML")
             else: await bot.send_message(chat_id, menu_text, reply_markup=markup.as_markup(), parse_mode="HTML")
         except Exception as e: logging.error(f"Критическая ошибка текста в show_userbots_menu: {e}", exc_info=True)

@router.callback_query(F.data == "userbots_menu")
async def userbots_menu_handler(query: CallbackQuery, bot: Bot):
    await query.answer()
    await show_userbots_menu(query, bot)

# --- Список юзерботов (без изменений) ---
async def show_list_userbots(target, bot: Bot):
    user_id = target.from_user.id
    chat_id = target.message.chat.id if isinstance(target, CallbackQuery) else target.chat.id
    containers = get_user_containers(user_id)
    markup = setup_list_userbots_keyboard(containers)
    list_text = f"🤖 {hbold('Меню управление юзерботами')}\n\n"
    if containers: list_text += "🪪 Выберите юзербота из списка для управления."
    else: list_text += "🤷 У вас пока нет активных юзерботов."
    photo_sent = False
    try:
        photo = FSInputFile(IMG_USERBOTS_LIST)
        if isinstance(target, CallbackQuery):
             try:
                 await target.message.edit_media(media=types.InputMediaPhoto(media=photo, caption=list_text, parse_mode="HTML"), reply_markup=markup.as_markup())
                 photo_sent = True
             except Exception:
                 await bot.send_photo(chat_id, photo=photo, caption=list_text, reply_markup=markup.as_markup(), parse_mode="HTML")
                 photo_sent = True
                 try: await target.message.delete()
                 except Exception: pass
        else:
             await bot.send_photo(chat_id, photo=photo, caption=list_text, reply_markup=markup.as_markup(), parse_mode="HTML")
             photo_sent = True
    except FileNotFoundError: logging.error(f"Фото {IMG_USERBOTS_LIST} не найдено.")
    except Exception as e: logging.error(f"Ошибка фото в show_list_userbots: {e}", exc_info=True)
    if not photo_sent:
        try:
            if isinstance(target, CallbackQuery):
                 try: await target.message.edit_caption(caption=list_text, reply_markup=markup.as_markup(), parse_mode="HTML")
                 except Exception: await target.message.edit_text(list_text, reply_markup=markup.as_markup(), parse_mode="HTML")
            else: await bot.send_message(chat_id, list_text, reply_markup=markup.as_markup(), parse_mode="HTML")
        except Exception as e: logging.error(f"Критическая ошибка текста в show_list_userbots: {e}", exc_info=True)

@router.callback_query(F.data == "list_userbots")
async def list_userbots_handler(query: CallbackQuery, bot: Bot):
    await query.answer()
    await show_list_userbots(query, bot)

# --- Панель управления ---
# !!! ИЗМЕНЕНО: Отображает имя тарифа из TARIFFS по ключу из БД !!!
async def send_control_panel_message(chat_id: int, container: dict, bot: Bot):
    if not container:
        logging.error(f"Попытка отправить панель для несуществующего контейнера в чат {chat_id}")
        await bot.send_message(chat_id, "❌ Ошибка: Не удалось найти данные контейнера.")
        return
    container_db_id = container.get('container_db_id')
    if not container_db_id:
         logging.error(f"Ошибка: отсутствует container_db_id в данных контейнера: {container}")
         await bot.send_message(chat_id, "❌ Ошибка: Некорректные данные контейнера.")
         return

    container_port = container.get('port')
    container_status = container.get('status', '❓')
    docker_status_map = {'🟢': "Включён", '🔴': "Выключен", '🔄': "Перезапускается", '❓': "Неизвестно"}
    install_link = f"http://{SERVER_IP}:{container_port}" if container_port else "N/A"
    markup = setup_control_userbot_keyboard(container_status, install_link, container_db_id)
    status_text = docker_status_map.get(container_status, "Ошибка статуса")

    # --- Получаем имя тарифа из конфига по ключу ---
    tariff_key = container.get('tariff') # В БД теперь хранится ключ (lite, standart)
    tariff_name = TARIFFS.get(tariff_key, {}).get('name', tariff_key or 'N/A') # Имя для отображения
    # ----------------------------------------------

    control_panel_text = (
        f"🌟 {hbold('Панель управления юзерботом')} 🌟\n\n"
        f"🤖 Юзербот: {hbold(container.get('name', 'N/A'))}\n"
        f"🆔 DB ID: {hcode(container_db_id)}\n"
        f"📊 Тариф: {tariff_name}\n" # Отображаем имя тарифа
        f"{container_status} Статус: {hbold(status_text)}\n"
        f"🇷🇺 Сервер: {container.get('server', 'MSK')}\n\n"
        f"🔗 Ссылка установки: {hcode(install_link)}\n"
        f"⏰ Подписка истекает: {container.get('subscription_expires', 'Beta')}"
    )
    try:
        photo = FSInputFile(IMG_USERBOTS_PANEL)
        await bot.send_photo(chat_id, photo=photo, caption=control_panel_text, reply_markup=markup.as_markup(), parse_mode="HTML")
    except FileNotFoundError:
        logging.error(f"Фото {IMG_USERBOTS_PANEL} не найдено.")
        await bot.send_message(chat_id, control_panel_text, reply_markup=markup.as_markup(), parse_mode="HTML")
    except Exception as e:
        logging.error(f"Ошибка при отправке панели управления для container_db_id {container_db_id}: {e}", exc_info=True)
        await bot.send_message(chat_id, control_panel_text, reply_markup=markup.as_markup(), parse_mode="HTML")

# control_userbot_handler (без изменений, уже использует get_container_by_id)
@router.callback_query(F.data.startswith("control_userbot_"))
async def control_userbot_handler(query: CallbackQuery, bot: Bot):
    try:
        container_db_id = int(query.data.split('_')[-1])
    except (IndexError, ValueError):
        logging.error(f"Неверный callback_data в control_userbot_handler: {query.data}")
        await query.answer("❌ Ошибка: Неверный ID контейнера.", show_alert=True)
        await show_userbots_menu(query, bot)
        return
    user_id = query.from_user.id
    container = get_container_by_id(container_db_id)
    if not container or container.get('user_id') != user_id:
        logging.warning(f"Контейнер DB ID {container_db_id} не найден или не принадлежит пользователю {user_id}.")
        await query.answer("❌ Контейнер не найден или вам не принадлежит.", show_alert=True)
        await show_list_userbots(query, bot)
        try: await query.message.delete()
        except Exception: pass
        return
    await query.answer()
    await send_control_panel_message(query.message.chat.id, container, bot)
    try:
        await query.message.delete()
    except Exception as e:
        logging.warning(f"Не удалось удалить сообщение в control_userbot_handler для {user_id}: {e}")


# --- Действия с контейнером (без изменений, уже используют container_db_id) ---
@router.callback_query(F.data.startswith(("enable_userbot_", "disable_userbot_", "restart_userbot_")))
async def container_action_handler(query: CallbackQuery, bot: Bot):
    # ... (Код container_action_handler остается прежним, т.к. он уже оперирует container_db_id
    #      и использует get_container_by_id, update_container_status, remove_container_from_db)
    action_map = {"enable": "start", "disable": "stop", "restart": "restart"}
    verb_map = {"enable": "Включение", "disable": "Выключение", "restart": "Перезапуск"}
    result_status_map = {"enable": "🟢", "disable": "🔴", "restart": "🟢"}
    temp_status_map = {"restart": "🔄"}
    try:
        parts = query.data.split('_')
        action_prefix = parts[0]
        container_db_id = int(parts[-1])
        docker_action = action_map[action_prefix]
        action_verb = verb_map[action_prefix]
    except (IndexError, ValueError, KeyError):
        logging.error(f"Ошибка разбора callback_data в container_action_handler: {query.data}")
        await query.answer("❌ Ошибка: Неверная команда.", show_alert=True)
        return
    user_id = query.from_user.id
    container = get_container_by_id(container_db_id)
    if not container or container.get('user_id') != user_id:
        await query.answer("❌ Контейнер не найден или вам не принадлежит.", show_alert=True)
        try: await query.message.edit_caption(caption="Действие отменено. Контейнер недоступен.", reply_markup=None)
        except Exception: pass
        return

    docker_name = container.get('docker_name')
    if not docker_name:
        logging.warning(f"Нет имени Docker для container_db_id {container_db_id} при действии '{action_prefix}'.")
        await query.answer("❌ Ошибка: Docker контейнер не связан с этой записью.", show_alert=True)
        update_container_status(container_db_id, "🔴")
        updated_container = get_container_by_id(container_db_id)
        if updated_container:
             await send_control_panel_message(query.message.chat.id, updated_container, bot)
             try: await query.message.delete()
             except Exception: pass
        return

    await query.answer(f"⏳ {action_verb} юзербота...")
    temp_status = temp_status_map.get(action_prefix)
    if temp_status:
        update_container_status(container_db_id, temp_status)
        updated_container = get_container_by_id(container_db_id)
        if updated_container:
             try:
                  tariff_key = updated_container.get('tariff')
                  tariff_name = TARIFFS.get(tariff_key, {}).get('name', tariff_key or 'N/A')
                  new_status_text = docker_status_map.get(updated_container.get('status', '❓'), "Ошибка статуса")
                  new_install_link = f"http://{SERVER_IP}:{updated_container.get('port')}" if updated_container.get('port') else "N/A"
                  new_markup = setup_control_userbot_keyboard(updated_container.get('status', '❓'), new_install_link, container_db_id)
                  new_caption = (f"🌟 {hbold('Панель управления юзерботом')} 🌟\n\n" + \
                                 f"🤖 Юзербот: {hbold(updated_container.get('name', 'N/A'))}\n" + \
                                 f"🆔 DB ID: {hcode(container_db_id)}\n" + \
                                 f"📊 Тариф: {tariff_name}\n" + \
                                 f"{updated_container.get('status', '❓')} Статус: {hbold(new_status_text)}\n" + \
                                 f"🇷🇺 Сервер: {updated_container.get('server', 'MSK')}\n\n" + \
                                 f"🔗 Ссылка установки: {hcode(new_install_link)}\n" + \
                                 f"⏰ Подписка истекает: {updated_container.get('subscription_expires', 'Beta')}")
                  await query.message.edit_caption(caption=new_caption, reply_markup=new_markup.as_markup(), parse_mode="HTML")
             except Exception as e: logging.error(f"Не удалось отредактировать панель для временного статуса {container_db_id}: {e}")

    success, message = await control_docker_container(docker_name, docker_action)
    final_status = "❓"
    if success:
        final_status = result_status_map[action_prefix]
        if action_prefix == "disable" and message == "Уже выключен": final_status = "🔴"
        elif action_prefix == "enable" and message == "Уже запущен": final_status = "🟢"
        logging.info(f"Действие '{docker_action}' для {docker_name} успешно: {message}")
    else:
        if message == "Не найден":
             final_status = "🔴"
             logging.warning(f"Docker контейнер {docker_name} не найден. Удаляю запись из БД.")
             remove_container_from_db(container_db_id)
             await query.answer(f"❌ {action_verb} не выполнен: Контейнер не найден на сервере и удален.", show_alert=True)
             await show_list_userbots(query, bot)
             try: await query.message.delete()
             except Exception: pass
             return
        else:
            final_status = "🔴"
            await query.answer(f"❌ {action_verb} не выполнен: {message}", show_alert=True)

    update_container_status(container_db_id, final_status)
    final_container_data = get_container_by_id(container_db_id)
    if final_container_data:
         try:
              tariff_key = final_container_data.get('tariff')
              tariff_name = TARIFFS.get(tariff_key, {}).get('name', tariff_key or 'N/A')
              new_status_text = docker_status_map.get(final_container_data.get('status', '❓'), "Ошибка статуса")
              new_install_link = f"http://{SERVER_IP}:{final_container_data.get('port')}" if final_container_data.get('port') else "N/A"
              new_markup = setup_control_userbot_keyboard(final_container_data.get('status', '❓'), new_install_link, container_db_id)
              new_caption = (f"🌟 {hbold('Панель управления юзерботом')} 🌟\n\n" + \
                             f"🤖 Юзербот: {hbold(final_container_data.get('name', 'N/A'))}\n" + \
                             f"🆔 DB ID: {hcode(container_db_id)}\n" + \
                             f"📊 Тариф: {tariff_name}\n" + \
                             f"{final_container_data.get('status', '❓')} Статус: {hbold(new_status_text)}\n" + \
                             f"🇷🇺 Сервер: {final_container_data.get('server', 'MSK')}\n\n" + \
                             f"🔗 Ссылка установки: {hcode(new_install_link)}\n" + \
                             f"⏰ Подписка истекает: {final_container_data.get('subscription_expires', 'Beta')}")
              await query.message.edit_caption(caption=new_caption, reply_markup=new_markup.as_markup(), parse_mode="HTML")
         except Exception as e:
              logging.warning(f"Не удалось отредактировать панель после действия {docker_action} для {container_db_id}, отправляю новую: {e}")
              await send_control_panel_message(query.message.chat.id, final_container_data, bot)
              try: await query.message.delete()
              except Exception: pass


# --- Переустановка ---
# confirm_reinstall_handler (без изменений, уже использует container_db_id)
@router.callback_query(F.data.startswith("confirm_reinstall_userbot_"))
async def confirm_reinstall_handler(query: CallbackQuery, bot: Bot):
    try:
        container_db_id = int(query.data.split('_')[-1])
    except (IndexError, ValueError):
        logging.error(f"Неверный callback_data в confirm_reinstall_handler: {query.data}")
        await query.answer("❌ Ошибка: Неверный ID.", show_alert=True)
        return
    user_id = query.from_user.id
    container = get_container_by_id(container_db_id)
    if not container or container.get('user_id') != user_id:
         await query.answer("❌ Контейнер не найден или вам не принадлежит.", show_alert=True)
         try: await query.message.delete()
         except Exception: pass
         await show_list_userbots(query, bot)
         return
    markup = setup_reinstall_confirmation_keyboard(container_db_id)
    confirmation_text = (f"⚠️ {hbold('Переустановка Юзербота')} ⚠️\n\n" + \
                         f"Вы уверены, что хотите переустановить юзербота DB ID: {hcode(container_db_id)}?\n\n" + \
                         f"🗑 {hbold('Все данные текущего юзербота будут УДАЛЕНЫ.')}\n\n" + \
                         f"Будет создан новый контейнер с теми же параметрами.")
    try:
        await query.message.edit_caption(caption=confirmation_text, reply_markup=markup.as_markup(), parse_mode="HTML")
        await query.answer()
    except Exception as e:
        logging.error(f"Ошибка при показе подтверждения переустановки для {container_db_id}: {e}")
        await query.answer("❌ Ошибка при запросе подтверждения.", show_alert=True)

# !!! ИЗМЕНЕНО: Передает tariff_key в create_docker_container !!!
@router.callback_query(F.data.startswith("reinstall_userbot_"))
async def reinstall_userbot_handler(query: CallbackQuery, bot: Bot):
    try:
        container_db_id = int(query.data.split('_')[-1])
    except (IndexError, ValueError):
        logging.error(f"Неверный callback_data в reinstall_userbot_handler: {query.data}")
        await query.answer("❌ Ошибка: Неверный ID.", show_alert=True)
        return

    user_id = query.from_user.id
    old_container = get_container_by_id(container_db_id)

    if not old_container or old_container.get('user_id') != user_id:
        await query.answer("❌ Контейнер не найден или вам не принадлежит.", show_alert=True)
        try: await query.message.delete()
        except Exception: pass
        await show_list_userbots(query, bot)
        return

    await query.message.edit_caption(caption="⏳ Начинаю переустановку...", reply_markup=None)

    # --- Получаем КЛЮЧ тарифа из старого контейнера ---
    original_tariff_key = old_container.get('tariff') # Здесь должен быть ключ 'lite' или 'standart'
    if not original_tariff_key or original_tariff_key not in TARIFFS:
         logging.error(f"Не найден или неверный ключ тарифа '{original_tariff_key}' в данных старого контейнера {container_db_id}. Переустановка невозможна.")
         await query.answer("❌ Ошибка: не удалось определить тариф старого контейнера.", show_alert=True)
         await send_control_panel_message(query.message.chat.id, old_container, bot) # Показать старую панель
         try: await query.message.delete()
         except Exception: pass
         return
    # ----------------------------------------------------

    original_name = old_container.get('name', f'Userbot_{container_db_id}')
    original_server = old_container.get('server', 'MSK')
    original_sub_expires = old_container.get('subscription_expires', 'Beta')

    # 1. Удаляем старый Docker контейнер
    old_docker_name = old_container.get('docker_name')
    if old_docker_name:
        await query.message.edit_caption(caption=f"⏳ Переустановка...\nУдаляю старый Docker ({old_docker_name})...", reply_markup=None)
        success, msg = await control_docker_container(old_docker_name, action="remove")
        if not success and msg != "Не найден":
            logging.error(f"Не удалось удалить {old_docker_name}: {msg}")
            await query.answer("❌ Ошибка при удалении старого контейнера.", show_alert=True)
            await send_control_panel_message(query.message.chat.id, old_container, bot)
            try: await query.message.delete()
            except Exception: pass
            return
        else: logging.info(f"Старый Docker {old_docker_name} удален/не найден.")

    # 2. Удаляем старую запись из БД
    await query.message.edit_caption(caption=f"⏳ Переустановка...\nУдаляю запись из БД (ID: {container_db_id})...", reply_markup=None)
    remove_container_from_db(container_db_id)

    # 3. Создаем новый контейнер
    await query.message.edit_caption(caption=f"⏳ Переустановка...\nСоздаю новый Docker контейнер (тариф: {original_tariff_key})...", reply_markup=None)
    new_docker_name_base = f"userbot_{user_id}_reinst_{randint(1000,9999)}"
    # --- Передаем ключ тарифа в create_docker_container ---
    docker_data = await create_docker_container(user_id, new_docker_name_base, original_tariff_key)
    # -------------------------------------------------

    if docker_data and docker_data.get('docker_id'):
        new_container_data_for_db = {
            "user_id": user_id,
            "name": original_name,
            "tariff": original_tariff_key, # Сохраняем КЛЮЧ тарифа
            "status": docker_data['status'],
            "server": original_server,
            "subscription_expires": original_sub_expires, # TODO: Обновить?
            "port": docker_data['port'],
            "docker_id": docker_data['docker_id'],
            "docker_name": docker_data['docker_name']
        }
        new_db_id = add_container_to_db(user_id, new_container_data_for_db)

        if new_db_id:
            logging.info(f"Контейнер DB ID {container_db_id} переустановлен. Новый DB ID: {new_db_id}")
            await query.answer("✅ Контейнер успешно переустановлен!")
            final_new_container = get_container_by_id(new_db_id)
            if final_new_container:
                await send_control_panel_message(query.message.chat.id, final_new_container, bot)
            else: await query.message.edit_caption(caption="✅ Переустановлено, но не удалось показать панель.", reply_markup=None)
        else:
            logging.error(f"Не удалось добавить запись о новом контейнере в БД при переустановке.")
            await query.answer("❌ Ошибка при записи нового контейнера в базу.", show_alert=True)
            await show_list_userbots(query, bot)
    else:
        logging.error(f"Не удалось создать новый Docker контейнер при переустановке.")
        await query.answer("❌ Ошибка при создании нового Docker контейнера.", show_alert=True)
        await show_list_userbots(query, bot)

    try: await query.message.delete()
    except Exception: pass

# cancel_reinstall_handler (без изменений, уже использует container_db_id)
@router.callback_query(F.data.startswith("cancel_reinstall_userbot_"))
async def cancel_reinstall_handler(query: CallbackQuery, bot: Bot):
    try:
        container_db_id = int(query.data.split('_')[-1])
    except (IndexError, ValueError):
        logging.error(f"Неверный callback_data в cancel_reinstall_handler: {query.data}")
        await query.answer("❌ Ошибка: Неверный ID.", show_alert=True)
        return
    user_id = query.from_user.id
    container = get_container_by_id(container_db_id)
    await query.answer("🚫 Переустановка отменена.")
    try: await query.message.delete()
    except Exception: pass
    if container and container.get('user_id') == user_id:
        await send_control_panel_message(query.message.chat.id, container, bot)
    else:
        logging.warning(f"Контейнер {container_db_id} не найден при отмене переустановки для {user_id}.")
        await show_list_userbots(query, bot)

# --- Покупка юзербота ---
# buy_userbot_handler (без изменений)
@router.callback_query(F.data == "buy_userbot")
async def buy_userbot_handler(query: CallbackQuery, bot: Bot):
    markup = setup_buy_userbot_keyboard()
    buy_text = f"💬 {hbold('Покупка юзербота')}\n\n📊 Выберите тариф подписки."
    try:
        photo = FSInputFile(IMG_USERBOTS_BUY)
        await query.message.edit_media(media=types.InputMediaPhoto(media=photo, caption=buy_text, parse_mode="HTML"), reply_markup=markup.as_markup())
    except FileNotFoundError:
        logging.error(f"Фото {IMG_USERBOTS_BUY} не найдено.")
        try: await query.message.edit_caption(caption=buy_text, reply_markup=markup.as_markup(), parse_mode="HTML")
        except Exception: await query.message.edit_text(buy_text, reply_markup=markup.as_markup(), parse_mode="HTML")
    except Exception as e:
        logging.error(f"Ошибка в buy_userbot_handler: {e}", exc_info=True)
        try: await query.message.edit_caption(caption=buy_text, reply_markup=markup.as_markup(), parse_mode="HTML")
        except Exception: await query.message.edit_text(buy_text, reply_markup=markup.as_markup(), parse_mode="HTML")
    await query.answer()

# select_tariff_handler (без изменений)
@router.callback_query(F.data.startswith("select_tariff_"))
async def select_tariff_handler(query: CallbackQuery, state: FSMContext, bot: Bot):
    try:
        tariff_key = query.data.split('_')[-1]
    except IndexError:
        logging.error(f"Неверный callback_data в select_tariff_handler: {query.data}")
        await query.answer("❌ Ошибка выбора тарифа.", show_alert=True)
        return
    if tariff_key not in TARIFFS or tariff_key == "Beta":
        logging.error(f"Выбран неверный тариф: {tariff_key}")
        await query.answer("❌ Выбран неверный тариф.", show_alert=True)
        return
    user_id = query.from_user.id
    currency = get_user_currency(user_id)
    markup = setup_tariff_period_keyboard(tariff_key, currency)
    tariff_name = TARIFFS[tariff_key]['name']
    period_text = (f"💬 {hbold('Покупка юзербота')}\n\n" + \
                  f"📊 Выбран тариф: {hbold(tariff_name)}\n" + \
                  f"🗓 Выберите срок оплаты подписки:")
    try: await query.message.edit_caption(caption=period_text, reply_markup=markup.as_markup(), parse_mode="HTML")
    except Exception: await query.message.edit_text(period_text, reply_markup=markup.as_markup(), parse_mode="HTML")
    await query.answer()
    await state.set_state(BuyUserbot.waiting_for_period_choice)
    await state.update_data(chosen_tariff=tariff_key)

# !!! ИЗМЕНЕНО: Передает tariff_key в create_docker_container и сохраняет его в БД !!!
@router.callback_query(BuyUserbot.waiting_for_period_choice, F.data.startswith("period_"))
async def period_choice_handler(query: CallbackQuery, state: FSMContext, bot: Bot):
    try:
        parts = query.data.split('_')
        if len(parts) != 3: raise ValueError("Invalid callback format")
        _, tariff_key, period_months_str = parts
        period_months = int(period_months_str)
        user_id = query.from_user.id

        if tariff_key not in TARIFFS or period_months not in TARIFFS[tariff_key]["monthly_prices"]:
            logging.error(f"Неверный тариф/период: {tariff_key}/{period_months}")
            await query.answer("❌ Ошибка: Неверный тариф или срок.", show_alert=True)
            await state.clear()
            await show_userbots_menu(query, bot)
            return

        price_info = TARIFFS[tariff_key]["monthly_prices"][period_months]
        price = price_info["price"]
        period_name = price_info["name"]
        tariff_info = TARIFFS[tariff_key]
        tariff_display_name = tariff_info["name"] # Имя для сообщений

        user_balance = get_user_balance(user_id)
        user_currency = get_user_currency(user_id)

        logging.info(f"Попытка покупки: User={user_id}, TariffKey={tariff_key}, Period={period_name}, Price={price}, Balance={user_balance}")

        if user_balance >= price:
            await query.message.edit_caption(caption=f"⏳ Покупаю {tariff_display_name} на {period_name}...\nСписываю средства...", reply_markup=None)
            new_balance = user_balance - price
            balance_updated = set_user_balance(user_id, new_balance)
            if not balance_updated:
                 logging.error(f"Не удалось списать баланс для {user_id}.")
                 await query.answer("❌ Ошибка при списании средств.", show_alert=True)
                 await state.clear()
                 await show_userbots_menu(query, bot)
                 return

            logging.info(f"Списан баланс {price} у {user_id}. Новый баланс: {new_balance:.2f}")
            await query.message.edit_caption(caption=f"⏳ Покупка...\nСоздаю Docker контейнер (тариф: {tariff_key})...", reply_markup=None)

            container_name_display = f"{tariff_display_name}_{randint(100,999)}"
            docker_name_base = f"userbot_{user_id}_{tariff_key}_{randint(1000,9999)}"

            # --- Передаем tariff_key в create_docker_container ---
            docker_data = await create_docker_container(user_id, docker_name_base, tariff_key)
            # --------------------------------------------------

            if docker_data and docker_data.get('docker_id'):
                # TODO: Вычислить дату окончания подписки
                expires_date = "TODO: Calculate date"

                new_container_data_for_db = {
                    "user_id": user_id,
                    "name": container_name_display,
                    "tariff": tariff_key, # Сохраняем КЛЮЧ тарифа
                    "status": docker_data['status'],
                    "server": "MSK",
                    "subscription_expires": expires_date,
                    "port": docker_data['port'],
                    "docker_id": docker_data['docker_id'],
                    "docker_name": docker_data['docker_name']
                }
                new_db_id = add_container_to_db(user_id, new_container_data_for_db)

                if new_db_id:
                    logging.info(f"Успешно куплен контейнер DB ID {new_db_id} для {user_id}")
                    await query.answer(f"✅ Юзербот '{container_name_display}' (DB ID: {new_db_id}) куплен на {period_name}!", show_alert=True)
                    await state.clear()
                    try: await query.message.delete()
                    except Exception: pass
                    await show_userbots_menu(query, bot)
                else: # Ошибка добавления в БД
                    logging.error(f"Не удалось добавить контейнер в БД для {user_id}!")
                    set_user_balance(user_id, user_balance) # Возврат денег
                    logging.warning(f"Возвращен баланс {price} пользователю {user_id}.")
                    if docker_data.get('docker_name'):
                         await control_docker_container(docker_data['docker_name'], action="remove")
                    await query.answer("❌ Ошибка при сохранении юзербота. Средства возвращены.", show_alert=True)
                    await state.clear()
                    await show_userbots_menu(query, bot)
            else: # Docker не создался
                logging.error(f"Не удалось создать Docker контейнер для {user_id}!")
                set_user_balance(user_id, user_balance) # Возврат денег
                logging.warning(f"Возвращен баланс {price} пользователю {user_id}.")
                await query.answer("❌ Ошибка при создании Docker. Средства возвращены.", show_alert=True)
                await state.clear()
                await show_userbots_menu(query, bot)
        else: # Недостаточно средств
            needed = price - user_balance
            await query.answer(f"❌ Недостаточно средств!\nНужно: {price:.2f} {user_currency}\nПополните на {needed:.2f} {user_currency}.", show_alert=True)

    except (ValueError, IndexError, KeyError) as e:
        logging.error(f"Ошибка обработки периода: {e}. Callback: {query.data}", exc_info=True)
        await query.answer("❌ Ошибка обработки.", show_alert=True)
        await state.clear()
        await show_userbots_menu(query, bot)
    except Exception as e:
        logging.error(f"Непредвиденная ошибка в period_choice_handler: {e}", exc_info=True)
        await query.answer("❌ Серьезная ошибка.", show_alert=True)
        # Попытка возврата денег (нужен флаг или проверка баланса до/после)
        await state.clear()
        await show_userbots_menu(query, bot)

# --- Плейсхолдеры (без изменений) ---
@router.callback_query(F.data.in_(["no_bots_placeholder", "link_na_placeholder", "no_periods_placeholder"]))
async def simple_placeholder_handler(query: CallbackQuery):
    if query.data == "no_bots_placeholder": await query.answer("ℹ️ Нет юзерботов.", show_alert=False)
    elif query.data == "link_na_placeholder": await query.answer("ℹ️ Ссылка недоступна.", show_alert=False)
    elif query.data == "no_periods_placeholder": await query.answer("❌ Нет периодов.", show_alert=True)
    else: await query.answer("ℹ️ Недоступно.", show_alert=True)

@router.callback_query(F.data.startswith(("get_log_beta_", "more_beta_")))
async def beta_placeholder_handler(query: CallbackQuery):
     try: container_db_id = int(query.data.split('_')[-1])
     except Exception: pass
     if query.data.startswith("get_log_beta_"): await query.answer("❌ Логи не реализованы.", show_alert=True)
     elif query.data.startswith("more_beta_"): await query.answer("❌ Доп. опции не реализованы.", show_alert=True)
     else: await query.answer("ℹ️ Не реализовано.", show_alert=True)

# --- END OF FILE handlers/userbots.py ---