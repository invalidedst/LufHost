# --- START OF FILE handlers/errors.py ---

import logging
from aiogram import Router, F
from aiogram.types import CallbackQuery

router = Router()

# Этот хэндлер должен быть последним в цепочке include_routers
@router.callback_query()
async def unhandled_callback_handler(query: CallbackQuery):
    """ Ловит все колбэки, которые не были обработаны ранее """
    logging.warning(f"Необработанный callback_query: {query.data} от пользователя {query.from_user.id} ({query.from_user.username})")
    try:
        # Пытаемся ответить, если сообщение еще существует
        await query.answer("🤔 Это действие не распознано или кнопка устарела.", show_alert=True)
        # Можно также попытаться удалить кнопки или сообщение
        # await query.message.edit_reply_markup(reply_markup=None)
    except Exception as e:
        # Если сообщение удалено или другая ошибка
        logging.warning(f"Не удалось ответить на необработанный колбэк {query.data}: {e}")
# --- END OF FILE handlers/errors.py ---