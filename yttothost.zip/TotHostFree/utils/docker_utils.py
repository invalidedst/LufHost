# --- START OF FILE utils/docker_utils.py ---

import docker
import logging
import asyncio
from random import randint

# --- ДОБАВЛЯЕМ TARIFFS ИЗ CONFIG ---
from config import DOCKER_IMAGE, PORT_RANGE_START, PORT_RANGE_END, TARIFFS
# ------------------------------------
from utils.database import (
    get_all_used_ports,
    remove_container_from_db,
    get_all_db_docker_names,
    get_container_by_id,
)

# ... (get_docker_client, find_available_port без изменений) ...
try:
    docker_client = docker.from_env()
    docker_client.ping()
    logging.info("Docker клиент успешно инициализирован.")
except docker.errors.DockerException as e:
    logging.error(f"Не удалось подключиться к Docker Engine: {e}")
    docker_client = None

def get_docker_client():
    if docker_client is None:
        logging.error("Docker клиент не инициализирован.")
    return docker_client

def find_available_port():
    used_ports = get_all_used_ports()
    if not isinstance(used_ports, set):
         logging.error("Функция get_all_used_ports не вернула множество. Невозможно найти порт.")
         return None
    max_attempts = (PORT_RANGE_END - PORT_RANGE_START + 1) * 2
    for _ in range(max_attempts):
        port = randint(PORT_RANGE_START, PORT_RANGE_END)
        if port not in used_ports:
            logging.info(f"Найден свободный порт: {port}")
            return port
    logging.error("Не удалось найти свободный порт после множества попыток.")
    return None

# --- ИЗМЕНЕНО: Добавлен аргумент tariff_key ---
async def create_docker_container(user_id, docker_name_base, tariff_key: str):
    """
    Создает и запускает Docker контейнер с учетом лимитов тарифа.
    Возвращает словарь с docker_id, docker_name, port, status или None в случае ошибки.
    """
    client = get_docker_client()
    if not client:
        return None

    # --- Получаем лимиты из конфига ---
    tariff_info = TARIFFS.get(tariff_key)
    limits = tariff_info.get("limits", {}) if tariff_info else {}
    memory_limit = limits.get("memory") # Например, "300m", "750m" или None
    storage_limit_gb = limits.get("storage_gb") # Информационно
    # ---------------------------------

    container_port = find_available_port()
    if container_port is None:
        logging.error("Не удалось найти свободный порт для нового контейнера.")
        return None

    docker_container_name = f"{docker_name_base}_{randint(1000, 9999)}"
    image_name = DOCKER_IMAGE
    ports_mapping = {f'8080/tcp': container_port}
    environment_vars = {"USER_ID": str(user_id), "TARIFF": tariff_key} # Добавим тариф в ENV

    result_data = {
        "docker_id": None,
        "docker_name": docker_container_name,
        "port": container_port,
        "status": "🔴"
    }

    # --- Готовим параметры для Docker ---
    run_kwargs = {
        "image": image_name,
        "detach": True,
        "name": docker_container_name,
        "ports": ports_mapping,
        "environment": environment_vars,
        "restart_policy": {"Name": "unless-stopped"}
    }
    # --- Применяем лимит памяти, если он задан ---
    if memory_limit:
        run_kwargs["mem_limit"] = memory_limit
        logging.info(f"Применяется лимит памяти: {memory_limit} для контейнера {docker_container_name}")
    else:
        logging.info(f"Лимит памяти не применяется для тарифа '{tariff_key}'.")

    # Логируем предполагаемый лимит диска (но не применяем его напрямую)
    if storage_limit_gb:
         logging.info(f"Информационно: предполагаемый лимит диска {storage_limit_gb} GB для тарифа '{tariff_key}' (не применяется через docker run).")
    # --------------------------------------

    try:
        logging.info(f"Попытка запуска Docker контейнера: {run_kwargs}")
        # Используем **run_kwargs для передачи всех параметров
        docker_container = client.containers.run(**run_kwargs)
        await asyncio.sleep(2)
        docker_container.reload()

        logging.info(f"Docker контейнер создан: ID={docker_container.short_id}, Name={docker_container.name}, Status={docker_container.status}")

        if docker_container.status in ['created', 'running']:
            result_data['docker_id'] = docker_container.id
            result_data['status'] = "🟢"
            logging.info(f"Статус контейнера {docker_container_name} установлен '🟢'")
        else:
            # ... (логика обработки ошибки создания и удаления без изменений) ...
            logging.warning(f"Docker контейнер {docker_container_name} создан, но статус '{docker_container.status}'. Устанавливаю статус '🔴'.")
            result_data['docker_id'] = docker_container.id
            try:
                logging.warning(f"Попытка удаления контейнера {docker_container_name} из-за статуса '{docker_container.status}' при создании.")
                docker_container.remove(force=True)
                result_data['docker_id'] = None
                logging.info(f"Контейнер {docker_container_name} удален.")
                return None
            except docker.errors.APIError as rm_err:
                logging.error(f"Не удалось удалить контейнер {docker_container_name} после неудачного запуска: {rm_err}")

        return result_data

    except docker.errors.ImageNotFound:
        logging.error(f"Docker образ '{image_name}' не найден.")
        return None
    except docker.errors.APIError as e:
        # ... (обработка APIError без изменений) ...
        if "is already in use by container" in str(e):
             logging.warning(f"Контейнер с именем {docker_container_name} уже существует. Ошибка: {e}")
             return None
        logging.error(f"Ошибка Docker API при создании контейнера {docker_container_name}: {e}", exc_info=True)
        try:
            existing_cont = client.containers.get(docker_container_name)
            existing_cont.remove(force=True)
            logging.info(f"Удален частично созданный контейнер {docker_container_name} из-за ошибки API.")
        except docker.errors.NotFound: pass
        except docker.errors.APIError as clean_e: logging.error(f"Ошибка при очистке {docker_container_name}: {clean_e}")
        return None
    except Exception as e:
        logging.error(f"Непредвиденная ошибка при создании Docker контейнера {docker_container_name}: {e}", exc_info=True)
        return None

# ... (control_docker_container, verify_server_containers без изменений) ...
async def control_docker_container(docker_name, action="start"):
    client = get_docker_client()
    if not client or not docker_name:
        msg = "Ошибка клиента Docker или имя не указано."
        logging.error(f"Невозможно выполнить '{action}' для '{docker_name}': {msg}")
        return False, msg
    try:
        container = client.containers.get(docker_name)
        current_status = container.status
        logging.info(f"Выполнение '{action}' для контейнера {docker_name} (текущий статус: {current_status})")

        if action == "start":
            if current_status == "running": return True, "Уже запущен"
            container.start()
            await asyncio.sleep(1)
            container.reload()
            if container.status == "running": return True, "Запущен"
            else: return False, f"Не запустился ({container.status})"
        elif action == "stop":
            if current_status != "running": return True, "Уже выключен"
            container.stop(timeout=5)
            logging.info(f"Контейнер {docker_name} остановлен.")
            return True, "Остановлен"
        elif action == "restart":
            container.restart(timeout=10)
            logging.info(f"Команда restart отправлена {docker_name}.")
            await asyncio.sleep(5)
            container.reload()
            if container.status == "running": return True, "Перезапущен"
            else: return False, f"Не запустился после рестарта ({container.status})"
        elif action == "remove":
            logging.info(f"Удаление контейнера {docker_name}...")
            container.remove(force=True)
            logging.info(f"Контейнер {docker_name} удален.")
            return True, "Удален"
        else:
            msg = "Неизвестное действие"
            logging.error(f"{msg} '{action}' для Docker контейнера.")
            return False, msg
    except docker.errors.NotFound:
        logging.warning(f"Контейнер {docker_name} не найден при попытке выполнить '{action}'.")
        return False, "Не найден"
    except docker.errors.APIError as e:
        logging.error(f"Ошибка Docker API при выполнении '{action}' для {docker_name}: {e}")
        return False, f"Ошибка API: {e}"
    except Exception as e:
        logging.error(f"Непредвиденная ошибка при выполнении '{action}' для {docker_name}: {e}", exc_info=True)
        return False, f"Внутренняя ошибка: {e}"

async def verify_server_containers():
    client = get_docker_client()
    if not client:
        logging.warning("Проверка контейнеров невозможна: Docker клиент недоступен.")
        return
    logging.info("Начинаю проверку и синхронизацию контейнеров Docker с БД SQLite...")
    try:
        server_container_names = {cont.name for cont in client.containers.list(all=True)}
        db_container_names = get_all_db_docker_names()
        missing_on_server = db_container_names - server_container_names
        removed_count = 0
        if missing_on_server:
            logging.warning(f"Обнаружены контейнеры в БД SQLite, отсутствующие на сервере Docker: {missing_on_server}")
            conn = get_db_connection()
            if not conn:
                 logging.error("Не удалось подключиться к БД для удаления отсутствующих контейнеров.")
                 return
            try:
                 cursor = conn.cursor()
                 placeholders = ','.join('?' * len(missing_on_server))
                 sql_select = f"SELECT container_db_id, docker_name FROM containers WHERE docker_name IN ({placeholders})"
                 cursor.execute(sql_select, tuple(missing_on_server))
                 rows_to_delete = cursor.fetchall()
                 ids_to_remove = [row['container_db_id'] for row in rows_to_delete]
                 if ids_to_remove:
                     placeholders_ids = ','.join('?' * len(ids_to_remove))
                     sql_delete = f"DELETE FROM containers WHERE container_db_id IN ({placeholders_ids})"
                     cursor.execute(sql_delete, tuple(ids_to_remove))
                     conn.commit()
                     removed_count = cursor.rowcount
                     removed_names = [row['docker_name'] for row in rows_to_delete]
                     logging.info(f"Удалено из базы данных SQLite: {removed_count} контейнеров (ID: {ids_to_remove}, Имена: {removed_names}), отсутствующих на сервере.")
                 else:
                     logging.info("Не найдено ID для удаления в БД для отсутствующих имен Docker.")
            except sqlite3.Error as e:
                 logging.error(f"Ошибка SQLite при удалении отсутствующих контейнеров: {e}")
            finally:
                 if conn: conn.close()
        else:
            logging.info("Расхождений между БД SQLite и сервером Docker не найдено.")
        extra_on_server = server_container_names - db_container_names
        if extra_on_server:
           logging.warning(f"Обнаружены 'лишние' контейнеры на сервере Docker (нет в БД SQLite): {extra_on_server}")
        logging.info("Проверка контейнеров Docker завершена.")
    except docker.errors.DockerException as e:
        logging.error(f"Ошибка Docker при проверке контейнеров на сервере: {e}")
    except Exception as e:
        logging.error(f"Непредвиденная ошибка при проверке контейнеров: {e}", exc_info=True)
# --- END OF FILE utils/docker_utils.py ---