# --- START OF FILE utils/database.py ---
import sqlite3
import logging
from config import SQLITE_DB_FILE, BALANCE_DEFAULT, CURRENCY_DEFAULT, REG_DATE_DEFAULT

# --- Инициализация и подключение ---

def get_db_connection():
    """ Устанавливает соединение с SQLite базой данных. """
    conn = None
    try:
        conn = sqlite3.connect(SQLITE_DB_FILE)
        conn.row_factory = sqlite3.Row # Возвращать строки как словари
        conn.execute("PRAGMA foreign_keys = ON;") # Включить внешние ключи
        logging.debug("Соединение с SQLite установлено.")
        return conn
    except sqlite3.Error as e:
        logging.error(f"Ошибка подключения к SQLite: {e}", exc_info=True)
        return None # Возвращаем None при ошибке

def init_db():
    """ Инициализирует базу данных: создает таблицы, если их нет. """
    conn = get_db_connection()
    if conn is None:
        logging.error("Не удалось инициализировать БД: нет соединения.")
        return
    try:
        cursor = conn.cursor()
        # Пользователи
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            balance REAL DEFAULT 0.0,
            currency TEXT DEFAULT 'RUB',
            reg_date TEXT DEFAULT 'Неизвестно',
            agreed_policy INTEGER DEFAULT 0 -- 0 = False, 1 = True
        )
        """)
        # Контейнеры
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS containers (
            container_db_id INTEGER PRIMARY KEY AUTOINCREMENT,
            container_txt_id INTEGER,
            user_id INTEGER NOT NULL,
            name TEXT,
            tariff TEXT,
            status TEXT DEFAULT '?',
            server TEXT DEFAULT 'MSK',
            subscription_expires TEXT,
            port INTEGER,
            docker_id TEXT,
            docker_name TEXT UNIQUE,
            FOREIGN KEY (user_id) REFERENCES users (user_id) ON DELETE CASCADE
        )
        """)
        # Индексы (создадутся только если их нет)
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_docker_name ON containers (docker_name)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_container_user_id ON containers (user_id)")

        conn.commit()
        logging.info("Проверка/создание таблиц БД завершено.")
    except sqlite3.Error as e:
        logging.error(f"Ошибка при инициализации таблиц БД: {e}", exc_info=True)
    finally:
        if conn:
            conn.close()

# --- Функции доступа к данным пользователя ---

def create_user_if_not_exists(user_id, agreed=False):
    """ Создает запись пользователя, если ее нет. Возвращает True, если создан, False иначе. """
    try:
        user_id_int = int(user_id)
    except (ValueError, TypeError):
        logging.error(f"[DB Create User] Попытка создать пользователя с невалидным ID: {user_id}. Отменено.")
        return False

    sql = """
        INSERT OR IGNORE INTO users (user_id, balance, currency, reg_date, agreed_policy)
        VALUES (?, ?, ?, ?, ?)
    """
    conn = get_db_connection()
    if not conn: return False
    try:
        cursor = conn.cursor()
        # Используем значения по умолчанию, но `agreed_policy` может быть 1 при первом создании
        policy_status = 1 if agreed else 0
        cursor.execute(sql, (user_id_int, BALANCE_DEFAULT, CURRENCY_DEFAULT, REG_DATE_DEFAULT, policy_status))
        conn.commit()
        # cursor.rowcount == 1 означает, что новая строка была вставлена
        if cursor.rowcount > 0:
             logging.info(f"[DB Create User] Создана новая запись для пользователя {user_id_int} (согласие: {policy_status}).")
             return True
        else:
             # Пользователь уже существовал, но может потребоваться обновить статус согласия
             if agreed:
                 # Попробуем обновить статус согласия, если он был 0
                 update_sql = "UPDATE users SET agreed_policy = 1 WHERE user_id = ? AND agreed_policy = 0"
                 cursor.execute(update_sql, (user_id_int,))
                 if cursor.rowcount > 0:
                     conn.commit()
                     logging.info(f"[DB Create User] Обновлен статус согласия для существующего пользователя {user_id_int}.")
                 # else: статус уже был 1 или пользователя нет (хотя INSERT IGNORE должен был его создать)
             logging.debug(f"[DB Create User] Пользователь {user_id_int} уже существует.")
             return False
    except sqlite3.Error as e:
        logging.error(f"[DB Create User] Ошибка при создании/проверке пользователя {user_id_int}: {e}", exc_info=True)
        return False
    finally:
        if conn:
            conn.close()

def check_user_agreement(user_id):
    """ Проверяет, принял ли пользователь соглашение """
    try:
        user_id_int = int(user_id)
    except (ValueError, TypeError):
        return False

    sql = "SELECT agreed_policy FROM users WHERE user_id = ?"
    conn = get_db_connection()
    if not conn: return False
    try:
        cursor = conn.cursor()
        cursor.execute(sql, (user_id_int,))
        result = cursor.fetchone()
        # Если пользователя нет (result is None) или agreed_policy == 0, возвращаем False
        return result is not None and result['agreed_policy'] == 1
    except sqlite3.Error as e:
        logging.error(f"[DB Check Agreement] Ошибка при проверке согласия для {user_id_int}: {e}", exc_info=True)
        return False
    finally:
        if conn:
            conn.close()

def record_user_agreement(user_id):
    """ Записывает согласие пользователя (создает пользователя, если нужно) """
    # Сначала убедимся, что пользователь существует, и сразу установим флаг agreed=True
    created = create_user_if_not_exists(user_id, agreed=True)
    # Если пользователь не был создан (т.е. он уже существовал),
    # create_user_if_not_exists уже позаботился об обновлении флага agreed_policy (если он был 0).
    # Так что здесь больше ничего делать не нужно.
    # Просто вернем True если операция прошла успешно (пользователь создан или обновлен)
    # Функция create_user_if_not_exists сама логирует детали.
    # Но для единообразия можно добавить лог.
    logging.info(f"[DB Record Agreement] Попытка записи согласия для {user_id} завершена.")
    # Возвращать статус успеха тут сложно, т.к. create_user_if_not_exists возвращает True только при создании
    # Просто выполним действие.

def get_user_data(user_id):
     """ Получает все данные пользователя или None """
     try:
         user_id_int = int(user_id)
     except (ValueError, TypeError):
         return None
     sql = "SELECT * FROM users WHERE user_id = ?"
     conn = get_db_connection()
     if not conn: return None
     try:
         cursor = conn.cursor()
         cursor.execute(sql, (user_id_int,))
         return cursor.fetchone() # Вернет Row object (как dict) или None
     except sqlite3.Error as e:
         logging.error(f"[DB Get User Data] Ошибка при получении данных для {user_id_int}: {e}", exc_info=True)
         return None
     finally:
         if conn:
             conn.close()

def get_user_balance(user_id):
    """ Получает баланс пользователя """
    user_data = get_user_data(user_id)
    return user_data['balance'] if user_data else BALANCE_DEFAULT

def get_user_currency(user_id):
    """ Получает валюту пользователя """
    user_data = get_user_data(user_id)
    return user_data['currency'] if user_data else CURRENCY_DEFAULT

def get_user_reg_date(user_id):
     """ Получает дату регистрации пользователя """
     user_data = get_user_data(user_id)
     return user_data['reg_date'] if user_data else REG_DATE_DEFAULT

def set_user_balance(user_id, balance):
    """ Устанавливает баланс пользователя """
    # Убедимся, что пользователь существует
    create_user_if_not_exists(user_id)
    try:
        user_id_int = int(user_id)
        balance_float = float(balance)
    except (ValueError, TypeError) as e:
        logging.error(f"[DB Set Balance] Неверные данные для установки баланса (user_id: {user_id}, balance: {balance}): {e}")
        return False

    sql = "UPDATE users SET balance = ? WHERE user_id = ?"
    conn = get_db_connection()
    if not conn: return False
    try:
        cursor = conn.cursor()
        cursor.execute(sql, (balance_float, user_id_int))
        conn.commit()
        if cursor.rowcount > 0:
             logging.debug(f"[DB Set Balance] Установлен баланс {balance_float} для пользователя {user_id_int}")
             return True
        else:
             # Это может произойти, если create_user_if_not_exists не сработал
             logging.error(f"[DB Set Balance] Не удалось обновить баланс для пользователя {user_id_int} (возможно, не найден).")
             return False
    except sqlite3.Error as e:
        logging.error(f"[DB Set Balance] Ошибка при установке баланса для {user_id_int}: {e}", exc_info=True)
        return False
    finally:
        if conn:
            conn.close()

def set_user_currency(user_id, currency):
    """ Устанавливает валюту пользователя """
    create_user_if_not_exists(user_id)
    try:
        user_id_int = int(user_id)
        currency_str = str(currency).upper()
    except (ValueError, TypeError) as e:
        logging.error(f"[DB Set Currency] Неверные данные для установки валюты (user_id: {user_id}, currency: {currency}): {e}")
        return False

    sql = "UPDATE users SET currency = ? WHERE user_id = ?"
    conn = get_db_connection()
    if not conn: return False
    try:
        cursor = conn.cursor()
        cursor.execute(sql, (currency_str, user_id_int))
        conn.commit()
        if cursor.rowcount > 0:
            logging.debug(f"[DB Set Currency] Установлена валюта {currency_str} для пользователя {user_id_int}")
            return True
        else:
            logging.error(f"[DB Set Currency] Не удалось обновить валюту для пользователя {user_id_int} (возможно, не найден).")
            return False
    except sqlite3.Error as e:
        logging.error(f"[DB Set Currency] Ошибка при установке валюты для {user_id_int}: {e}", exc_info=True)
        return False
    finally:
        if conn:
            conn.close()

# --- Функции доступа к данным контейнеров ---

def get_user_containers(user_id):
    """ Получает список контейнеров пользователя (список словарей) """
    try:
        user_id_int = int(user_id)
    except (ValueError, TypeError):
        return [] # Возвращаем пустой список для невалидного ID

    # Выбираем все поля, чтобы вернуть словари, совместимые со старым кодом
    sql = "SELECT * FROM containers WHERE user_id = ?"
    conn = get_db_connection()
    if not conn: return []
    containers = []
    try:
        cursor = conn.cursor()
        cursor.execute(sql, (user_id_int,))
        # Преобразуем Row объекты в обычные словари
        containers = [dict(row) for row in cursor.fetchall()]
        logging.debug(f"[DB Get Containers] Найдено {len(containers)} контейнеров для пользователя {user_id_int}")
    except sqlite3.Error as e:
        logging.error(f"[DB Get Containers] Ошибка при получении контейнеров для {user_id_int}: {e}", exc_info=True)
    finally:
        if conn:
            conn.close()
    return containers

def get_container_by_id(container_db_id):
    """ Получает контейнер по его ID в базе данных (container_db_id) """
    try:
        target_id = int(container_db_id)
    except (ValueError, TypeError):
        logging.warning(f"[DB Get Container] Неверный тип ID контейнера при поиске: {container_db_id}")
        return None

    sql = "SELECT * FROM containers WHERE container_db_id = ?"
    conn = get_db_connection()
    if not conn: return None
    try:
        cursor = conn.cursor()
        cursor.execute(sql, (target_id,))
        row = cursor.fetchone()
        return dict(row) if row else None # Возвращаем словарь или None
    except sqlite3.Error as e:
        logging.error(f"[DB Get Container] Ошибка при поиске контейнера по ID {target_id}: {e}", exc_info=True)
        return None
    finally:
        if conn:
            conn.close()

def add_container_to_db(user_id, container_data: dict):
    """ Добавляет данные контейнера в базу данных пользователя.
        container_data - словарь с данными нового контейнера.
        Возвращает ID нового контейнера в БД (container_db_id) или None в случае ошибки.
    """
    # Убедимся, что пользователь существует
    create_user_if_not_exists(user_id)
    try:
        user_id_int = int(user_id)
    except (ValueError, TypeError):
        logging.error(f"[DB Add Container] Неверный user_id {user_id} при добавлении контейнера.")
        return None

    # Подготавливаем данные для вставки
    # container_txt_id теперь опционален или равен 'id' из словаря, если он там есть
    container_txt_id = container_data.get('id') or container_data.get('container_txt_id')
    name = container_data.get('name')
    tariff = container_data.get('tariff')
    status = container_data.get('status', '?')
    server = container_data.get('server', 'MSK')
    subscription_expires = container_data.get('subscription_expires')
    port = container_data.get('port')
    docker_id = container_data.get('docker_id')
    docker_name = container_data.get('docker_name')

    sql = """
        INSERT INTO containers (
            container_txt_id, user_id, name, tariff, status, server,
            subscription_expires, port, docker_id, docker_name
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """
    conn = get_db_connection()
    if not conn: return None
    try:
        cursor = conn.cursor()
        cursor.execute(sql, (
            container_txt_id, user_id_int, name, tariff, status, server,
            subscription_expires, port, docker_id, docker_name
        ))
        new_container_db_id = cursor.lastrowid # Получаем ID вставленной строки
        conn.commit()
        logging.info(f"[DB Add Container] Контейнер добавлен для пользователя {user_id_int}. Новый ID в БД: {new_container_db_id}. Docker Name: {docker_name}")
        return new_container_db_id
    except sqlite3.IntegrityError as e:
        # Чаще всего ошибка уникальности docker_name
        logging.error(f"[DB Add Container] Ошибка целостности при добавлении контейнера для {user_id_int} (возможно, docker_name '{docker_name}' уже занят): {e}")
        return None
    except sqlite3.Error as e:
        logging.error(f"[DB Add Container] Ошибка при добавлении контейнера для {user_id_int}: {e}", exc_info=True)
        return None
    finally:
        if conn:
            conn.close()

def remove_container_from_db(container_db_id):
    """ Удаляет контейнер из БД по его ID (container_db_id) """
    try:
        target_id = int(container_db_id)
    except (ValueError, TypeError):
        logging.error(f"[DB Remove Container] Неверный ID контейнера для удаления: {container_db_id}")
        return False

    sql = "DELETE FROM containers WHERE container_db_id = ?"
    conn = get_db_connection()
    if not conn: return False
    try:
        cursor = conn.cursor()
        cursor.execute(sql, (target_id,))
        conn.commit()
        if cursor.rowcount > 0:
            logging.info(f"[DB Remove Container] Контейнер с ID={target_id} удален из БД.")
            return True
        else:
            logging.warning(f"[DB Remove Container] Контейнер с ID={target_id} не найден в БД для удаления.")
            return False
    except sqlite3.Error as e:
        logging.error(f"[DB Remove Container] Ошибка при удалении контейнера ID={target_id}: {e}", exc_info=True)
        return False
    finally:
        if conn:
            conn.close()

def update_container_status(container_db_id, new_status):
    """ Обновляет статус контейнера в базе данных """
    try:
        target_id = int(container_db_id)
    except (ValueError, TypeError):
        logging.error(f"[DB Update Status] Неверный ID контейнера для обновления статуса: {container_db_id}")
        return False

    sql = "UPDATE containers SET status = ? WHERE container_db_id = ?"
    conn = get_db_connection()
    if not conn: return False
    try:
        cursor = conn.cursor()
        cursor.execute(sql, (new_status, target_id))
        conn.commit()
        if cursor.rowcount > 0:
            logging.debug(f"[DB Update Status] Статус контейнера ID={target_id} обновлен на {new_status}.")
            return True
        else:
            logging.warning(f"[DB Update Status] Контейнер ID={target_id} не найден для обновления статуса.")
            return False
    except sqlite3.Error as e:
        logging.error(f"[DB Update Status] Ошибка при обновлении статуса контейнера ID={target_id}: {e}", exc_info=True)
        return False
    finally:
        if conn:
            conn.close()

def get_container_docker_name(container_db_id):
     """ Получает docker_name контейнера по container_db_id """
     container = get_container_by_id(container_db_id)
     return container['docker_name'] if container else None

def get_all_db_docker_names():
    """ Возвращает множество всех docker_name из базы данных """
    sql = "SELECT docker_name FROM containers WHERE docker_name IS NOT NULL"
    conn = get_db_connection()
    if not conn: return set()
    names = set()
    try:
        cursor = conn.cursor()
        cursor.execute(sql)
        rows = cursor.fetchall()
        names = {row['docker_name'] for row in rows}
        logging.debug(f"[DB Get Docker Names] Найдено {len(names)} уникальных docker_name в БД.")
    except sqlite3.Error as e:
        logging.error(f"[DB Get Docker Names] Ошибка при получении имен Docker: {e}", exc_info=True)
    finally:
        if conn:
            conn.close()
    return names

def get_all_used_ports():
    """ Возвращает множество всех используемых портов из базы данных """
    sql = "SELECT port FROM containers WHERE port IS NOT NULL"
    conn = get_db_connection()
    if not conn: return set()
    ports = set()
    try:
        cursor = conn.cursor()
        cursor.execute(sql)
        rows = cursor.fetchall()
        for row in rows:
             try:
                 ports.add(int(row['port']))
             except (ValueError, TypeError):
                 logging.warning(f"[DB Get Ports] Обнаружен невалидный порт '{row['port']}' в БД. Пропущен.")
        logging.debug(f"[DB Get Ports] Найдено {len(ports)} используемых портов в БД.")
    except sqlite3.Error as e:
        logging.error(f"[DB Get Ports] Ошибка при получении портов: {e}", exc_info=True)
    finally:
        if conn:
            conn.close()
    return ports

# --- Функции для бота (например, для рассылки) ---

def get_all_agreed_user_ids():
    """ Возвращает список ID всех пользователей, принявших соглашение """
    sql = "SELECT user_id FROM users WHERE agreed_policy = 1"
    conn = get_db_connection()
    if not conn: return []
    user_ids = []
    try:
        cursor = conn.cursor()
        cursor.execute(sql)
        rows = cursor.fetchall()
        user_ids = [row['user_id'] for row in rows]
        logging.info(f"[DB Get Agreed IDs] Найдено {len(user_ids)} согласившихся пользователей для рассылки.")
    except sqlite3.Error as e:
        logging.error(f"[DB Get Agreed IDs] Ошибка при получении ID согласившихся пользователей: {e}", exc_info=True)
    finally:
        if conn:
            conn.close()
    return user_ids

# --- END OF FILE utils/database.py ---