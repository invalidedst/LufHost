# --- START OF FILE config.py ---
import os
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SQLITE_DB_FILE = os.path.join(BASE_DIR, 'bot_database.db')
# Старые TXT файлы можно закомментировать, если миграция прошла успешно
# DATABASE_FILE = os.path.join(BASE_DIR, 'user_database.txt')
# AGREEMENT_DATABASE_FILE = os.path.join(BASE_DIR, 'agreement_database.txt')
LOG_FILE = os.path.join(BASE_DIR, 'bot.log')

# --- Изображения ---
IMG_MAIN = os.path.join(BASE_DIR, 'Main.jpg')
IMG_PROFILE = os.path.join(BASE_DIR, 'profile.jpg')
IMG_SETTINGS = os.path.join(BASE_DIR, 'settings.jpg')
IMG_USERBOTS_MENU = os.path.join(BASE_DIR, 'UserBots.jpg')
IMG_USERBOTS_LIST = os.path.join(BASE_DIR, 'list_UserBots.jpg')
IMG_USERBOTS_PANEL = os.path.join(BASE_DIR, 'panel.jpg')
IMG_USERBOTS_BUY = os.path.join(BASE_DIR, 'buy_UserBots.jpg')

# --- Токен ---
def get_token():
    token_path = os.path.join(BASE_DIR, 'bot_token.txt')
    try:
        with open(token_path, 'r') as f:
            token = f.read().strip()
            if token: return token
    except FileNotFoundError: pass
    token_env = os.environ.get("BOT_TOKEN")
    if token_env: return token_env
    print(f"!!! ОШИБКА: Файл {token_path} не найден и BOT_TOKEN не установлен.")
    exit()
BOT_TOKEN = get_token()

# --- Настройки по умолчанию ---
BALANCE_DEFAULT = 0.0
CURRENCY_DEFAULT = "RUB"
REG_DATE_DEFAULT = "Неизвестно"

# --- Тарифы ---
# !!! ДОБАВЛЕНА СЕКЦИЯ LIMITS ДЛЯ КАЖДОГО ТАРИФА !!!
TARIFFS = {
    "lite": {
        "name": "Lite",
        "monthly_prices": {
            1: {"price": 45.0, "name": "1 месяц"},
            2: {"price": 88.2, "name": "2 месяца"},
            3: {"price": 130.95, "name": "3 месяца"},
            6: {"price": 253.8, "name": "6 месяцев"},
            12: {"price": 475.2, "name": "12 месяцев"},
        },
        "limits": {
            "memory": "300m",  # 300 MB RAM
            "storage_gb": 2     # 2 GB Disk (информационно, прямое применение сложнее)
            # Примечание: Прямое ограничение диска через `docker run` сложно.
            # Это значение используется информационно или для будущих реализаций
            # с volume drivers или storage-opt.
        }
    },
    # --- НОВЫЙ ТАРИФ STANDART ---
    "standart": {
        "name": "Standart", # Используем эмодзи в имени для красоты
        "monthly_prices": {
            1: {"price": 75.0, "name": "1 месяц"},
            2: {"price": 147.0, "name": "2 месяца"},
            3: {"price": 218.25, "name": "3 месяца"},
            6: {"price": 423.0, "name": "6 месяцев"},
            12: {"price": 792.0, "name": "12 месяцев"},
        },
        "limits": {
            "memory": "750m",  # 750 MB RAM
            "storage_gb": 4     # 4 GB Disk (информационно)
        }
    },
    # ---------------------------
     "Beta": { # Beta тариф без цен и лимитов (или с дефолтными)
        "name": "Beta",
        "monthly_prices": {},
        "limits": {
            "memory": None, # Без явного лимита (или можно поставить дефолтный)
            "storage_gb": None
        }
     }
}

# --- Docker ---
DOCKER_IMAGE = "topkasoso"
SERVER_IP = "77.222.47.27"
PORT_RANGE_START = 8001
PORT_RANGE_END = 8999

# --- Администраторы ---
ADMIN_IDS = [7485721661]
# --- END OF FILE config.py ---