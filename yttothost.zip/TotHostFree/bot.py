# --- START OF FILE bot.py ---
import asyncio
import logging
import sys

from aiogram import Bot, Dispatcher, F
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.client.default import DefaultBotProperties

# Импортируем конфигурацию и НОВЫЕ функции из database
import config
from utils.database import (
    init_db, # <-- НОВАЯ функция инициализации
    get_all_agreed_user_ids # <-- Функция для получения ID для рассылки
    # Убрали USER_DATA, AGREED_USERS и функции сохранения TXT
)
from utils.docker_utils import verify_server_containers, get_docker_client
from utils.broadcast import send_broadcast

# Импортируем главный роутер обработчиков
from handlers import handlers_router

# Настройка логирования
logging.basicConfig(
    level=logging.INFO, # Или DEBUG для подробностей
    format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',
    stream=sys.stdout
)
logging.getLogger('aiogram.event').setLevel(logging.WARNING)

async def main():
    # --- Инициализация БД ---
    logging.info("Инициализация базы данных SQLite...")
    init_db() # Создаем таблицы, если их нет
    logging.info("Инициализация БД завершена.")

    # --- Проверка Docker ---
    if get_docker_client():
        logging.info("Запуск проверки контейнеров Docker...")
        await verify_server_containers()
        logging.info("Проверка контейнеров завершена.")
    else:
        logging.warning("Пропуск проверки контейнеров: Docker клиент недоступен.")

    # --- Инициализация бота и диспетчера ---
    bot = Bot(token=config.BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    storage = MemoryStorage()
    dp = Dispatcher(storage=storage)
    dp.include_router(handlers_router)

    # --- Опциональная Рассылка перед стартом ---
    logging.info("-" * 30)
    try:
        ask_broadcast = input("Хотите сделать рассылку перед запуском? (Y/N): ").strip().lower()
        if ask_broadcast == 'y':
            broadcast_text = input("Введите текст рассылки (HTML разметка поддерживается):\n")
            if broadcast_text:
                logging.info("Подготовка к рассылке...")
                # --- Получаем ID пользователей из SQLite ---
                recipient_ids = get_all_agreed_user_ids() # Получаем список ID согласившихся
                logging.info(f"Целевая аудитория для рассылки: {len(recipient_ids)} пользователей из БД (согласившиеся).")
                if recipient_ids:
                    # --- Передаем СПИСОК ID в send_broadcast ---
                    await send_broadcast(bot, recipient_ids, broadcast_text)
                    logging.info("Процесс рассылки инициирован.")
                else:
                    logging.warning("Список пользователей для рассылки пуст. Рассылка не будет выполнена.")
            else:
                print("Текст рассылки пуст. Рассылка отменена.")
        else:
            print("Запуск без рассылки.")
    except EOFError:
         print("Пропуск запроса на рассылку (нет интерактивного ввода).")
    except Exception as e:
        logging.error(f"Ошибка во время запроса/подготовки рассылки: {e}", exc_info=True)
        print("Произошла ошибка во время запроса на рассылку. Запуск без рассылки.")

    logging.info("-" * 30)

    # --- Запуск ---
    logging.info("Запуск бота...")
    await bot.delete_webhook(drop_pending_updates=True)
    try:
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    finally:
        logging.info("Остановка бота...")
        await bot.session.close()
        logging.info("Сессия бота закрыта.")
        # Сохранять ничего не нужно, SQLite сохраняет данные сам

if __name__ == '__main__':
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logging.info("Бот остановлен вручную.")
# --- END OF FILE bot.py ---