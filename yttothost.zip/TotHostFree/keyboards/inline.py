# --- START OF FILE keyboards/inline.py ---

from aiogram.types import InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder
import logging

# Импортируем тарифы для клавиатуры покупки
from config import TARIFFS, CURRENCY_DEFAULT

# --- Основные Меню ---
def setup_main_menu_keyboard():
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="💻 Профиль", callback_data="profile"),
        InlineKeyboardButton(text="⚙️ Настройки", callback_data="settings")
    )
    builder.row(
        InlineKeyboardButton(text="Чат поддержки", url="https://t.me/ToThosTing"),
        InlineKeyboardButton(text="💸Задонатить хосту", url="https://t.me/tothosting_donates")
    )
    builder.row(
        InlineKeyboardButton(text="🤖 Управление юзерботами", callback_data="userbots_menu")
    )
    return builder

def setup_profile_keyboard():
    builder = InlineKeyboardBuilder()
    builder.button(text="💰 Пополнить баланс", callback_data="top_up_balance")
    builder.button(text="🔙 Назад", callback_data="main_menu")
    builder.adjust(1)
    return builder

def setup_settings_keyboard():
    builder = InlineKeyboardBuilder()
    builder.button(text="📋 Выбрать валюту", callback_data="select_currency")
    builder.button(text="🔙 Назад", callback_data="main_menu")
    builder.adjust(1)
    return builder

def setup_userbots_menu_keyboard():
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="🪪 Список юзерботов", callback_data="list_userbots"),
        InlineKeyboardButton(text="📲 Купить юзербота", callback_data="buy_userbot")
    )
    builder.button(text="🔙 Назад", callback_data="main_menu")
    builder.adjust(2, 1)
    return builder

# --- Соглашение ---
def setup_agreement_keyboard():
    builder = InlineKeyboardBuilder()
    builder.button(text="✅ Согласен", callback_data="agree_policy")
    builder.adjust(1)
    return builder

# --- Пополнение ---
def setup_top_up_balance_keyboard():
    builder = InlineKeyboardBuilder()
    builder.button(text="🇷🇺 Русские карты", callback_data="russian_cards")
    builder.button(text="🇺🇦 Украинские карты", callback_data="ukrainian_cards")
    builder.button(text="🇰🇿 Казахские карты", callback_data="kazakh_cards")
    builder.button(text="🏝 Crypto Pay", callback_data="crypto_pay")
    builder.button(text="❌ Отмена", callback_data="cancel_top_up")
    builder.adjust(1)
    return builder

def setup_cancel_top_up_keyboard():
    builder = InlineKeyboardBuilder()
    builder.button(text="❌ Отмена", callback_data="cancel_top_up")
    builder.adjust(1)
    return builder


# --- Настройки Валюты ---
def setup_select_currency_keyboard():
    builder = InlineKeyboardBuilder()
    builder.button(text="🇷🇺 RUB", callback_data="currency_rub")
    builder.button(text="🇺🇦 UAH", callback_data="currency_uah")
    builder.button(text="🇰🇿 KZT", callback_data="currency_kzt")
    builder.button(text="🇺🇸 USD", callback_data="currency_usd")
    builder.button(text="🔙 Назад", callback_data="back_to_settings")
    builder.adjust(1)
    return builder

# --- Управление Юзерботами ---

def setup_list_userbots_keyboard(containers):
    builder = InlineKeyboardBuilder()
    if containers:
        for container in containers:
            db_id = container.get('container_db_id')
            name = container.get('name', 'N/A')
            status = container.get('status', '?')
            if db_id is not None:
                button_text = f"🤖 {name} [DB:{db_id}] ({status})"
                builder.button(text=button_text, callback_data=f"control_userbot_{db_id}")
            else:
                 logging.warning(f"Пропуск контейнера в клавиатуре - отсутствует container_db_id: {container}")
    else:
         builder.button(text="У вас нет юзерботов", callback_data="no_bots_placeholder")

    builder.button(text="🔙 Назад", callback_data="userbots_menu")
    builder.adjust(1)
    return builder

def setup_control_userbot_keyboard(container_status, install_link, container_db_id):
    builder = InlineKeyboardBuilder()
    status_button_text = "🔴 Выключить" if container_status == "🟢" else "🟢 Включить"
    status_callback_data = f"disable_userbot_{container_db_id}" if container_status == "🟢" else f"enable_userbot_{container_db_id}"
    builder.button(text=status_button_text, callback_data=status_callback_data)
    builder.button(text="🔄 Перезапустить", callback_data=f"restart_userbot_{container_db_id}")
    builder.button(text="♻️ Переустановить", callback_data=f"confirm_reinstall_userbot_{container_db_id}")
    if install_link and "N/A" not in install_link:
        builder.button(text="🔗 Ссылка на установку", url=install_link)
    else:
        builder.button(text="🔗 Ссылка (недоступна)", callback_data="link_na_placeholder")
    builder.button(text="🔙 Назад", callback_data="list_userbots")
    builder.adjust(2, 2, 1)
    return builder

def setup_reinstall_confirmation_keyboard(container_db_id):
    builder = InlineKeyboardBuilder()
    builder.button(text="♻️ Да, переустановить", callback_data=f"reinstall_userbot_{container_db_id}")
    builder.button(text="❌ Нет, отмена", callback_data=f"cancel_reinstall_userbot_{container_db_id}")
    builder.adjust(1)
    return builder

# --- Покупка Юзербота ---

# !!! ИЗМЕНЕНО: Добавлено условие для эмодзи тарифов !!!
def setup_buy_userbot_keyboard():
    """ Создает клавиатуру для выбора тарифа при покупке. """
    builder = InlineKeyboardBuilder()
    # Динамически добавляем кнопки для каждого тарифа из конфига (кроме Beta)
    for tariff_key, tariff_data in TARIFFS.items():
        if tariff_key != "Beta":
            # --- Определяем эмодзи для кнопки ---
            tariff_emoji = ""
            if tariff_key == "lite":
                tariff_emoji = "🌀 " # Эмодзи для Lite
            elif tariff_key == "standart":
                tariff_emoji = "🛠 " # Эмодзи для Standart
            # Можно добавить elif для других тарифов
            # --- -----------------------------

            button_text = f"{tariff_emoji}{tariff_data['name']}" # Собираем текст кнопки
            builder.button(text=button_text, callback_data=f"select_tariff_{tariff_key}")

    builder.button(text="🔙 Назад", callback_data="userbots_menu")
    builder.adjust(1) # Тарифы и кнопка Назад - в столбец
    return builder

def setup_tariff_period_keyboard(tariff_key, currency=CURRENCY_DEFAULT):
    builder = InlineKeyboardBuilder()
    tariff_data = TARIFFS.get(tariff_key)
    if not tariff_data or not tariff_data.get("monthly_prices"):
        logging.error(f"Не найдены цены для тарифа '{tariff_key}' в конфиге.")
        builder.button(text="Нет доступных периодов", callback_data="no_periods_placeholder")
    else:
        prices = tariff_data["monthly_prices"]
        for period_months in sorted(prices.keys()):
            period_info = prices[period_months]
            price = period_info['price']
            name = period_info['name']
            builder.button(text=f"{name} - {price:.2f} {currency}",
                           callback_data=f"period_{tariff_key}_{period_months}")
    builder.button(text="🔙 Назад", callback_data="buy_userbot")
    builder.adjust(1)
    return builder

# --- END OF FILE keyboards/inline.py ---